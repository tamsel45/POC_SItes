import axios from 'axios'
import { useAuthStore } from '../store/authStore'
import * as mockData from './mockData'

// Set to true to use mock data (no backend required)
const USE_MOCK_DATA = false

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8001/api/v1'

export const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
})

// Request interceptor to add auth token
apiClient.interceptors.request.use(
  (config) => {
    const token = useAuthStore.getState().token
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// Response interceptor for error handling
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401 && !USE_MOCK_DATA) {
      useAuthStore.getState().logout()
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

// Mock API responses
const mockApiCall = async (data: any) => {
  await mockData.delay()
  return { data }
}

// Agent API
export const agentApi = {
  list: async (params?: any) => {
    if (USE_MOCK_DATA) {
      return mockApiCall({
        agents: mockData.mockAgents,
        total: mockData.mockAgents.length,
        page: 1,
        page_size: 20,
      })
    }
    return apiClient.get('/agents', { params })
  },
  get: async (id: string) => {
    if (USE_MOCK_DATA) {
      const agent = mockData.mockAgents.find((a) => a.id === id)
      return mockApiCall(agent)
    }
    return apiClient.get(`/agents/${id}`)
  },
  create: async (data: any) => {
    if (USE_MOCK_DATA) {
      const newAgent = {
        id: `agent-${Date.now()}`,
        ...data,
        status: 'active',
        conversation_count: 0,
        success_rate: 0,
        avg_response_time: 0,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        created_by: 'You',
      }
      mockData.mockAgents.push(newAgent)
      return mockApiCall(newAgent)
    }
    return apiClient.post('/agents', data)
  },
  update: async (id: string, data: any) => {
    if (USE_MOCK_DATA) {
      const index = mockData.mockAgents.findIndex((a) => a.id === id)
      if (index !== -1) {
        mockData.mockAgents[index] = { ...mockData.mockAgents[index], ...data }
        return mockApiCall(mockData.mockAgents[index])
      }
    }
    return apiClient.put(`/agents/${id}`, data)
  },
  delete: async (id: string) => {
    if (USE_MOCK_DATA) {
      const index = mockData.mockAgents.findIndex((a) => a.id === id)
      if (index !== -1) {
        mockData.mockAgents.splice(index, 1)
      }
      return mockApiCall({ success: true })
    }
    return apiClient.delete(`/agents/${id}`)
  },
  invoke: async (id: string, input: string, debug?: boolean) => {
    if (USE_MOCK_DATA) {
      return mockApiCall({
        agent_id: id,
        response: `Thank you for your message: "${input}". This is a mock response from the agent. In production, this would be the actual AI response.`,
        tokens_in: 15,
        tokens_out: 28,
        latency: 1.8,
        timestamp: new Date().toISOString(),
      })
    }
    return apiClient.post(`/agents/${id}/invoke`, { input, debug })
  },
}

// Prompt API
export const promptApi = {
  list: async (agentId: string) => {
    if (USE_MOCK_DATA) {
      return mockApiCall(mockData.mockPrompts.filter((p) => p.agent_id === agentId))
    }
    return apiClient.get(`/prompts/${agentId}`)
  },
  create: async (data: any) => {
    if (USE_MOCK_DATA) {
      const newPrompt = {
        id: `prompt-${Date.now()}`,
        ...data,
        version: 'v1.0',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        created_by: 'You',
      }
      mockData.mockPrompts.push(newPrompt)
      return mockApiCall(newPrompt)
    }
    return apiClient.post('/prompts', data)
  },
  test: async (data: any) => {
    if (USE_MOCK_DATA) {
      await mockData.delay(800)
      return mockApiCall({
        response: `Mock response for input: "${data.input}". In production, this would use your actual prompt and LLM to generate a response.`,
        tokens_in: data.prompt.split(' ').length + data.input.split(' ').length,
        tokens_out: 45,
        latency: 0.8,
      })
    }
    return apiClient.post('/prompts/test', data)
  },
}

// Knowledge Base API
export const knowledgeBaseApi = {
  listDocuments: async (agentId: string) => {
    if (USE_MOCK_DATA) {
      return mockApiCall({
        documents: mockData.mockDocuments.filter((d) => d.agent_id === agentId),
        total: mockData.mockDocuments.length,
        total_size: mockData.mockDocuments.reduce((sum, d) => sum + d.size, 0),
      })
    }
    return apiClient.get(`/knowledge-base/${agentId}/documents`)
  },
  getStats: async (agentId: string) => {
    if (USE_MOCK_DATA) {
      return mockApiCall(mockData.mockKnowledgeBaseStats)
    }
    return apiClient.get(`/knowledge-base/${agentId}/stats`)
  },
  upload: async (agentId: string, files: File[], options: any) => {
    if (USE_MOCK_DATA) {
      await mockData.delay(1000)
      const newDocs = files.map((file) => ({
        id: `doc-${Date.now()}-${Math.random()}`,
        agent_id: agentId,
        name: file.name,
        type: file.name.split('.').pop()?.toLowerCase() || 'txt',
        size: file.size,
        status: 'processing',
        chunks: 0,
        embeddings_complete: false,
        uploaded_at: new Date().toISOString(),
        last_indexed: null,
      }))
      mockData.mockDocuments.push(...newDocs)
      return mockApiCall(newDocs)
    }
    const formData = new FormData()
    files.forEach((file) => formData.append('files', file))
    formData.append('agent_id', agentId)
    Object.entries(options).forEach(([key, value]) => {
      formData.append(key, String(value))
    })
    return apiClient.post('/knowledge-base/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    })
  },
  delete: async (documentId: string) => {
    if (USE_MOCK_DATA) {
      const index = mockData.mockDocuments.findIndex((d) => d.id === documentId)
      if (index !== -1) {
        mockData.mockDocuments.splice(index, 1)
      }
      return mockApiCall({ success: true })
    }
    return apiClient.delete(`/knowledge-base/${documentId}`)
  },
  reindex: async (documentId: string) => {
    if (USE_MOCK_DATA) {
      return mockApiCall({ detail: 'Reindexing started', document_id: documentId })
    }
    return apiClient.post(`/knowledge-base/${documentId}/reindex`)
  },
}

// Testing API
export const testingApi = {
  runSingle: async (agentId: string, input: string, debug?: boolean) => {
    if (USE_MOCK_DATA) {
      await mockData.delay(600)
      return mockApiCall({
        agent_id: agentId,
        input,
        output: `Mock response: Thank you for your input "${input}". This is a simulated response. In production, this would be generated by your AI agent with full context and knowledge base access.`,
        latency: 0.6,
        tokens_in: input.split(' ').length + 50,
        tokens_out: 35,
        debug: debug
          ? {
              timestamp: new Date().toISOString(),
              model: 'GPT-4 Turbo',
              temperature: 0.7,
              kb_queries: [{ query: 'customer support', results: 5, top_score: 0.94 }],
            }
          : null,
      })
    }
    return apiClient.post('/testing/single', null, {
      params: { agent_id: agentId, input_text: input, debug },
    })
  },
  runBatch: async (data: any) => {
    if (USE_MOCK_DATA) {
      await mockData.delay(1500)
      const passed = Math.floor(data.test_cases.length * 0.85)
      const failed = data.test_cases.length - passed
      return mockApiCall({
        test_id: `batch-${Date.now()}`,
        total_tests: data.test_cases.length,
        completed: data.test_cases.length,
        passed,
        failed,
        avg_latency: 1.2,
        results: data.test_cases.map((tc: any, idx: number) => ({
          id: `test-${idx}`,
          ...tc,
          result: idx % 5 === 0 ? 'fail' : 'pass',
          actual_output: `Mock response for: ${tc.input}`,
          score: idx % 5 === 0 ? 0.65 : 0.92,
          latency: Math.random() * 2 + 0.5,
        })),
      })
    }
    return apiClient.post('/testing/batch', data)
  },
}

// Analytics API
export const analyticsApi = {
  get: async (agentId: string, period?: string) => {
    if (USE_MOCK_DATA) {
      return mockApiCall(mockData.mockAnalytics)
    }
    return apiClient.get(`/analytics/${agentId}`, { params: { period } })
  },
  export: async (agentId: string, period: string, format: string) => {
    if (USE_MOCK_DATA) {
      return mockApiCall({
        detail: `Analytics export for agent ${agentId}`,
        download_url: `/downloads/analytics-${agentId}-${period}.${format}`,
      })
    }
    return apiClient.get(`/analytics/${agentId}/export`, { params: { period, format } })
  },
}
