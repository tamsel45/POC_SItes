// Mock data for standalone frontend development

export const mockAgents = [
  {
    id: 'agent-001',
    name: 'Customer Support Agent',
    description: 'Handles customer inquiries and provides product information',
    status: 'active',
    framework: 'Microsoft Copilot Studio',
    language_model: 'GPT-4 Turbo',
    temperature: 0.7,
    max_tokens: 1000,
    tags: ['customer-service', 'production', 'high-priority'],
    conversation_count: 1247,
    success_rate: 94.2,
    avg_response_time: 2.1,
    created_at: '2024-01-15T10:30:00Z',
    updated_at: '2024-12-01T08:15:00Z',
    created_by: 'Arif',
  },
  {
    id: 'agent-002',
    name: 'HR Onboarding Assistant',
    description: 'Assists with employee onboarding processes',
    status: 'paused',
    framework: 'Microsoft Copilot Studio',
    language_model: 'GPT-4 Turbo',
    temperature: 0.6,
    max_tokens: 800,
    tags: ['hr', 'onboarding'],
    conversation_count: 456,
    success_rate: 89.0,
    avg_response_time: 3.2,
    created_at: '2024-01-20T14:45:00Z',
    updated_at: '2024-11-30T16:20:00Z',
    created_by: 'Rupak',
  },
  {
    id: 'agent-003',
    name: 'Sales Lead Qualifier',
    description: 'Qualifies sales leads and schedules demos',
    status: 'active',
    framework: 'Microsoft Copilot Studio',
    language_model: 'GPT-4',
    temperature: 0.8,
    max_tokens: 1200,
    tags: ['sales', 'lead-gen'],
    conversation_count: 789,
    success_rate: 91.5,
    avg_response_time: 2.8,
    created_at: '2024-01-10T09:00:00Z',
    updated_at: '2024-11-28T11:30:00Z',
    created_by: 'David',
  },
]

export const mockPrompts = [
  {
    id: 'prompt-001',
    agent_id: 'agent-001',
    name: 'Customer Support System Prompt',
    content: `You are an expert customer support agent for Acme Corporation. Your role is to:

1. Greet customers warmly and professionally
2. Understand their issue through active listening
3. Provide accurate solutions from the knowledge base
4. Escalate complex issues to human agents when needed

Guidelines:
- Always be polite and empathetic
- Keep responses concise (under 150 words)
- Use {{customer_name}} for personalization
- Reference policy {{return_policy}} when needed

If you don't know the answer, say "Let me connect you with a specialist who can help."`,
    version: 'v3.2',
    variables: [
      {
        name: 'customer_name',
        description: "User's display name",
        default_value: 'there',
      },
      {
        name: 'return_policy',
        description: '30-day return policy text',
        default_value: 'Our 30-day return policy allows...',
      },
    ],
    few_shot_examples: [
      {
        user_input: 'I want to return my order',
        assistant_output:
          "I'd be happy to help with your return. According to our {{return_policy}}, you can return items within 30 days...",
      },
    ],
    created_at: '2024-01-15T10:30:00Z',
    updated_at: '2024-12-01T08:15:00Z',
    created_by: 'admin@agentstudio.com',
  },
]

export const mockDocuments = [
  {
    id: 'doc-001',
    agent_id: 'agent-001',
    name: 'Product_Catalog_2024.pdf',
    type: 'pdf',
    size: 2516582,
    status: 'complete',
    chunks: 45,
    embeddings_complete: true,
    uploaded_at: '2024-01-20T14:30:00Z',
    last_indexed: '2024-11-29T10:15:00Z',
  },
  {
    id: 'doc-002',
    agent_id: 'agent-001',
    name: 'Return_Policy.docx',
    type: 'docx',
    size: 87040,
    status: 'complete',
    chunks: 8,
    embeddings_complete: true,
    uploaded_at: '2024-01-18T09:45:00Z',
    last_indexed: '2024-11-27T16:20:00Z',
  },
  {
    id: 'doc-003',
    agent_id: 'agent-001',
    name: 'FAQ_Document.txt',
    type: 'txt',
    size: 45120,
    status: 'processing',
    chunks: 12,
    embeddings_complete: false,
    uploaded_at: '2024-12-04T10:00:00Z',
    last_indexed: null,
  },
]

export const mockKnowledgeBaseStats = {
  total_documents: 3,
  total_chunks: 65,
  vector_store_size: 2648742,
  embedding_model: 'text-embedding-ada-002',
  last_full_reindex: '2024-11-29T10:15:00Z',
  avg_retrieval_time: 0.8,
}

export const mockAnalytics = {
  metrics: {
    total_conversations: 12456,
    success_rate: 94.2,
    avg_latency: 2.3,
    user_satisfaction: 4.6,
  },
  conversation_trends: Array.from({ length: 30 }, (_, i) => ({
    date: `Day ${i + 1}`,
    count: Math.floor(Math.random() * 200) + 300,
  })),
  response_time_distribution: [
    { bucket: '<1s', count: 2847 },
    { bucket: '1-2s', count: 5234 },
    { bucket: '2-3s', count: 3156 },
    { bucket: '3-5s', count: 892 },
    { bucket: '>5s', count: 327 },
  ],
  top_intents: [
    { intent: 'Product Returns', percentage: 28.0, count: 3487 },
    { intent: 'Order Status', percentage: 22.0, count: 2740 },
    { intent: 'Account Issues', percentage: 18.0, count: 2242 },
    { intent: 'Product Information', percentage: 15.0, count: 1868 },
    { intent: 'Shipping Questions', percentage: 12.0, count: 1495 },
    { intent: 'Other', percentage: 5.0, count: 624 },
  ],
  error_breakdown: [
    { type: 'Timeout (>30s)', count: 312, percentage: 43.0 },
    { type: 'Invalid Response', count: 189, percentage: 26.0 },
    { type: 'Knowledge Base Miss', count: 145, percentage: 20.0 },
    { type: 'API Errors', count: 78, percentage: 11.0 },
  ],
  cost_breakdown: [
    { category: 'LLM API Calls', amount: 987.23, percentage: 79.0 },
    { category: 'Embeddings', amount: 156.34, percentage: 13.0 },
    { category: 'Storage', amount: 78.9, percentage: 6.0 },
    { category: 'Compute', amount: 23.2, percentage: 2.0 },
  ],
}

// Helper function to simulate API delay
export const delay = (ms: number = 300) =>
  new Promise((resolve) => setTimeout(resolve, ms))

