import { useState } from 'react'
import { toast } from 'react-toastify'
import './Integrations.css'

const AVAILABLE_INTEGRATIONS = [
  {
    id: 'slack',
    name: 'Slack',
    icon: '💬',
    category: 'communication',
    description: 'Send notifications and interact with agents via Slack',
    status: 'connected',
    config: {
      workspace: 'mycompany.slack.com',
      channels: 3,
      lastSync: '2024-12-04T10:30:00Z',
    },
  },
  {
    id: 'teams',
    name: 'Microsoft Teams',
    icon: '🟪',
    category: 'communication',
    description: 'Integrate agents with Microsoft Teams channels',
    status: 'connected',
    config: {
      tenant: 'mycompany.onmicrosoft.com',
      teams: 5,
      lastSync: '2024-12-04T09:15:00Z',
    },
  },
  {
    id: 'salesforce',
    name: 'Salesforce',
    icon: '☁️',
    category: 'crm',
    description: 'Sync leads and opportunities with Salesforce CRM',
    status: 'not-connected',
  },
  {
    id: 'hubspot',
    name: 'HubSpot',
    icon: '🟠',
    category: 'crm',
    description: 'Manage contacts and deals in HubSpot',
    status: 'not-connected',
  },
  {
    id: 'zendesk',
    name: 'Zendesk',
    icon: '🎫',
    category: 'support',
    description: 'Create and manage support tickets',
    status: 'connected',
    config: {
      domain: 'mycompany.zendesk.com',
      tickets: 1247,
      lastSync: '2024-12-04T11:45:00Z',
    },
  },
  {
    id: 'intercom',
    name: 'Intercom',
    icon: '💙',
    category: 'support',
    description: 'Customer messaging and support platform',
    status: 'not-connected',
  },
  {
    id: 'sharepoint',
    name: 'SharePoint',
    icon: '📘',
    category: 'storage',
    description: 'Access documents from SharePoint for knowledge base',
    status: 'not-connected',
  },
  {
    id: 's3',
    name: 'Amazon S3',
    icon: '📦',
    category: 'storage',
    description: 'Store and retrieve files from S3 buckets',
    status: 'not-connected',
  },
  {
    id: 'azure-blob',
    name: 'Azure Blob Storage',
    icon: '☁️',
    category: 'storage',
    description: 'Connect to Azure Blob Storage containers',
    status: 'not-connected',
  },
  {
    id: 'jira',
    name: 'Jira',
    icon: '🔷',
    category: 'project',
    description: 'Create and track issues in Jira',
    status: 'not-connected',
  },
  {
    id: 'asana',
    name: 'Asana',
    icon: '🔴',
    category: 'project',
    description: 'Manage tasks and projects in Asana',
    status: 'not-connected',
  },
  {
    id: 'webhook',
    name: 'Custom Webhook',
    icon: '🔗',
    category: 'custom',
    description: 'Send data to custom webhook endpoints',
    status: 'not-connected',
  },
]

const CATEGORIES = [
  { id: 'all', name: 'All Integrations', icon: '📦' },
  { id: 'communication', name: 'Communication', icon: '💬' },
  { id: 'crm', name: 'CRM & Sales', icon: '💼' },
  { id: 'support', name: 'Support', icon: '🎫' },
  { id: 'storage', name: 'Storage', icon: '📁' },
  { id: 'project', name: 'Project Management', icon: '📋' },
  { id: 'custom', name: 'Custom', icon: '⚙️' },
]

export default function Integrations() {
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedIntegration, setSelectedIntegration] = useState<string | null>(null)

  const filteredIntegrations = AVAILABLE_INTEGRATIONS.filter((integration) => {
    const matchesCategory =
      selectedCategory === 'all' || integration.category === selectedCategory
    const matchesSearch =
      integration.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      integration.description.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesCategory && matchesSearch
  })

  const connectedCount = AVAILABLE_INTEGRATIONS.filter((i) => i.status === 'connected').length

  const handleConnect = (integrationId: string) => {
    toast.info(`Connecting to ${integrationId}...`)
  }

  const handleDisconnect = (integrationId: string) => {
    if (confirm('Are you sure you want to disconnect this integration?')) {
      toast.success(`Disconnected from ${integrationId}`)
    }
  }

  const handleConfigure = (integrationId: string) => {
    setSelectedIntegration(integrationId)
  }

  return (
    <div className="integrations-page">
      {/* Header */}
      <div className="integrations-header">
        <div>
          <h1 className="page-title">Integrations</h1>
          <p className="page-subtitle">
            Connect your agents with external services and platforms
          </p>
        </div>
        <button className="btn btn-primary">
          <span className="btn-icon">➕</span>
          Request Integration
        </button>
      </div>

      {/* Stats */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon green">✓</div>
          <div>
            <div className="stat-value">{connectedCount}</div>
            <div className="stat-label">Connected</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon blue">📦</div>
          <div>
            <div className="stat-value">{AVAILABLE_INTEGRATIONS.length}</div>
            <div className="stat-label">Available</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon purple">🔄</div>
          <div>
            <div className="stat-value">
              {AVAILABLE_INTEGRATIONS.filter((i) => i.config).reduce(
                (sum, i) => sum + (i.config?.channels || i.config?.teams || i.config?.tickets || 0),
                0
              )}
            </div>
            <div className="stat-label">Active Connections</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon orange">⚡</div>
          <div>
            <div className="stat-value">24/7</div>
            <div className="stat-label">Monitoring</div>
          </div>
        </div>
      </div>

      <div className="integrations-content">
        {/* Sidebar */}
        <div className="integrations-sidebar">
          <div className="sidebar-section">
            <h3 className="sidebar-title">Categories</h3>
            <div className="category-list">
              {CATEGORIES.map((category) => {
                const count =
                  category.id === 'all'
                    ? AVAILABLE_INTEGRATIONS.length
                    : AVAILABLE_INTEGRATIONS.filter((i) => i.category === category.id).length
                return (
                  <button
                    key={category.id}
                    className={`category-item ${selectedCategory === category.id ? 'active' : ''}`}
                    onClick={() => setSelectedCategory(category.id)}
                  >
                    <span className="category-icon">{category.icon}</span>
                    <span className="category-name">{category.name}</span>
                    <span className="category-count">{count}</span>
                  </button>
                )
              })}
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="integrations-main">
          {/* Search */}
          <div className="search-box">
            <span className="search-icon">🔍</span>
            <input
              type="text"
              placeholder="Search integrations..."
              className="search-input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          {/* Integrations Grid */}
          <div className="integrations-grid">
            {filteredIntegrations.map((integration) => (
              <div key={integration.id} className="integration-card card hover-lift">
                <div className="integration-header">
                  <div className="integration-icon-wrapper">
                    <span className="integration-icon">{integration.icon}</span>
                  </div>
                  <span
                    className={`status-badge ${integration.status === 'connected' ? 'success' : 'secondary'}`}
                  >
                    {integration.status === 'connected' ? '● Connected' : '○ Not Connected'}
                  </span>
                </div>

                <h3 className="integration-name">{integration.name}</h3>
                <p className="integration-description">{integration.description}</p>

                {integration.config && (
                  <div className="integration-stats">
                    {Object.entries(integration.config).map(([key, value]) => {
                      if (key === 'lastSync') return null
                      return (
                        <div key={key} className="stat">
                          <span className="stat-key">{key}:</span>
                          <span className="stat-value">{value}</span>
                        </div>
                      )
                    })}
                    {integration.config.lastSync && (
                      <div className="last-sync">
                        Last sync: {new Date(integration.config.lastSync).toLocaleString()}
                      </div>
                    )}
                  </div>
                )}

                <div className="integration-actions">
                  {integration.status === 'connected' ? (
                    <>
                      <button
                        className="btn btn-secondary btn-sm"
                        onClick={() => handleConfigure(integration.id)}
                      >
                        Configure
                      </button>
                      <button
                        className="btn btn-danger btn-sm"
                        onClick={() => handleDisconnect(integration.id)}
                      >
                        Disconnect
                      </button>
                    </>
                  ) : (
                    <button
                      className="btn btn-primary btn-full"
                      onClick={() => handleConnect(integration.id)}
                    >
                      Connect
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>

          {filteredIntegrations.length === 0 && (
            <div className="empty-state">
              <span className="empty-icon">🔍</span>
              <h3>No integrations found</h3>
              <p>Try adjusting your search or category filter</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

