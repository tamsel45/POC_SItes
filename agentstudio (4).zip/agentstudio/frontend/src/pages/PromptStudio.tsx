import { useState } from 'react'
import { useParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import {
  Card,
  Button,
  Input,
  Label,
  Textarea,
  Select,
  Tab,
  TabList,
  Switch,
} from '@fluentui/react-components'
import {
  SaveRegular,
  PlayRegular,
  DocumentCopyRegular,
  HistoryRegular,
  ChartMultipleRegular,
  AddRegular,
  DeleteRegular,
  CodeRegular,
  TextGrammarSettingsRegular,
} from '@fluentui/react-icons'
import Editor from '@monaco-editor/react'
import { toast } from 'react-toastify'
import { promptApi } from '../services/api'
import './PromptStudio.css'

export default function PromptStudio() {
  const { id } = useParams()
  const [activeTab, setActiveTab] = useState('editor')
  const [promptContent, setPromptContent] = useState(`You are an expert AI assistant designed to help users effectively.

## Your Capabilities
- Provide accurate and helpful information
- Understand context and nuance
- Admit when you don't know something
- Ask clarifying questions when needed

## Guidelines
1. Be clear and concise
2. Use {{user_name}} for personalization
3. Reference {{context}} when available
4. Maintain a professional yet friendly tone

## Response Format
- Start with acknowledgment
- Provide structured information
- End with next steps or questions

Remember: Always prioritize accuracy over speed.`)

  const [variables, setVariables] = useState([
    { name: 'user_name', description: 'User display name', defaultValue: 'there' },
    { name: 'context', description: 'Conversation context', defaultValue: 'general inquiry' },
  ])

  const [testInput, setTestInput] = useState('Hello, I need help with my account.')
  const [testOutput, setTestOutput] = useState('')
  const [testing, setTesting] = useState(false)
  const [selectedModel, setSelectedModel] = useState('gpt-4-turbo')
  const [temperature, setTemperature] = useState(0.7)
  const [maxTokens, setMaxTokens] = useState(1000)

  const templates = [
    { name: 'Customer Support', category: 'Support' },
    { name: 'Sales Assistant', category: 'Sales' },
    { name: 'Technical Expert', category: 'Technical' },
    { name: 'Creative Writer', category: 'Creative' },
    { name: 'Data Analyst', category: 'Analytics' },
  ]

  const handleTest = async () => {
    if (!testInput.trim()) return

    setTesting(true)
    try {
      const response = await promptApi.test({
        prompt: promptContent,
        input: testInput,
        variables: {},
      })
      setTestOutput(response.data.response)
      toast.success('Prompt tested successfully!')
    } catch (error) {
      toast.error('Failed to test prompt')
    } finally {
      setTesting(false)
    }
  }

  const handleSave = () => {
    toast.success('Prompt saved successfully!')
  }

  const addVariable = () => {
    setVariables([
      ...variables,
      { name: '', description: '', defaultValue: '' },
    ])
  }

  const removeVariable = (index: number) => {
    setVariables(variables.filter((_, i) => i !== index))
  }

  const updateVariable = (index: number, field: string, value: string) => {
    const updated = [...variables]
    updated[index] = { ...updated[index], [field]: value }
    setVariables(updated)
  }

  return (
    <div className="prompt-studio">
      {/* Header */}
      <div className="prompt-studio-header">
        <div>
          <h1 className="page-title">Prompt Studio</h1>
          <p className="page-subtitle">Design, test, and optimize your AI prompts</p>
        </div>
        <div className="header-actions">
          <Button icon={<HistoryRegular />}>Version History</Button>
          <Button icon={<DocumentCopyRegular />}>Duplicate</Button>
          <Button icon={<SaveRegular />} appearance="primary" onClick={handleSave}>
            Save Prompt
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="studio-layout">
        {/* Left Sidebar - Templates & Settings */}
        <div className="studio-sidebar">
          <Card className="sidebar-section">
            <h3 className="section-title">
              <CodeRegular /> Templates
            </h3>
            <div className="template-list">
              {templates.map((template, idx) => (
                <button key={idx} className="template-item">
                  <div className="template-name">{template.name}</div>
                  <div className="template-category">{template.category}</div>
                </button>
              ))}
            </div>
          </Card>

          <Card className="sidebar-section">
            <h3 className="section-title">
              <TextGrammarSettingsRegular /> Model Settings
            </h3>
            <div className="settings-form">
              <div className="form-field">
                <Label>Model</Label>
                <Select
                  value={selectedModel}
                  onChange={(e) => setSelectedModel(e.target.value)}
                >
                  <option value="gpt-4-turbo">GPT-4 Turbo</option>
                  <option value="gpt-4">GPT-4</option>
                  <option value="gpt-3.5-turbo">GPT-3.5 Turbo</option>
                </Select>
              </div>

              <div className="form-field">
                <Label>Temperature: {temperature}</Label>
                <input
                  type="range"
                  min="0"
                  max="2"
                  step="0.1"
                  value={temperature}
                  onChange={(e) => setTemperature(parseFloat(e.target.value))}
                  className="slider"
                />
                <div className="slider-labels">
                  <span>Precise</span>
                  <span>Creative</span>
                </div>
              </div>

              <div className="form-field">
                <Label>Max Tokens</Label>
                <Input
                  type="number"
                  value={maxTokens.toString()}
                  onChange={(e) => setMaxTokens(parseInt(e.target.value))}
                />
              </div>

              <div className="form-field">
                <div className="switch-field">
                  <Switch />
                  <Label>Streaming</Label>
                </div>
              </div>
            </div>
          </Card>

          <Card className="sidebar-section stats-card">
            <h3 className="section-title">
              <ChartMultipleRegular /> Performance
            </h3>
            <div className="stats-grid">
              <div className="stat">
                <div className="stat-value">94.2%</div>
                <div className="stat-label">Success Rate</div>
              </div>
              <div className="stat">
                <div className="stat-value">1.8s</div>
                <div className="stat-label">Avg Latency</div>
              </div>
            </div>
          </Card>
        </div>

        {/* Main Editor Area */}
        <div className="studio-main">
          <Card className="editor-card">
            <TabList
              selectedValue={activeTab}
              onTabSelect={(_, data) => setActiveTab(data.value as string)}
              size="large"
            >
              <Tab value="editor" icon={<CodeRegular />}>
                Editor
              </Tab>
              <Tab value="variables">Variables ({variables.length})</Tab>
              <Tab value="examples">Few-Shot Examples</Tab>
              <Tab value="advanced">Advanced</Tab>
            </TabList>

            <div className="tab-content">
              {activeTab === 'editor' && (
                <div className="editor-container">
                  <div className="editor-toolbar">
                    <div className="toolbar-left">
                      <span className="editor-label">System Prompt</span>
                      <span className="char-count">
                        {promptContent.length} characters
                      </span>
                    </div>
                    <div className="toolbar-right">
                      <Button size="small" appearance="subtle">
                        Format
                      </Button>
                      <Button size="small" appearance="subtle">
                        AI Improve
                      </Button>
                    </div>
                  </div>
                  <Editor
                    height="500px"
                    defaultLanguage="markdown"
                    value={promptContent}
                    onChange={(value) => setPromptContent(value || '')}
                    theme="vs-light"
                    options={{
                      minimap: { enabled: false },
                      fontSize: 14,
                      lineNumbers: 'on',
                      wordWrap: 'on',
                      padding: { top: 16, bottom: 16 },
                      scrollBeyondLastLine: false,
                      renderLineHighlight: 'all',
                      fontFamily: 'Consolas, Monaco, Courier New, monospace',
                    }}
                  />
                </div>
              )}

              {activeTab === 'variables' && (
                <div className="variables-section">
                  <div className="section-header">
                    <p className="section-description">
                      Define variables that can be dynamically replaced in your prompt
                    </p>
                    <Button icon={<AddRegular />} onClick={addVariable}>
                      Add Variable
                    </Button>
                  </div>

                  <div className="variables-list">
                    {variables.map((variable, idx) => (
                      <Card key={idx} className="variable-card">
                        <div className="variable-fields">
                          <div className="form-field">
                            <Label>Variable Name</Label>
                            <Input
                              value={variable.name}
                              onChange={(e) =>
                                updateVariable(idx, 'name', e.target.value)
                              }
                              placeholder="e.g., user_name"
                            />
                          </div>
                          <div className="form-field">
                            <Label>Description</Label>
                            <Input
                              value={variable.description}
                              onChange={(e) =>
                                updateVariable(idx, 'description', e.target.value)
                              }
                              placeholder="What this variable represents"
                            />
                          </div>
                          <div className="form-field">
                            <Label>Default Value</Label>
                            <Input
                              value={variable.defaultValue}
                              onChange={(e) =>
                                updateVariable(idx, 'defaultValue', e.target.value)
                              }
                              placeholder="Default value"
                            />
                          </div>
                        </div>
                        <Button
                          icon={<DeleteRegular />}
                          appearance="subtle"
                          onClick={() => removeVariable(idx)}
                        >
                          Remove
                        </Button>
                      </Card>
                    ))}
                  </div>
                </div>
              )}

              {activeTab === 'examples' && (
                <div className="examples-section">
                  <div className="section-header">
                    <p className="section-description">
                      Add few-shot examples to guide the model's responses
                    </p>
                    <Button icon={<AddRegular />}>Add Example</Button>
                  </div>
                  <div className="examples-placeholder">
                    <span className="placeholder-icon">💡</span>
                    <p>No examples yet. Add your first example to improve prompt accuracy.</p>
                  </div>
                </div>
              )}

              {activeTab === 'advanced' && (
                <div className="advanced-section">
                  <div className="advanced-settings">
                    <h3>Token Management</h3>
                    <div className="form-field">
                      <Label>Stop Sequences</Label>
                      <Input placeholder="Enter stop sequences (comma separated)" />
                    </div>
                    <div className="form-field">
                      <Label>Top P</Label>
                      <Input type="number" defaultValue="1.0" step="0.1" />
                    </div>
                    <div className="form-field">
                      <Label>Frequency Penalty</Label>
                      <Input type="number" defaultValue="0" step="0.1" />
                    </div>
                    <div className="form-field">
                      <Label>Presence Penalty</Label>
                      <Input type="number" defaultValue="0" step="0.1" />
                    </div>
                  </div>
                </div>
              )}
            </div>
          </Card>

          {/* Testing Panel */}
          <Card className="testing-panel">
            <div className="panel-header">
              <h3 className="panel-title">
                <PlayRegular /> Test Playground
              </h3>
              <Button
                icon={<PlayRegular />}
                appearance="primary"
                onClick={handleTest}
                disabled={testing}
              >
                {testing ? 'Testing...' : 'Run Test'}
              </Button>
            </div>

            <div className="testing-content">
              <div className="test-input-section">
                <Label>Test Input</Label>
                <Textarea
                  value={testInput}
                  onChange={(e) => setTestInput(e.target.value)}
                  placeholder="Enter your test input here..."
                  rows={4}
                  className="test-textarea"
                />
              </div>

              {testOutput && (
                <div className="test-output-section">
                  <Label>Response</Label>
                  <div className="test-output">
                    <pre>{testOutput}</pre>
                  </div>
                  <div className="test-metrics">
                    <span className="metric">⚡ 1.2s</span>
                    <span className="metric">📊 234 tokens</span>
                    <span className="metric">💰 $0.003</span>
                  </div>
                </div>
              )}
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}
