import { useState } from 'react'
import { toast } from 'react-toastify'
import './APIKeys.css'

const MOCK_API_KEYS = [
  {
    id: 'key-1',
    name: 'Production API Key',
    key: 'ak_prod_12345678901234567890',
    prefix: 'ak_prod_',
    created: '2024-01-15T10:30:00Z',
    lastUsed: '2024-12-04T11:30:00Z',
    requests: 45678,
    status: 'active',
    permissions: ['read', 'write', 'delete'],
    rateLimit: '1000/hour',
  },
  {
    id: 'key-2',
    name: 'Development API Key',
    key: 'ak_dev_98765432109876543210',
    prefix: 'ak_dev_',
    created: '2024-02-20T14:15:00Z',
    lastUsed: '2024-12-04T10:15:00Z',
    requests: 12345,
    status: 'active',
    permissions: ['read', 'write'],
    rateLimit: '500/hour',
  },
  {
    id: 'key-3',
    name: 'Mobile App Key',
    key: 'ak_mobile_11223344556677889900',
    prefix: 'ak_mobile_',
    created: '2024-03-10T09:00:00Z',
    lastUsed: '2024-11-30T16:45:00Z',
    requests: 8901,
    status: 'revoked',
    permissions: ['read'],
    rateLimit: '100/hour',
  },
]

const PERMISSIONS_OPTIONS = [
  { id: 'read', name: 'Read', description: 'View agents and data' },
  { id: 'write', name: 'Write', description: 'Create and update resources' },
  { id: 'delete', name: 'Delete', description: 'Delete resources' },
  { id: 'admin', name: 'Admin', description: 'Full administrative access' },
]

export default function APIKeys() {
  const [apiKeys, setApiKeys] = useState(MOCK_API_KEYS)
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [newKeyName, setNewKeyName] = useState('')
  const [selectedPermissions, setSelectedPermissions] = useState<string[]>(['read'])
  const [selectedRateLimit, setSelectedRateLimit] = useState('1000')
  const [generatedKey, setGeneratedKey] = useState<string | null>(null)

  const handleCreateKey = () => {
    const newKey = {
      id: `key-${Date.now()}`,
      name: newKeyName,
      key: `ak_${newKeyName.toLowerCase().replace(/\s+/g, '_')}_${Math.random().toString(36).substring(2, 22)}`,
      prefix: `ak_${newKeyName.toLowerCase().replace(/\s+/g, '_')}_`,
      created: new Date().toISOString(),
      lastUsed: null,
      requests: 0,
      status: 'active',
      permissions: selectedPermissions,
      rateLimit: `${selectedRateLimit}/hour`,
    }
    
    setApiKeys([...apiKeys, newKey as any])
    setGeneratedKey(newKey.key)
    toast.success('API Key created successfully!')
  }

  const handleRevokeKey = (keyId: string) => {
    if (confirm('Are you sure you want to revoke this API key? This action cannot be undone.')) {
      setApiKeys(apiKeys.map((key) => (key.id === keyId ? { ...key, status: 'revoked' } : key)))
      toast.success('API Key revoked')
    }
  }

  const handleCopyKey = (key: string) => {
    navigator.clipboard.writeText(key)
    toast.success('API Key copied to clipboard!')
  }

  const handleTogglePermission = (permission: string) => {
    if (selectedPermissions.includes(permission)) {
      setSelectedPermissions(selectedPermissions.filter((p) => p !== permission))
    } else {
      setSelectedPermissions([...selectedPermissions, permission])
    }
  }

  const totalRequests = apiKeys.reduce((sum, key) => sum + key.requests, 0)
  const activeKeys = apiKeys.filter((key) => key.status === 'active').length

  return (
    <div className="api-keys-page">
      {/* Header */}
      <div className="api-keys-header">
        <div>
          <h1 className="page-title">API Keys</h1>
          <p className="page-subtitle">
            Manage API keys for programmatic access to your agents
          </p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowCreateModal(true)}>
          <span className="btn-icon">➕</span>
          Create API Key
        </button>
      </div>

      {/* Stats */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon blue">🔑</div>
          <div>
            <div className="stat-value">{activeKeys}</div>
            <div className="stat-label">Active Keys</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon green">📊</div>
          <div>
            <div className="stat-value">{totalRequests.toLocaleString()}</div>
            <div className="stat-label">Total Requests</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon purple">⚡</div>
          <div>
            <div className="stat-value">99.9%</div>
            <div className="stat-label">Uptime</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon orange">🛡️</div>
          <div>
            <div className="stat-value">256-bit</div>
            <div className="stat-label">Encryption</div>
          </div>
        </div>
      </div>

      {/* API Keys List */}
      <div className="api-keys-list">
        {apiKeys.map((apiKey) => (
          <div key={apiKey.id} className="api-key-card card hover-lift">
            <div className="key-header">
              <div className="key-main-info">
                <h3 className="key-name">{apiKey.name}</h3>
                <span className={`status-badge ${apiKey.status === 'active' ? 'success' : 'secondary'}`}>
                  {apiKey.status === 'active' ? '● Active' : '○ Revoked'}
                </span>
              </div>
            </div>

            <div className="key-display">
              <code className="key-value">
                {apiKey.prefix}{'●'.repeat(20)}
              </code>
              <button
                className="btn-icon-only"
                onClick={() => handleCopyKey(apiKey.key)}
                title="Copy full key"
              >
                📋
              </button>
            </div>

            <div className="key-details">
              <div className="detail-row">
                <span className="detail-label">Created:</span>
                <span className="detail-value">
                  {new Date(apiKey.created).toLocaleDateString()}
                </span>
              </div>
              <div className="detail-row">
                <span className="detail-label">Last Used:</span>
                <span className="detail-value">
                  {apiKey.lastUsed
                    ? new Date(apiKey.lastUsed).toLocaleDateString()
                    : 'Never'}
                </span>
              </div>
              <div className="detail-row">
                <span className="detail-label">Requests:</span>
                <span className="detail-value">{apiKey.requests.toLocaleString()}</span>
              </div>
              <div className="detail-row">
                <span className="detail-label">Rate Limit:</span>
                <span className="detail-value">{apiKey.rateLimit}</span>
              </div>
            </div>

            <div className="key-permissions">
              <span className="permissions-label">Permissions:</span>
              <div className="permissions-tags">
                {apiKey.permissions.map((permission) => (
                  <span key={permission} className="permission-tag">
                    {permission}
                  </span>
                ))}
              </div>
            </div>

            <div className="key-actions">
              {apiKey.status === 'active' && (
                <button
                  className="btn btn-danger btn-sm"
                  onClick={() => handleRevokeKey(apiKey.id)}
                >
                  Revoke Key
                </button>
              )}
              <button className="btn btn-secondary btn-sm">View Details</button>
            </div>
          </div>
        ))}
      </div>

      {/* Create Modal */}
      {showCreateModal && (
        <div className="modal-overlay" onClick={() => !generatedKey && setShowCreateModal(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>{generatedKey ? 'API Key Created' : 'Create API Key'}</h2>
              <button
                className="modal-close"
                onClick={() => {
                  setShowCreateModal(false)
                  setGeneratedKey(null)
                  setNewKeyName('')
                  setSelectedPermissions(['read'])
                }}
              >
                ✕
              </button>
            </div>

            <div className="modal-body">
              {generatedKey ? (
                <div className="key-created">
                  <div className="alert alert-warning">
                    <span className="alert-icon">⚠️</span>
                    <div>
                      <strong>Save this key now!</strong>
                      <p>You won't be able to see it again after closing this dialog.</p>
                    </div>
                  </div>

                  <div className="generated-key-display">
                    <code>{generatedKey}</code>
                    <button
                      className="btn btn-secondary"
                      onClick={() => handleCopyKey(generatedKey)}
                    >
                      📋 Copy
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  <div className="form-group">
                    <label htmlFor="key-name">Key Name</label>
                    <input
                      type="text"
                      id="key-name"
                      className="form-input"
                      placeholder="e.g., Production API Key"
                      value={newKeyName}
                      onChange={(e) => setNewKeyName(e.target.value)}
                    />
                  </div>

                  <div className="form-group">
                    <label>Permissions</label>
                    <div className="permissions-checkboxes">
                      {PERMISSIONS_OPTIONS.map((permission) => (
                        <label key={permission.id} className="checkbox-label">
                          <input
                            type="checkbox"
                            checked={selectedPermissions.includes(permission.id)}
                            onChange={() => handleTogglePermission(permission.id)}
                          />
                          <div>
                            <strong>{permission.name}</strong>
                            <p>{permission.description}</p>
                          </div>
                        </label>
                      ))}
                    </div>
                  </div>

                  <div className="form-group">
                    <label htmlFor="rate-limit">Rate Limit (requests per hour)</label>
                    <select
                      id="rate-limit"
                      className="form-select"
                      value={selectedRateLimit}
                      onChange={(e) => setSelectedRateLimit(e.target.value)}
                    >
                      <option value="100">100/hour</option>
                      <option value="500">500/hour</option>
                      <option value="1000">1,000/hour</option>
                      <option value="5000">5,000/hour</option>
                      <option value="10000">10,000/hour</option>
                      <option value="unlimited">Unlimited</option>
                    </select>
                  </div>
                </>
              )}
            </div>

            <div className="modal-footer">
              {generatedKey ? (
                <button
                  className="btn btn-primary"
                  onClick={() => {
                    setShowCreateModal(false)
                    setGeneratedKey(null)
                    setNewKeyName('')
                    setSelectedPermissions(['read'])
                  }}
                >
                  Done
                </button>
              ) : (
                <>
                  <button
                    className="btn btn-secondary"
                    onClick={() => setShowCreateModal(false)}
                  >
                    Cancel
                  </button>
                  <button
                    className="btn btn-primary"
                    onClick={handleCreateKey}
                    disabled={!newKeyName || selectedPermissions.length === 0}
                  >
                    Create Key
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Documentation */}
      <div className="api-docs card">
        <h3 className="card-title">API Documentation</h3>
        <p className="card-subtitle">Quick reference for using the API</p>

        <div className="docs-section">
          <h4>Authentication</h4>
          <pre className="code-block">
{`curl -X GET https://api.agentstudio.com/v1/agents \\
  -H "Authorization: Bearer YOUR_API_KEY"`}
          </pre>
        </div>

        <div className="docs-section">
          <h4>Example Request</h4>
          <pre className="code-block">
{`POST /v1/agents/{id}/invoke
{
  "input": "Hello, how can I help you?",
  "debug": false
}`}
          </pre>
        </div>

        <button className="btn btn-secondary">
          View Full Documentation
        </button>
      </div>
    </div>
  )
}

