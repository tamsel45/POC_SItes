import { useState } from 'react'
import { toast } from 'react-toastify'
import './Deployments.css'

const MOCK_DEPLOYMENTS = [
  {
    id: 'deploy-1',
    agent: 'Customer Support Agent',
    agentId: 'agent-001',
    environment: 'production',
    version: 'v2.3.1',
    status: 'running',
    url: 'https://api.agentstudio.com/prod/agent-001',
    replicas: 3,
    cpu: '45%',
    memory: '62%',
    requests24h: 12456,
    uptime: '99.97%',
    deployedAt: '2024-11-28T14:30:00Z',
    deployedBy: 'admin@agentstudio.com',
  },
  {
    id: 'deploy-2',
    agent: 'Sales Lead Qualifier',
    agentId: 'agent-002',
    environment: 'staging',
    version: 'v1.5.0-beta',
    status: 'running',
    url: 'https://api.agentstudio.com/staging/agent-002',
    replicas: 2,
    cpu: '28%',
    memory: '41%',
    requests24h: 3456,
    uptime: '99.85%',
    deployedAt: '2024-12-03T10:15:00Z',
    deployedBy: 'dev@agentstudio.com',
  },
  {
    id: 'deploy-3',
    agent: 'HR Onboarding Assistant',
    agentId: 'agent-003',
    environment: 'development',
    version: 'v0.9.2-alpha',
    status: 'stopped',
    url: 'https://api.agentstudio.com/dev/agent-003',
    replicas: 1,
    cpu: '0%',
    memory: '0%',
    requests24h: 0,
    uptime: '0%',
    deployedAt: '2024-12-01T16:45:00Z',
    deployedBy: 'dev@agentstudio.com',
  },
]

const STATUS_COLORS: Record<string, string> = {
  running: 'success',
  stopped: 'secondary',
  deploying: 'warning',
  failed: 'danger',
}

const STATUS_ICONS: Record<string, string> = {
  running: '✓',
  stopped: '○',
  deploying: '⟳',
  failed: '✕',
}

export default function Deployments() {
  const [deployments] = useState(MOCK_DEPLOYMENTS)
  const [selectedEnv, setSelectedEnv] = useState('all')

  const filteredDeployments = deployments.filter(
    (d) => selectedEnv === 'all' || d.environment === selectedEnv
  )

  const runningCount = deployments.filter((d) => d.status === 'running').length
  const totalRequests = deployments.reduce((sum, d) => sum + d.requests24h, 0)

  const handleDeploy = (agentId: string) => {
    toast.info(`Deploying agent ${agentId}...`)
  }

  const handleStop = (deploymentId: string) => {
    if (confirm('Are you sure you want to stop this deployment?')) {
      toast.success('Deployment stopped')
    }
  }

  const handleRestart = (deploymentId: string) => {
    toast.info('Restarting deployment...')
  }

  return (
    <div className="deployments-page">
      {/* Header */}
      <div className="deployments-header">
        <div>
          <h1 className="page-title">Deployments</h1>
          <p className="page-subtitle">
            Manage agent deployments across environments
          </p>
        </div>
        <button className="btn btn-primary" onClick={() => handleDeploy('new')}>
          <span className="btn-icon">🚀</span>
          New Deployment
        </button>
      </div>

      {/* Stats */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon green">✓</div>
          <div>
            <div className="stat-value">{runningCount}</div>
            <div className="stat-label">Running</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon blue">📊</div>
          <div>
            <div className="stat-value">{totalRequests.toLocaleString()}</div>
            <div className="stat-label">Requests (24h)</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon purple">⚡</div>
          <div>
            <div className="stat-value">99.9%</div>
            <div className="stat-label">Avg Uptime</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon orange">🔄</div>
          <div>
            <div className="stat-value">{deployments.reduce((sum, d) => sum + d.replicas, 0)}</div>
            <div className="stat-label">Total Replicas</div>
          </div>
        </div>
      </div>

      {/* Environment Filter */}
      <div className="env-filter">
        <button
          className={`env-btn ${selectedEnv === 'all' ? 'active' : ''}`}
          onClick={() => setSelectedEnv('all')}
        >
          All Environments
        </button>
        <button
          className={`env-btn ${selectedEnv === 'production' ? 'active' : ''}`}
          onClick={() => setSelectedEnv('production')}
        >
          🟢 Production
        </button>
        <button
          className={`env-btn ${selectedEnv === 'staging' ? 'active' : ''}`}
          onClick={() => setSelectedEnv('staging')}
        >
          🟡 Staging
        </button>
        <button
          className={`env-btn ${selectedEnv === 'development' ? 'active' : ''}`}
          onClick={() => setSelectedEnv('development')}
        >
          🔵 Development
        </button>
      </div>

      {/* Deployments List */}
      <div className="deployments-list">
        {filteredDeployments.map((deployment) => (
          <div key={deployment.id} className="deployment-card card hover-lift">
            <div className="deployment-header">
              <div className="deployment-main-info">
                <h3 className="deployment-agent">{deployment.agent}</h3>
                <div className="deployment-meta">
                  <span className="env-badge env-{deployment.environment}">
                    {deployment.environment}
                  </span>
                  <span className="version-badge">{deployment.version}</span>
                </div>
              </div>
              <span className={`status-badge ${STATUS_COLORS[deployment.status]}`}>
                {STATUS_ICONS[deployment.status]} {deployment.status}
              </span>
            </div>

            <div className="deployment-url">
              <code>{deployment.url}</code>
              <button className="btn-icon-only" onClick={() => {
                navigator.clipboard.writeText(deployment.url)
                toast.success('URL copied!')
              }}>
                📋
              </button>
            </div>

            <div className="deployment-metrics">
              <div className="metric-item">
                <div className="metric-label">Replicas</div>
                <div className="metric-value">{deployment.replicas}</div>
              </div>
              <div className="metric-item">
                <div className="metric-label">CPU</div>
                <div className="metric-value">{deployment.cpu}</div>
              </div>
              <div className="metric-item">
                <div className="metric-label">Memory</div>
                <div className="metric-value">{deployment.memory}</div>
              </div>
              <div className="metric-item">
                <div className="metric-label">Uptime</div>
                <div className="metric-value">{deployment.uptime}</div>
              </div>
              <div className="metric-item">
                <div className="metric-label">Requests (24h)</div>
                <div className="metric-value">{deployment.requests24h.toLocaleString()}</div>
              </div>
            </div>

            <div className="deployment-footer">
              <div className="deployment-info">
                <span>
                  Deployed {new Date(deployment.deployedAt).toLocaleDateString()} by{' '}
                  {deployment.deployedBy}
                </span>
              </div>
              <div className="deployment-actions">
                {deployment.status === 'running' ? (
                  <>
                    <button
                      className="btn btn-secondary btn-sm"
                      onClick={() => handleRestart(deployment.id)}
                    >
                      🔄 Restart
                    </button>
                    <button
                      className="btn btn-danger btn-sm"
                      onClick={() => handleStop(deployment.id)}
                    >
                      ⏸️ Stop
                    </button>
                  </>
                ) : (
                  <button
                    className="btn btn-primary btn-sm"
                    onClick={() => handleDeploy(deployment.agentId)}
                  >
                    ▶️ Start
                  </button>
                )}
                <button className="btn btn-secondary btn-sm">View Logs</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

