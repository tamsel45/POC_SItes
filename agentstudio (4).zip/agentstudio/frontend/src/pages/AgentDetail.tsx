import { useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { toast } from 'react-toastify'
import { agentApi, promptApi, knowledgeBaseApi, analyticsApi } from '../services/api'
import './AgentDetail.css'

const FRAMEWORK_ICONS: Record<string, string> = {
  'Microsoft Copilot Studio': '🤖',
  'Amazon Bedrock': '🟠',
  'LangChain': '🦜',
  'Custom': '⚙️',
}

const STATUS_COLORS: Record<string, string> = {
  active: 'success',
  paused: 'warning',
  draft: 'secondary',
  error: 'danger',
}

export default function AgentDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const [activeTab, setActiveTab] = useState('overview')
  const [isEditing, setIsEditing] = useState(false)

  // Fetch agent details
  const { data: agentData, refetch: refetchAgent } = useQuery({
    queryKey: ['agent', id],
    queryFn: () => agentApi.get(id || ''),
  })

  const agent = agentData?.data

  // Fetch prompts
  const { data: promptsData } = useQuery({
    queryKey: ['prompts', id],
    queryFn: () => promptApi.list(id || ''),
    enabled: activeTab === 'prompts',
  })

  const prompts = promptsData?.data || []

  // Fetch knowledge base
  const { data: kbData } = useQuery({
    queryKey: ['kb', id],
    queryFn: () => knowledgeBaseApi.listDocuments(id || ''),
    enabled: activeTab === 'knowledge',
  })

  const documents = kbData?.data?.documents || []

  // Fetch analytics
  const { data: analyticsData } = useQuery({
    queryKey: ['analytics', id],
    queryFn: () => analyticsApi.get(id || ''),
    enabled: activeTab === 'analytics',
  })

  const analytics = analyticsData?.data

  const handleDelete = async () => {
    if (!confirm('Are you sure you want to delete this agent? This action cannot be undone.')) {
      return
    }

    try {
      await agentApi.delete(id || '')
      toast.success('Agent deleted successfully')
      navigate('/agents')
    } catch (error) {
      toast.error('Failed to delete agent')
    }
  }

  const handleStatusToggle = async () => {
    try {
      const newStatus = agent?.status === 'active' ? 'paused' : 'active'
      await agentApi.update(id || '', { status: newStatus })
      toast.success(`Agent ${newStatus}`)
      refetchAgent()
    } catch (error) {
      toast.error('Failed to update status')
    }
  }

  const handleDeploy = () => {
    toast.info('Deploy feature coming soon!')
  }

  if (!agent) {
    return (
      <div className="agent-detail-page">
        <div className="loading-state">
          <div className="spinner"></div>
          <p>Loading agent details...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="agent-detail-page">
      {/* Header */}
      <div className="detail-header">
        <button className="btn-back" onClick={() => navigate('/agents')}>
          ← Back to Agents
        </button>

        <div className="header-content">
          <div className="header-main">
            <div className="agent-icon">
              {FRAMEWORK_ICONS[agent.framework] || '🤖'}
            </div>
            <div className="header-info">
              <h1 className="agent-title">{agent.name}</h1>
              <p className="agent-subtitle">{agent.description}</p>
              <div className="agent-meta">
                <span className={`status-badge ${STATUS_COLORS[agent.status]}`}>
                  {agent.status === 'active' ? '● Active' : '○ Paused'}
                </span>
                <span className="meta-item">
                  <span className="meta-icon">👤</span>
                  Created by {agent.created_by}
                </span>
                <span className="meta-item">
                  <span className="meta-icon">📅</span>
                  {new Date(agent.created_at).toLocaleDateString()}
                </span>
              </div>
            </div>
          </div>

          <div className="header-actions">
            <button className="btn btn-secondary" onClick={() => navigate(`/testing?agent=${id}`)}>
              <span className="btn-icon">🧪</span>
              Test
            </button>
            <button className="btn btn-secondary" onClick={handleStatusToggle}>
              <span className="btn-icon">{agent.status === 'active' ? '⏸️' : '▶️'}</span>
              {agent.status === 'active' ? 'Pause' : 'Resume'}
            </button>
            <button className="btn btn-secondary" onClick={handleDeploy}>
              <span className="btn-icon">🚀</span>
              Deploy
            </button>
            <button className="btn btn-secondary" onClick={() => setIsEditing(!isEditing)}>
              <span className="btn-icon">✏️</span>
              Edit
            </button>
            <button className="btn btn-danger" onClick={handleDelete}>
              <span className="btn-icon">🗑️</span>
              Delete
            </button>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="quick-stats">
          <div className="stat-item">
            <div className="stat-value">{agent.conversation_count?.toLocaleString() || 0}</div>
            <div className="stat-label">Conversations</div>
          </div>
          <div className="stat-item">
            <div className="stat-value">{agent.success_rate?.toFixed(1) || 0}%</div>
            <div className="stat-label">Success Rate</div>
          </div>
          <div className="stat-item">
            <div className="stat-value">{agent.avg_response_time?.toFixed(1) || 0}s</div>
            <div className="stat-label">Avg Response</div>
          </div>
          <div className="stat-item">
            <div className="stat-value">{documents.length}</div>
            <div className="stat-label">Documents</div>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="detail-tabs">
        <button
          className={`tab ${activeTab === 'overview' ? 'active' : ''}`}
          onClick={() => setActiveTab('overview')}
        >
          <span className="tab-icon">📊</span>
          Overview
        </button>
        <button
          className={`tab ${activeTab === 'configuration' ? 'active' : ''}`}
          onClick={() => setActiveTab('configuration')}
        >
          <span className="tab-icon">⚙️</span>
          Configuration
        </button>
        <button
          className={`tab ${activeTab === 'prompts' ? 'active' : ''}`}
          onClick={() => setActiveTab('prompts')}
        >
          <span className="tab-icon">📝</span>
          Prompts ({prompts.length})
        </button>
        <button
          className={`tab ${activeTab === 'knowledge' ? 'active' : ''}`}
          onClick={() => setActiveTab('knowledge')}
        >
          <span className="tab-icon">🧠</span>
          Knowledge Base ({documents.length})
        </button>
        <button
          className={`tab ${activeTab === 'testing' ? 'active' : ''}`}
          onClick={() => setActiveTab('testing')}
        >
          <span className="tab-icon">🧪</span>
          Testing
        </button>
        <button
          className={`tab ${activeTab === 'analytics' ? 'active' : ''}`}
          onClick={() => setActiveTab('analytics')}
        >
          <span className="tab-icon">📈</span>
          Analytics
        </button>
        <button
          className={`tab ${activeTab === 'history' ? 'active' : ''}`}
          onClick={() => setActiveTab('history')}
        >
          <span className="tab-icon">🕐</span>
          History
        </button>
      </div>

      {/* Tab Content */}
      <div className="tab-content-wrapper">
        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div className="tab-content">
            <div className="content-grid">
              <div className="grid-col-2">
                <div className="card">
                  <h3 className="card-title">Agent Information</h3>
                  <div className="info-grid">
                    <div className="info-item">
                      <label>Framework</label>
                      <div className="info-value">
                        <span className="framework-badge">
                          {FRAMEWORK_ICONS[agent.framework]} {agent.framework}
                        </span>
                      </div>
                    </div>
                    <div className="info-item">
                      <label>Language Model</label>
                      <div className="info-value">{agent.language_model}</div>
                    </div>
                    <div className="info-item">
                      <label>Temperature</label>
                      <div className="info-value">{agent.temperature}</div>
                    </div>
                    <div className="info-item">
                      <label>Max Tokens</label>
                      <div className="info-value">{agent.max_tokens}</div>
                    </div>
                    <div className="info-item full-width">
                      <label>Description</label>
                      <div className="info-value">{agent.description}</div>
                    </div>
                    <div className="info-item full-width">
                      <label>Tags</label>
                      <div className="tags-list">
                        {agent.tags?.map((tag: string) => (
                          <span key={tag} className="tag-badge">
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="card">
                  <h3 className="card-title">Performance Metrics</h3>
                  <div className="metrics-grid">
                    <div className="metric-card">
                      <div className="metric-icon blue">💬</div>
                      <div className="metric-info">
                        <div className="metric-value">
                          {agent.conversation_count?.toLocaleString() || 0}
                        </div>
                        <div className="metric-label">Total Conversations</div>
                      </div>
                    </div>
                    <div className="metric-card">
                      <div className="metric-icon green">✓</div>
                      <div className="metric-info">
                        <div className="metric-value">{agent.success_rate?.toFixed(1) || 0}%</div>
                        <div className="metric-label">Success Rate</div>
                      </div>
                    </div>
                    <div className="metric-card">
                      <div className="metric-icon purple">⚡</div>
                      <div className="metric-info">
                        <div className="metric-value">
                          {agent.avg_response_time?.toFixed(2) || 0}s
                        </div>
                        <div className="metric-label">Avg Response Time</div>
                      </div>
                    </div>
                    <div className="metric-card">
                      <div className="metric-icon orange">📊</div>
                      <div className="metric-info">
                        <div className="metric-value">
                          {((agent.success_rate || 0) * 10).toFixed(0)}
                        </div>
                        <div className="metric-label">Quality Score</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="grid-col-1">
                <div className="card">
                  <h3 className="card-title">Recent Activity</h3>
                  <div className="activity-list">
                    <div className="activity-item">
                      <div className="activity-icon success">✓</div>
                      <div className="activity-content">
                        <div className="activity-title">Configuration updated</div>
                        <div className="activity-time">2 hours ago</div>
                      </div>
                    </div>
                    <div className="activity-item">
                      <div className="activity-icon info">💬</div>
                      <div className="activity-content">
                        <div className="activity-title">125 conversations processed</div>
                        <div className="activity-time">5 hours ago</div>
                      </div>
                    </div>
                    <div className="activity-item">
                      <div className="activity-icon warning">📄</div>
                      <div className="activity-content">
                        <div className="activity-title">Knowledge base updated</div>
                        <div className="activity-time">1 day ago</div>
                      </div>
                    </div>
                    <div className="activity-item">
                      <div className="activity-icon success">🚀</div>
                      <div className="activity-content">
                        <div className="activity-title">Deployed to production</div>
                        <div className="activity-time">3 days ago</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="card">
                  <h3 className="card-title">Quick Actions</h3>
                  <div className="quick-actions-grid">
                    <button
                      className="action-button"
                      onClick={() => navigate(`/testing?agent=${id}`)}
                    >
                      <span className="action-icon">🧪</span>
                      <span className="action-label">Test Agent</span>
                    </button>
                    <button
                      className="action-button"
                      onClick={() => navigate(`/prompts?agent=${id}`)}
                    >
                      <span className="action-icon">📝</span>
                      <span className="action-label">Edit Prompts</span>
                    </button>
                    <button
                      className="action-button"
                      onClick={() => navigate(`/knowledge-base/${id}`)}
                    >
                      <span className="action-icon">🧠</span>
                      <span className="action-label">Manage KB</span>
                    </button>
                    <button className="action-button" onClick={() => setActiveTab('analytics')}>
                      <span className="action-icon">📈</span>
                      <span className="action-label">View Analytics</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Configuration Tab */}
        {activeTab === 'configuration' && (
          <div className="tab-content">
            <div className="card">
              <h3 className="card-title">Model Configuration</h3>
              <div className="config-form">
                <div className="form-group">
                  <label htmlFor="model">Language Model</label>
                  <select id="model" className="form-select" defaultValue={agent.language_model}>
                    <option value="GPT-4 Turbo">GPT-4 Turbo</option>
                    <option value="GPT-4">GPT-4</option>
                    <option value="GPT-3.5 Turbo">GPT-3.5 Turbo</option>
                    <option value="Claude 2">Claude 2</option>
                    <option value="Claude Instant">Claude Instant</option>
                  </select>
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label htmlFor="temperature">
                      Temperature: <strong>{agent.temperature}</strong>
                    </label>
                    <input
                      type="range"
                      id="temperature"
                      min="0"
                      max="2"
                      step="0.1"
                      defaultValue={agent.temperature}
                      className="slider"
                    />
                    <div className="slider-labels">
                      <span>Precise (0)</span>
                      <span>Creative (2)</span>
                    </div>
                  </div>

                  <div className="form-group">
                    <label htmlFor="max-tokens">
                      Max Tokens: <strong>{agent.max_tokens}</strong>
                    </label>
                    <input
                      type="range"
                      id="max-tokens"
                      min="100"
                      max="4000"
                      step="100"
                      defaultValue={agent.max_tokens}
                      className="slider"
                    />
                    <div className="slider-labels">
                      <span>100</span>
                      <span>4000</span>
                    </div>
                  </div>
                </div>

                <div className="form-group">
                  <label htmlFor="system-prompt">System Prompt</label>
                  <textarea
                    id="system-prompt"
                    className="form-textarea"
                    rows={6}
                    placeholder="Enter system prompt..."
                    defaultValue="You are a helpful AI assistant..."
                  />
                </div>

                <div className="form-actions">
                  <button className="btn btn-secondary">Cancel</button>
                  <button className="btn btn-primary">Save Configuration</button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Prompts Tab */}
        {activeTab === 'prompts' && (
          <div className="tab-content">
            <div className="card">
              <div className="card-header-with-action">
                <h3 className="card-title">Prompts</h3>
                <button className="btn btn-primary" onClick={() => navigate(`/prompts?agent=${id}`)}>
                  <span className="btn-icon">➕</span>
                  Add Prompt
                </button>
              </div>

              {prompts.length === 0 ? (
                <div className="empty-state">
                  <span className="empty-icon">📝</span>
                  <h3>No prompts configured</h3>
                  <p>Add your first prompt to get started</p>
                  <button className="btn btn-primary" onClick={() => navigate(`/prompts?agent=${id}`)}>
                    Create Prompt
                  </button>
                </div>
              ) : (
                <div className="prompts-list">
                  {prompts.map((prompt: any) => (
                    <div key={prompt.id} className="prompt-item card hover-lift">
                      <div className="prompt-header">
                        <h4>{prompt.name}</h4>
                        <span className="version-badge">{prompt.version}</span>
                      </div>
                      <div className="prompt-preview">{prompt.content.substring(0, 200)}...</div>
                      <div className="prompt-footer">
                        <span className="prompt-meta">
                          Updated {new Date(prompt.updated_at).toLocaleDateString()}
                        </span>
                        <div className="prompt-actions">
                          <button className="btn-icon-only" title="Edit">
                            ✏️
                          </button>
                          <button className="btn-icon-only" title="Test">
                            🧪
                          </button>
                          <button className="btn-icon-only" title="Delete">
                            🗑️
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Knowledge Base Tab */}
        {activeTab === 'knowledge' && (
          <div className="tab-content">
            <div className="card">
              <div className="card-header-with-action">
                <h3 className="card-title">Knowledge Base Documents</h3>
                <button
                  className="btn btn-primary"
                  onClick={() => navigate(`/knowledge-base/${id}`)}
                >
                  <span className="btn-icon">📤</span>
                  Upload Documents
                </button>
              </div>

              {documents.length === 0 ? (
                <div className="empty-state">
                  <span className="empty-icon">📄</span>
                  <h3>No documents uploaded</h3>
                  <p>Upload documents to enhance your agent's knowledge</p>
                  <button
                    className="btn btn-primary"
                    onClick={() => navigate(`/knowledge-base/${id}`)}
                  >
                    Upload Files
                  </button>
                </div>
              ) : (
                <div className="documents-list">
                  {documents.map((doc: any) => (
                    <div key={doc.id} className="document-item hover-lift">
                      <div className="doc-icon">📄</div>
                      <div className="doc-info">
                        <div className="doc-name">{doc.name}</div>
                        <div className="doc-meta">
                          {(doc.size / 1024).toFixed(1)} KB • {doc.chunks} chunks • Uploaded{' '}
                          {new Date(doc.uploaded_at).toLocaleDateString()}
                        </div>
                      </div>
                      <span
                        className={`status-badge ${
                          doc.status === 'complete' ? 'success' : 'warning'
                        }`}
                      >
                        {doc.status === 'complete' ? '✓ Indexed' : '⏳ Processing'}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Testing Tab */}
        {activeTab === 'testing' && (
          <div className="tab-content">
            <div className="card">
              <h3 className="card-title">Quick Test</h3>
              <p className="card-subtitle">Test your agent with a quick message</p>

              <div className="test-interface">
                <div className="test-input-area">
                  <textarea
                    className="test-input"
                    placeholder="Enter your test message..."
                    rows={4}
                  />
                  <button className="btn btn-primary">
                    <span className="btn-icon">🚀</span>
                    Send Test
                  </button>
                </div>

                <div className="test-results">
                  <div className="result-placeholder">
                    <span className="placeholder-icon">💬</span>
                    <p>Response will appear here</p>
                  </div>
                </div>

                <button
                  className="btn btn-secondary btn-full"
                  onClick={() => navigate(`/testing?agent=${id}`)}
                >
                  Open Full Testing Console
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Analytics Tab */}
        {activeTab === 'analytics' && (
          <div className="tab-content">
            <div className="card">
              <h3 className="card-title">Performance Analytics</h3>

              <div className="analytics-grid">
                <div className="metric-card-large">
                  <div className="metric-header">
                    <span className="metric-icon-large">📊</span>
                    <span className="metric-title">Conversation Trends</span>
                  </div>
                  <div className="chart-placeholder">
                    <div className="placeholder-bars">
                      <div className="bar" style={{ height: '60%' }}></div>
                      <div className="bar" style={{ height: '80%' }}></div>
                      <div className="bar" style={{ height: '45%' }}></div>
                      <div className="bar" style={{ height: '90%' }}></div>
                      <div className="bar" style={{ height: '75%' }}></div>
                    </div>
                    <p>Last 7 days</p>
                  </div>
                </div>

                <div className="metric-card-large">
                  <div className="metric-header">
                    <span className="metric-icon-large">⏱️</span>
                    <span className="metric-title">Response Times</span>
                  </div>
                  <div className="chart-placeholder">
                    <div className="placeholder-line">
                      <svg viewBox="0 0 200 100" className="line-chart">
                        <polyline
                          points="0,80 40,50 80,60 120,30 160,40 200,20"
                          fill="none"
                          stroke="var(--color-primary)"
                          strokeWidth="3"
                        />
                      </svg>
                    </div>
                    <p>Average: {agent.avg_response_time?.toFixed(2)}s</p>
                  </div>
                </div>
              </div>

              <button
                className="btn btn-secondary btn-full"
                onClick={() => navigate(`/analytics?agent=${id}`)}
              >
                View Full Analytics
              </button>
            </div>
          </div>
        )}

        {/* History Tab */}
        {activeTab === 'history' && (
          <div className="tab-content">
            <div className="card">
              <h3 className="card-title">Change History</h3>

              <div className="timeline">
                <div className="timeline-item">
                  <div className="timeline-marker success"></div>
                  <div className="timeline-content">
                    <div className="timeline-header">
                      <strong>Configuration Updated</strong>
                      <span className="timeline-time">2 hours ago</span>
                    </div>
                    <div className="timeline-body">
                      Temperature changed from 0.5 to {agent.temperature} by {agent.created_by}
                    </div>
                  </div>
                </div>

                <div className="timeline-item">
                  <div className="timeline-marker info"></div>
                  <div className="timeline-content">
                    <div className="timeline-header">
                      <strong>Document Added</strong>
                      <span className="timeline-time">1 day ago</span>
                    </div>
                    <div className="timeline-body">
                      New document "Product_FAQ.pdf" uploaded to knowledge base
                    </div>
                  </div>
                </div>

                <div className="timeline-item">
                  <div className="timeline-marker warning"></div>
                  <div className="timeline-content">
                    <div className="timeline-header">
                      <strong>Agent Paused</strong>
                      <span className="timeline-time">2 days ago</span>
                    </div>
                    <div className="timeline-body">Agent temporarily paused for maintenance</div>
                  </div>
                </div>

                <div className="timeline-item">
                  <div className="timeline-marker success"></div>
                  <div className="timeline-content">
                    <div className="timeline-header">
                      <strong>Agent Created</strong>
                      <span className="timeline-time">
                        {new Date(agent.created_at).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="timeline-body">Agent created by {agent.created_by}</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
