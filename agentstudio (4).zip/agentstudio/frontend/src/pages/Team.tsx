import { useState } from 'react'
import { toast } from 'react-toastify'
import './Team.css'

const MOCK_TEAM_MEMBERS = [
  {
    id: 'user-1',
    name: 'Admin User',
    email: 'admin@agentstudio.com',
    role: 'admin',
    avatar: '👤',
    status: 'active',
    lastActive: '2024-12-04T11:30:00Z',
    joinedAt: '2024-01-01T00:00:00Z',
  },
  {
    id: 'user-2',
    name: 'John Developer',
    email: 'john@agentstudio.com',
    role: 'developer',
    avatar: '👨‍💻',
    status: 'active',
    lastActive: '2024-12-04T10:15:00Z',
    joinedAt: '2024-02-15T00:00:00Z',
  },
  {
    id: 'user-3',
    name: 'Sarah Manager',
    email: 'sarah@agentstudio.com',
    role: 'manager',
    avatar: '👩‍💼',
    status: 'active',
    lastActive: '2024-12-03T16:45:00Z',
    joinedAt: '2024-03-20T00:00:00Z',
  },
  {
    id: 'user-4',
    name: 'Mike Viewer',
    email: 'mike@agentstudio.com',
    role: 'viewer',
    avatar: '👁️',
    status: 'inactive',
    lastActive: '2024-11-28T14:20:00Z',
    joinedAt: '2024-06-10T00:00:00Z',
  },
]

const ROLES = [
  {
    id: 'admin',
    name: 'Admin',
    description: 'Full access to all features and settings',
    permissions: ['read', 'write', 'delete', 'admin'],
    color: 'red',
  },
  {
    id: 'manager',
    name: 'Manager',
    description: 'Manage agents, prompts, and team members',
    permissions: ['read', 'write', 'manage_team'],
    color: 'purple',
  },
  {
    id: 'developer',
    name: 'Developer',
    description: 'Create and modify agents and prompts',
    permissions: ['read', 'write'],
    color: 'blue',
  },
  {
    id: 'viewer',
    name: 'Viewer',
    description: 'View-only access to agents and analytics',
    permissions: ['read'],
    color: 'gray',
  },
]

export default function Team() {
  const [teamMembers] = useState(MOCK_TEAM_MEMBERS)
  const [showInviteModal, setShowInviteModal] = useState(false)
  const [inviteEmail, setInviteEmail] = useState('')
  const [inviteRole, setInviteRole] = useState('viewer')

  const handleInvite = () => {
    toast.success(`Invitation sent to ${inviteEmail}`)
    setShowInviteModal(false)
    setInviteEmail('')
    setInviteRole('viewer')
  }

  const handleRemoveMember = (memberId: string) => {
    if (confirm('Are you sure you want to remove this team member?')) {
      toast.success('Team member removed')
    }
  }

  const handleChangeRole = (memberId: string, newRole: string) => {
    toast.success(`Role updated to ${newRole}`)
  }

  return (
    <div className="team-page">
      {/* Header */}
      <div className="team-header">
        <div>
          <h1 className="page-title">Team & Access</h1>
          <p className="page-subtitle">
            Manage team members and their permissions
          </p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowInviteModal(true)}>
          <span className="btn-icon">➕</span>
          Invite Team Member
        </button>
      </div>

      {/* Stats */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon blue">👥</div>
          <div>
            <div className="stat-value">{teamMembers.length}</div>
            <div className="stat-label">Total Members</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon green">✓</div>
          <div>
            <div className="stat-value">
              {teamMembers.filter((m) => m.status === 'active').length}
            </div>
            <div className="stat-label">Active</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon purple">🔑</div>
          <div>
            <div className="stat-value">{ROLES.length}</div>
            <div className="stat-label">Roles</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon orange">📊</div>
          <div>
            <div className="stat-value">5</div>
            <div className="stat-label">Pending Invites</div>
          </div>
        </div>
      </div>

      <div className="team-content">
        {/* Team Members */}
        <div className="members-section">
          <h3 className="section-title">Team Members</h3>
          <div className="members-list">
            {teamMembers.map((member) => (
              <div key={member.id} className="member-card card hover-lift">
                <div className="member-avatar">{member.avatar}</div>
                <div className="member-info">
                  <div className="member-name">{member.name}</div>
                  <div className="member-email">{member.email}</div>
                  <div className="member-meta">
                    <span className={`status-badge ${member.status === 'active' ? 'success' : 'secondary'}`}>
                      {member.status === 'active' ? '● Active' : '○ Inactive'}
                    </span>
                    <span className="last-active">
                      Last active: {new Date(member.lastActive).toLocaleDateString()}
                    </span>
                  </div>
                </div>
                <div className="member-role">
                  <select
                    className="role-select"
                    value={member.role}
                    onChange={(e) => handleChangeRole(member.id, e.target.value)}
                    disabled={member.role === 'admin'}
                  >
                    {ROLES.map((role) => (
                      <option key={role.id} value={role.id}>
                        {role.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="member-actions">
                  {member.role !== 'admin' && (
                    <button
                      className="btn btn-danger btn-sm"
                      onClick={() => handleRemoveMember(member.id)}
                    >
                      Remove
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Roles Section */}
        <div className="roles-section">
          <h3 className="section-title">Roles & Permissions</h3>
          <div className="roles-grid">
            {ROLES.map((role) => (
              <div key={role.id} className="role-card card">
                <div className={`role-icon ${role.color}`}>🔑</div>
                <h4 className="role-name">{role.name}</h4>
                <p className="role-description">{role.description}</p>
                <div className="role-permissions">
                  {role.permissions.map((permission) => (
                    <span key={permission} className="permission-tag">
                      {permission.replace('_', ' ')}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Invite Modal */}
      {showInviteModal && (
        <div className="modal-overlay" onClick={() => setShowInviteModal(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Invite Team Member</h2>
              <button className="modal-close" onClick={() => setShowInviteModal(false)}>
                ✕
              </button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label htmlFor="invite-email">Email Address</label>
                <input
                  type="email"
                  id="invite-email"
                  className="form-input"
                  placeholder="colleague@company.com"
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e.target.value)}
                />
              </div>
              <div className="form-group">
                <label htmlFor="invite-role">Role</label>
                <select
                  id="invite-role"
                  className="form-select"
                  value={inviteRole}
                  onChange={(e) => setInviteRole(e.target.value)}
                >
                  {ROLES.map((role) => (
                    <option key={role.id} value={role.id}>
                      {role.name} - {role.description}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={() => setShowInviteModal(false)}>
                Cancel
              </button>
              <button
                className="btn btn-primary"
                onClick={handleInvite}
                disabled={!inviteEmail}
              >
                Send Invitation
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

