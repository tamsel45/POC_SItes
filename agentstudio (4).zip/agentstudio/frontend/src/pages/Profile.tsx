import { useState } from 'react'
import { useAuthStore } from '../store/authStore'
import { toast } from 'react-toastify'
import './Profile.css'

export default function Profile() {
  const { user } = useAuthStore()
  const [fullName, setFullName] = useState(user?.fullName || '')
  const [email, setEmail] = useState(user?.email || '')
  const [bio, setBio] = useState('AI Engineer passionate about building intelligent agents')
  const [company, setCompany] = useState('Agent Studio Inc.')
  const [location, setLocation] = useState('San Francisco, CA')
  const [website, setWebsite] = useState('https://agentstudio.com')

  const handleSave = () => {
    toast.success('Profile updated successfully!')
  }

  const handleUploadAvatar = () => {
    toast.info('Avatar upload coming soon!')
  }

  return (
    <div className="profile-page">
      {/* Header */}
      <div className="profile-header">
        <div>
          <h1 className="page-title">Profile Settings</h1>
          <p className="page-subtitle">Manage your personal information and preferences</p>
        </div>
      </div>

      <div className="profile-content">
        {/* Avatar Section */}
        <div className="profile-section card">
          <h3 className="section-title">Profile Photo</h3>
          <div className="avatar-section">
            <div className="avatar-display">
              <div className="avatar-large">👤</div>
            </div>
            <div className="avatar-actions">
              <button className="btn btn-secondary" onClick={handleUploadAvatar}>
                Upload Photo
              </button>
              <button className="btn btn-secondary">Remove</button>
              <p className="avatar-hint">JPG, PNG or GIF. Max size 5MB</p>
            </div>
          </div>
        </div>

        {/* Personal Information */}
        <div className="profile-section card">
          <h3 className="section-title">Personal Information</h3>
          
          <div className="form-row">
            <div className="form-group">
              <label htmlFor="full-name">Full Name</label>
              <input
                type="text"
                id="full-name"
                className="form-input"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
              />
            </div>

            <div className="form-group">
              <label htmlFor="email">Email Address</label>
              <input
                type="email"
                id="email"
                className="form-input"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
          </div>

          <div className="form-group">
            <label htmlFor="bio">Bio</label>
            <textarea
              id="bio"
              className="form-textarea"
              rows={3}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
            />
          </div>

          <div className="form-row">
            <div className="form-group">
              <label htmlFor="company">Company</label>
              <input
                type="text"
                id="company"
                className="form-input"
                value={company}
                onChange={(e) => setCompany(e.target.value)}
              />
            </div>

            <div className="form-group">
              <label htmlFor="location">Location</label>
              <input
                type="text"
                id="location"
                className="form-input"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
              />
            </div>
          </div>

          <div className="form-group">
            <label htmlFor="website">Website</label>
            <input
              type="url"
              id="website"
              className="form-input"
              value={website}
              onChange={(e) => setWebsite(e.target.value)}
            />
          </div>

          <div className="form-actions">
            <button className="btn btn-primary" onClick={handleSave}>
              Save Changes
            </button>
          </div>
        </div>

        {/* Activity Summary */}
        <div className="profile-section card">
          <h3 className="section-title">Activity Summary</h3>
          <div className="activity-stats">
            <div className="activity-stat">
              <div className="stat-icon blue">🤖</div>
              <div>
                <div className="stat-value">12</div>
                <div className="stat-label">Agents Created</div>
              </div>
            </div>
            <div className="activity-stat">
              <div className="stat-icon green">💬</div>
              <div>
                <div className="stat-value">45,678</div>
                <div className="stat-label">Conversations</div>
              </div>
            </div>
            <div className="activity-stat">
              <div className="stat-icon purple">📝</div>
              <div>
                <div className="stat-value">28</div>
                <div className="stat-label">Prompts</div>
              </div>
            </div>
            <div className="activity-stat">
              <div className="stat-icon orange">📊</div>
              <div>
                <div className="stat-value">156</div>
                <div className="stat-label">Tests Run</div>
              </div>
            </div>
          </div>
        </div>

        {/* Preferences */}
        <div className="profile-section card">
          <h3 className="section-title">Preferences</h3>
          
          <div className="preference-item">
            <div className="preference-info">
              <div className="preference-name">Email Digest</div>
              <div className="preference-description">
                Receive weekly summary of your agent performance
              </div>
            </div>
            <label className="toggle-switch">
              <input type="checkbox" defaultChecked />
              <span className="toggle-slider"></span>
            </label>
          </div>

          <div className="preference-item">
            <div className="preference-info">
              <div className="preference-name">Marketing Emails</div>
              <div className="preference-description">
                Get updates about new features and tips
              </div>
            </div>
            <label className="toggle-switch">
              <input type="checkbox" />
              <span className="toggle-slider"></span>
            </label>
          </div>

          <div className="preference-item">
            <div className="preference-info">
              <div className="preference-name">Public Profile</div>
              <div className="preference-description">
                Make your profile visible to other users
              </div>
            </div>
            <label className="toggle-switch">
              <input type="checkbox" />
              <span className="toggle-slider"></span>
            </label>
          </div>
        </div>

        {/* Danger Zone */}
        <div className="profile-section card danger-zone">
          <h3 className="section-title danger">Danger Zone</h3>
          
          <div className="danger-actions">
            <div className="danger-action-item">
              <div>
                <div className="danger-action-name">Delete Account</div>
                <div className="danger-action-description">
                  Permanently delete your account and all associated data
                </div>
              </div>
              <button className="btn btn-danger">Delete Account</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

