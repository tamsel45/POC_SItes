import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { toast } from 'react-toastify'
import { promptApi } from '../services/api'
import './PromptLibrary.css'

const PROMPT_CATEGORIES = [
  { id: 'all', name: 'All Prompts', icon: '📚' },
  { id: 'customer-service', name: 'Customer Service', icon: '💬' },
  { id: 'sales', name: 'Sales & Marketing', icon: '📈' },
  { id: 'hr', name: 'Human Resources', icon: '👥' },
  { id: 'technical', name: 'Technical Support', icon: '🔧' },
  { id: 'creative', name: 'Creative Writing', icon: '✍️' },
  { id: 'data-analysis', name: 'Data Analysis', icon: '📊' },
  { id: 'custom', name: 'Custom', icon: '⚙️' },
]

const TEMPLATE_LIBRARY = [
  {
    id: 'template-1',
    name: 'Customer Support Agent',
    category: 'customer-service',
    description: 'Handles customer inquiries with empathy and provides product information',
    preview: 'You are a helpful customer support agent. Your role is to assist customers with their questions and concerns...',
    tags: ['support', 'empathy', 'product-info'],
    uses: 1247,
    rating: 4.8,
  },
  {
    id: 'template-2',
    name: 'Sales Lead Qualifier',
    category: 'sales',
    description: 'Qualifies sales leads and schedules demos with potential customers',
    preview: 'You are an expert sales qualification agent. Your goal is to understand customer needs...',
    tags: ['sales', 'qualification', 'demos'],
    uses: 892,
    rating: 4.6,
  },
  {
    id: 'template-3',
    name: 'HR Onboarding Assistant',
    category: 'hr',
    description: 'Guides new employees through the onboarding process',
    preview: 'You are an HR onboarding specialist. Help new employees navigate their first days...',
    tags: ['onboarding', 'hr', 'employee'],
    uses: 654,
    rating: 4.9,
  },
  {
    id: 'template-4',
    name: 'Code Review Assistant',
    category: 'technical',
    description: 'Reviews code and provides constructive feedback',
    preview: 'You are a senior software engineer. Review code for best practices, security, and performance...',
    tags: ['code', 'review', 'technical'],
    uses: 1089,
    rating: 4.7,
  },
  {
    id: 'template-5',
    name: 'Content Writer',
    category: 'creative',
    description: 'Creates engaging marketing and blog content',
    preview: 'You are a creative content writer. Craft compelling stories and engaging content...',
    tags: ['content', 'writing', 'marketing'],
    uses: 756,
    rating: 4.5,
  },
  {
    id: 'template-6',
    name: 'Data Analyst',
    category: 'data-analysis',
    description: 'Analyzes data and provides insights',
    preview: 'You are a data analyst. Analyze datasets, identify trends, and provide actionable insights...',
    tags: ['data', 'analysis', 'insights'],
    uses: 523,
    rating: 4.8,
  },
]

export default function PromptLibrary() {
  const navigate = useNavigate()
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [searchQuery, setSearchQuery] = useState('')
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')
  const [showCreateModal, setShowCreateModal] = useState(false)

  const filteredTemplates = TEMPLATE_LIBRARY.filter((template) => {
    const matchesCategory = selectedCategory === 'all' || template.category === selectedCategory
    const matchesSearch =
      template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      template.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      template.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase()))
    return matchesCategory && matchesSearch
  })

  const handleUseTemplate = (templateId: string) => {
    const template = TEMPLATE_LIBRARY.find((t) => t.id === templateId)
    if (template) {
      toast.success(`Using template: ${template.name}`)
      navigate(`/prompts?template=${templateId}`)
    }
  }

  return (
    <div className="prompt-library-page">
      {/* Header */}
      <div className="library-header">
        <div>
          <h1 className="page-title">Prompt Library</h1>
          <p className="page-subtitle">
            Browse and use pre-built prompt templates for various use cases
          </p>
        </div>
        <div className="header-actions">
          <button className="btn btn-secondary" onClick={() => navigate('/prompts')}>
            <span className="btn-icon">📝</span>
            My Prompts
          </button>
          <button className="btn btn-primary" onClick={() => setShowCreateModal(true)}>
            <span className="btn-icon">➕</span>
            Create Custom Prompt
          </button>
        </div>
      </div>

      {/* Stats Bar */}
      <div className="stats-bar">
        <div className="stat-item">
          <span className="stat-icon">📚</span>
          <div>
            <div className="stat-value">{TEMPLATE_LIBRARY.length}</div>
            <div className="stat-label">Templates</div>
          </div>
        </div>
        <div className="stat-item">
          <span className="stat-icon">📂</span>
          <div>
            <div className="stat-value">{PROMPT_CATEGORIES.length - 1}</div>
            <div className="stat-label">Categories</div>
          </div>
        </div>
        <div className="stat-item">
          <span className="stat-icon">⭐</span>
          <div>
            <div className="stat-value">4.7</div>
            <div className="stat-label">Avg Rating</div>
          </div>
        </div>
        <div className="stat-item">
          <span className="stat-icon">👥</span>
          <div>
            <div className="stat-value">
              {TEMPLATE_LIBRARY.reduce((sum, t) => sum + t.uses, 0).toLocaleString()}
            </div>
            <div className="stat-label">Total Uses</div>
          </div>
        </div>
      </div>

      <div className="library-content">
        {/* Sidebar Categories */}
        <div className="library-sidebar">
          <div className="sidebar-section">
            <h3 className="sidebar-title">Categories</h3>
            <div className="category-list">
              {PROMPT_CATEGORIES.map((category) => {
                const count =
                  category.id === 'all'
                    ? TEMPLATE_LIBRARY.length
                    : TEMPLATE_LIBRARY.filter((t) => t.category === category.id).length
                return (
                  <button
                    key={category.id}
                    className={`category-item ${selectedCategory === category.id ? 'active' : ''}`}
                    onClick={() => setSelectedCategory(category.id)}
                  >
                    <span className="category-icon">{category.icon}</span>
                    <span className="category-name">{category.name}</span>
                    <span className="category-count">{count}</span>
                  </button>
                )
              })}
            </div>
          </div>

          <div className="sidebar-section">
            <h3 className="sidebar-title">Popular Tags</h3>
            <div className="tags-cloud">
              {['support', 'sales', 'onboarding', 'code', 'writing', 'data', 'empathy', 'technical'].map(
                (tag) => (
                  <button key={tag} className="tag-cloud-item">
                    {tag}
                  </button>
                )
              )}
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="library-main">
          {/* Search & Controls */}
          <div className="library-controls">
            <div className="search-box">
              <span className="search-icon">🔍</span>
              <input
                type="text"
                placeholder="Search prompts..."
                className="search-input"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            <div className="view-controls">
              <button
                className={`view-btn ${viewMode === 'grid' ? 'active' : ''}`}
                onClick={() => setViewMode('grid')}
                title="Grid view"
              >
                ⊞
              </button>
              <button
                className={`view-btn ${viewMode === 'list' ? 'active' : ''}`}
                onClick={() => setViewMode('list')}
                title="List view"
              >
                ☰
              </button>
            </div>
          </div>

          {/* Results Count */}
          <div className="results-info">
            <span>
              {filteredTemplates.length} template{filteredTemplates.length !== 1 ? 's' : ''} found
            </span>
          </div>

          {/* Templates Grid/List */}
          {filteredTemplates.length === 0 ? (
            <div className="empty-state">
              <span className="empty-icon">📚</span>
              <h3>No templates found</h3>
              <p>Try adjusting your search or category filter</p>
            </div>
          ) : (
            <div className={`templates-${viewMode}`}>
              {filteredTemplates.map((template) => (
                <div key={template.id} className="template-card card hover-lift">
                  <div className="template-header">
                    <div className="template-category">
                      {PROMPT_CATEGORIES.find((c) => c.id === template.category)?.icon}{' '}
                      {PROMPT_CATEGORIES.find((c) => c.id === template.category)?.name}
                    </div>
                    <div className="template-rating">
                      <span className="rating-stars">⭐</span>
                      <span className="rating-value">{template.rating}</span>
                    </div>
                  </div>

                  <h3 className="template-name">{template.name}</h3>
                  <p className="template-description">{template.description}</p>

                  <div className="template-preview">
                    <code>{template.preview.substring(0, 100)}...</code>
                  </div>

                  <div className="template-tags">
                    {template.tags.map((tag) => (
                      <span key={tag} className="tag-badge">
                        {tag}
                      </span>
                    ))}
                  </div>

                  <div className="template-footer">
                    <span className="template-uses">
                      <span className="uses-icon">👥</span>
                      {template.uses.toLocaleString()} uses
                    </span>
                    <button
                      className="btn btn-primary btn-sm"
                      onClick={() => handleUseTemplate(template.id)}
                    >
                      Use Template
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Create Modal (Simple placeholder) */}
      {showCreateModal && (
        <div className="modal-overlay" onClick={() => setShowCreateModal(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Create Custom Prompt</h2>
              <button className="modal-close" onClick={() => setShowCreateModal(false)}>
                ✕
              </button>
            </div>
            <div className="modal-body">
              <p>This will redirect you to the Prompt Studio...</p>
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={() => setShowCreateModal(false)}>
                Cancel
              </button>
              <button
                className="btn btn-primary"
                onClick={() => {
                  setShowCreateModal(false)
                  navigate('/prompts')
                }}
              >
                Go to Prompt Studio
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

