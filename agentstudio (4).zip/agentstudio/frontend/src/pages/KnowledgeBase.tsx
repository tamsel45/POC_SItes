import { useCallback, useState } from 'react'
import { useParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { useDropzone } from 'react-dropzone'
import { toast } from 'react-toastify'
import { knowledgeBaseApi } from '../services/api'
import './KnowledgeBase.css'

const FILE_ICONS: Record<string, string> = {
  pdf: '📄',
  docx: '📝',
  txt: '📃',
  md: '📋',
  html: '🌐',
  csv: '📊',
}

export default function KnowledgeBase() {
  const { id } = useParams()
  const [activeTab, setActiveTab] = useState('documents')
  const [selectedDocs, setSelectedDocs] = useState<string[]>([])
  const [searchQuery, setSearchQuery] = useState('')
  const [filterType, setFilterType] = useState('all')

  // Chunking settings
  const [chunkSize, setChunkSize] = useState(500)
  const [chunkOverlap, setChunkOverlap] = useState(50)

  // Fetch documents
  const { data: docsData, refetch: refetchDocs } = useQuery({
    queryKey: ['knowledge-base-docs', id || 'default'],
    queryFn: () => knowledgeBaseApi.listDocuments(id || 'agent-001'),
  })

  const docs = docsData?.data?.documents || []
  const totalSize = docsData?.data?.total_size || 0

  // Fetch KB stats
  const { data: statsData } = useQuery({
    queryKey: ['kb-stats', id || 'default'],
    queryFn: () => knowledgeBaseApi.getStats(id || 'agent-001'),
  })

  const kbStats = statsData?.data

  // File upload
  const onDrop = useCallback(
    async (acceptedFiles: File[]) => {
      try {
        const options = {
          chunk_size: chunkSize,
          chunk_overlap: chunkOverlap,
          auto_index: true,
        }

        await knowledgeBaseApi.upload(id || 'agent-001', acceptedFiles, options)
        toast.success(`${acceptedFiles.length} file(s) uploaded successfully!`)
        refetchDocs()
      } catch (error) {
        console.error('Upload error:', error)
        toast.error('Upload failed')
      }
    },
    [id, chunkSize, chunkOverlap, refetchDocs]
  )

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
      'text/plain': ['.txt'],
      'text/markdown': ['.md'],
      'text/html': ['.html'],
      'text/csv': ['.csv'],
    },
    maxSize: 26214400, // 25MB
  })

  const handleDelete = async (docId: string) => {
    if (!confirm('Are you sure you want to delete this document?')) return

    try {
      await knowledgeBaseApi.delete(docId)
      toast.success('Document deleted')
      refetchDocs()
    } catch (error) {
      toast.error('Delete failed')
    }
  }

  const handleReindex = async (docId: string) => {
    try {
      await knowledgeBaseApi.reindex(docId)
      toast.success('Reindexing started')
      refetchDocs()
    } catch (error) {
      toast.error('Reindex failed')
    }
  }

  const filteredDocs = docs.filter((doc: any) => {
    const matchesSearch = doc.name.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesType = filterType === 'all' || doc.type === filterType
    return matchesSearch && matchesType
  })

  return (
    <div className="knowledge-base-page">
      {/* Header */}
      <div className="kb-header">
        <div>
          <h1 className="page-title">Knowledge Base</h1>
          <p className="page-subtitle">
            Manage documents and data sources for your AI agents
          </p>
        </div>
        <div className="header-actions">
          <button className="btn btn-secondary">
            <span className="btn-icon">🔗</span>
            Connect SharePoint
          </button>
          <button className="btn btn-secondary">
            <span className="btn-icon">🌐</span>
            Crawl Website
          </button>
          <button className="btn btn-primary">
            <span className="btn-icon">📤</span>
            Upload Files
          </button>
        </div>
      </div>

      {/* Stats Dashboard */}
      {kbStats && (
        <div className="stats-dashboard">
          <div className="stat-card hover-lift">
            <div className="stat-icon-wrapper blue">
              <span className="stat-icon">📄</span>
            </div>
            <div className="stat-content">
              <div className="stat-label">Total Documents</div>
              <div className="stat-value">{kbStats.total_documents}</div>
            </div>
          </div>

          <div className="stat-card hover-lift">
            <div className="stat-icon-wrapper green">
              <span className="stat-icon">🧩</span>
            </div>
            <div className="stat-content">
              <div className="stat-label">Total Chunks</div>
              <div className="stat-value">{kbStats.total_chunks}</div>
            </div>
          </div>

          <div className="stat-card hover-lift">
            <div className="stat-icon-wrapper purple">
              <span className="stat-icon">🔗</span>
            </div>
            <div className="stat-content">
              <div className="stat-label">Embedding Model</div>
              <div className="stat-value-small">{kbStats.embedding_model}</div>
            </div>
          </div>

          <div className="stat-card hover-lift">
            <div className="stat-icon-wrapper orange">
              <span className="stat-icon">⚡</span>
            </div>
            <div className="stat-content">
              <div className="stat-label">Avg Retrieval Time</div>
              <div className="stat-value">{kbStats.avg_retrieval_time}s</div>
            </div>
          </div>
        </div>
      )}

      {/* Upload Area */}
      <div className="upload-card card">
        <div {...getRootProps()} className={`dropzone ${isDragActive ? 'active' : ''}`}>
          <input {...getInputProps()} />
          <div className="dropzone-content">
            <span className="dropzone-icon">📤</span>
            <h3 className="dropzone-title">
              {isDragActive ? 'Drop files here...' : 'Upload Documents'}
            </h3>
            <p className="dropzone-text">
              Drag and drop files here, or click to browse
            </p>
            <div className="dropzone-formats">
              <span className="format-badge">📄 PDF</span>
              <span className="format-badge">📝 DOCX</span>
              <span className="format-badge">📃 TXT</span>
              <span className="format-badge">📋 MD</span>
              <span className="format-badge">🌐 HTML</span>
              <span className="format-badge">📊 CSV</span>
            </div>
            <span className="dropzone-limit">Max file size: 25 MB per file</span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="kb-main">
        <div className="kb-content-card card">
          {/* Tabs & Controls */}
          <div className="content-header">
            <div className="tab-list">
              <button
                className={`tab ${activeTab === 'documents' ? 'active' : ''}`}
                onClick={() => setActiveTab('documents')}
              >
                <span className="tab-icon">📄</span>
                Documents ({docs.length})
              </button>
              <button
                className={`tab ${activeTab === 'connections' ? 'active' : ''}`}
                onClick={() => setActiveTab('connections')}
              >
                <span className="tab-icon">🔗</span>
                Data Connections
              </button>
              <button
                className={`tab ${activeTab === 'settings' ? 'active' : ''}`}
                onClick={() => setActiveTab('settings')}
              >
                <span className="tab-icon">⚙️</span>
                Settings
              </button>
            </div>

            {activeTab === 'documents' && (
              <div className="content-controls">
                <div className="search-box">
                  <span className="search-icon">🔍</span>
                  <input
                    type="text"
                    placeholder="Search documents..."
                    className="search-input"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <select
                  className="filter-select"
                  value={filterType}
                  onChange={(e) => setFilterType(e.target.value)}
                >
                  <option value="all">All Types</option>
                  <option value="pdf">PDF</option>
                  <option value="docx">Word</option>
                  <option value="txt">Text</option>
                  <option value="md">Markdown</option>
                </select>
                <button className="btn btn-secondary">
                  <span className="btn-icon">🔽</span>
                  Filters
                </button>
              </div>
            )}
          </div>

          {/* Tab Content */}
          <div className="tab-content">
            {activeTab === 'documents' && (
              <div className="documents-tab">
                {filteredDocs.length === 0 ? (
                  <div className="empty-state">
                    <span className="empty-icon">📄</span>
                    <h3>No documents yet</h3>
                    <p>Upload your first document to get started</p>
                  </div>
                ) : (
                  <div className="documents-list">
                    {filteredDocs.map((doc: any) => (
                      <div key={doc.id} className="document-item hover-lift">
                        <div className="doc-icon">{FILE_ICONS[doc.type] || '📄'}</div>
                        <div className="doc-info">
                          <div className="doc-name">{doc.name}</div>
                          <div className="doc-meta">
                            <span>{(doc.size / 1024).toFixed(1)} KB</span>
                            <span>•</span>
                            <span>{doc.chunks} chunks</span>
                            <span>•</span>
                            <span>
                              Uploaded {new Date(doc.uploaded_at).toLocaleDateString()}
                            </span>
                          </div>
                        </div>
                        <div className="doc-status">
                          <span
                            className={`status-badge ${
                              doc.status === 'complete' ? 'success' : 'warning'
                            }`}
                          >
                            {doc.status === 'complete' ? '✓ Indexed' : '⏳ Processing'}
                          </span>
                        </div>
                        <div className="doc-actions">
                          <button
                            className="btn-icon-only"
                            onClick={() => handleReindex(doc.id)}
                            title="Reindex"
                          >
                            🔄
                          </button>
                          <button
                            className="btn-icon-only"
                            onClick={() => handleDelete(doc.id)}
                            title="Delete"
                          >
                            🗑️
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'connections' && (
              <div className="connections-tab">
                <div className="connections-grid">
                  <div className="connection-card card hover-lift">
                    <div className="connection-icon">🔗</div>
                    <h3>SharePoint</h3>
                    <p>Connect to SharePoint sites and sync documents</p>
                    <button className="btn btn-primary">Connect</button>
                  </div>

                  <div className="connection-card card hover-lift">
                    <div className="connection-icon">🌐</div>
                    <h3>Web Crawler</h3>
                    <p>Crawl websites and extract content</p>
                    <button className="btn btn-primary">Configure</button>
                  </div>

                  <div className="connection-card card hover-lift">
                    <div className="connection-icon">🗄️</div>
                    <h3>Database</h3>
                    <p>Connect to SQL databases and query data</p>
                    <button className="btn btn-primary">Connect</button>
                  </div>

                  <div className="connection-card card hover-lift">
                    <div className="connection-icon">☁️</div>
                    <h3>Cloud Storage</h3>
                    <p>Sync from S3, Azure Blob, or Google Cloud Storage</p>
                    <button className="btn btn-primary">Connect</button>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'settings' && (
              <div className="settings-tab">
                <div className="settings-section">
                  <h3 className="section-title">Chunking Strategy</h3>
                  <div className="form-group">
                    <label htmlFor="chunk-size">
                      Chunk Size: <strong>{chunkSize}</strong> tokens
                    </label>
                    <input
                      type="range"
                      id="chunk-size"
                      min="100"
                      max="2000"
                      step="100"
                      value={chunkSize}
                      onChange={(e) => setChunkSize(Number(e.target.value))}
                      className="slider"
                    />
                    <div className="slider-labels">
                      <span>100</span>
                      <span>2000</span>
                    </div>
                  </div>

                  <div className="form-group">
                    <label htmlFor="chunk-overlap">
                      Chunk Overlap: <strong>{chunkOverlap}</strong> tokens
                    </label>
                    <input
                      type="range"
                      id="chunk-overlap"
                      min="0"
                      max="200"
                      step="10"
                      value={chunkOverlap}
                      onChange={(e) => setChunkOverlap(Number(e.target.value))}
                      className="slider"
                    />
                    <div className="slider-labels">
                      <span>0</span>
                      <span>200</span>
                    </div>
                  </div>
                </div>

                <div className="settings-section">
                  <h3 className="section-title">Embeddings</h3>
                  <div className="form-group">
                    <label htmlFor="embedding-model">Embedding Model</label>
                    <select id="embedding-model" className="form-select">
                      <option value="text-embedding-ada-002">
                        text-embedding-ada-002 (OpenAI)
                      </option>
                      <option value="text-embedding-3-small">
                        text-embedding-3-small (OpenAI)
                      </option>
                      <option value="text-embedding-3-large">
                        text-embedding-3-large (OpenAI)
                      </option>
                    </select>
                  </div>

                  <div className="form-group">
                    <label htmlFor="vector-store">Vector Store</label>
                    <select id="vector-store" className="form-select">
                      <option value="pinecone">Pinecone</option>
                      <option value="weaviate">Weaviate</option>
                      <option value="qdrant">Qdrant</option>
                      <option value="chromadb">ChromaDB</option>
                    </select>
                  </div>
                </div>

                <div className="settings-actions">
                  <button className="btn btn-secondary">Cancel</button>
                  <button className="btn btn-primary">Save Settings</button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
