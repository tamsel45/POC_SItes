import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { toast } from 'react-toastify'
import './Logs.css'

const LOG_LEVELS = ['all', 'info', 'warning', 'error', 'debug']

const MOCK_LOGS = [
  {
    id: 'log-1',
    timestamp: '2024-12-04T12:30:45.123Z',
    level: 'info',
    agent: 'Customer Support Agent',
    agentId: 'agent-001',
    message: 'Agent invoked successfully',
    metadata: {
      requestId: 'req-abc123',
      userId: 'user-456',
      latency: 1.8,
      tokensIn: 125,
      tokensOut: 89,
    },
    trace: {
      id: 'trace-001',
      spans: 5,
      duration: 2100,
    },
  },
  {
    id: 'log-2',
    timestamp: '2024-12-04T12:30:42.456Z',
    level: 'warning',
    agent: 'Sales Lead Qualifier',
    agentId: 'agent-002',
    message: 'High latency detected (>3s)',
    metadata: {
      requestId: 'req-def456',
      userId: 'user-789',
      latency: 3.5,
      tokensIn: 200,
      tokensOut: 150,
    },
    trace: {
      id: 'trace-002',
      spans: 7,
      duration: 3500,
    },
  },
  {
    id: 'log-3',
    timestamp: '2024-12-04T12:30:38.789Z',
    level: 'error',
    agent: 'HR Onboarding Assistant',
    agentId: 'agent-003',
    message: 'Knowledge base query failed',
    metadata: {
      requestId: 'req-ghi789',
      userId: 'user-012',
      error: 'Connection timeout to vector store',
      stackTrace: 'Error: ETIMEDOUT...',
    },
    trace: {
      id: 'trace-003',
      spans: 3,
      duration: 5000,
    },
  },
  {
    id: 'log-4',
    timestamp: '2024-12-04T12:30:35.234Z',
    level: 'debug',
    agent: 'Customer Support Agent',
    agentId: 'agent-001',
    message: 'Retrieved 5 documents from knowledge base',
    metadata: {
      requestId: 'req-jkl012',
      query: 'return policy',
      results: 5,
      topScore: 0.94,
    },
    trace: {
      id: 'trace-004',
      spans: 4,
      duration: 450,
    },
  },
  {
    id: 'log-5',
    timestamp: '2024-12-04T12:30:30.567Z',
    level: 'info',
    agent: 'Sales Lead Qualifier',
    agentId: 'agent-002',
    message: 'Lead qualification completed',
    metadata: {
      requestId: 'req-mno345',
      leadScore: 85,
      qualification: 'high-priority',
      nextAction: 'schedule-demo',
    },
    trace: {
      id: 'trace-005',
      spans: 6,
      duration: 1900,
    },
  },
]

const LEVEL_COLORS: Record<string, string> = {
  info: 'blue',
  warning: 'orange',
  error: 'red',
  debug: 'purple',
}

const LEVEL_ICONS: Record<string, string> = {
  info: 'ℹ️',
  warning: '⚠️',
  error: '❌',
  debug: '🐛',
}

export default function Logs() {
  const [selectedLevel, setSelectedLevel] = useState('all')
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedLog, setSelectedLog] = useState<typeof MOCK_LOGS[0] | null>(null)
  const [timeRange, setTimeRange] = useState('1h')

  const filteredLogs = MOCK_LOGS.filter((log) => {
    const matchesLevel = selectedLevel === 'all' || log.level === selectedLevel
    const matchesSearch =
      log.message.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.agent.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.metadata.requestId?.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesLevel && matchesSearch
  })

  const handleExport = () => {
    toast.success('Exporting logs...')
  }

  const handleViewTrace = (traceId: string) => {
    toast.info(`Opening trace: ${traceId}`)
  }

  return (
    <div className="logs-page">
      {/* Header */}
      <div className="logs-header">
        <div>
          <h1 className="page-title">Logs & Traces</h1>
          <p className="page-subtitle">
            Monitor real-time logs and distributed traces for debugging
          </p>
        </div>
        <div className="header-actions">
          <button className="btn btn-secondary" onClick={handleExport}>
            <span className="btn-icon">📥</span>
            Export Logs
          </button>
          <button className="btn btn-primary">
            <span className="btn-icon">⚙️</span>
            Configure
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="logs-stats">
        <div className="stat-card">
          <div className="stat-icon blue">ℹ️</div>
          <div>
            <div className="stat-value">{MOCK_LOGS.filter((l) => l.level === 'info').length}</div>
            <div className="stat-label">Info</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon orange">⚠️</div>
          <div>
            <div className="stat-value">
              {MOCK_LOGS.filter((l) => l.level === 'warning').length}
            </div>
            <div className="stat-label">Warnings</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon red">❌</div>
          <div>
            <div className="stat-value">{MOCK_LOGS.filter((l) => l.level === 'error').length}</div>
            <div className="stat-label">Errors</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon purple">🐛</div>
          <div>
            <div className="stat-value">{MOCK_LOGS.filter((l) => l.level === 'debug').length}</div>
            <div className="stat-label">Debug</div>
          </div>
        </div>
      </div>

      <div className="logs-content">
        {/* Filters */}
        <div className="logs-filters card">
          <div className="filter-group">
            <label>Level</label>
            <div className="level-buttons">
              {LOG_LEVELS.map((level) => (
                <button
                  key={level}
                  className={`level-btn ${selectedLevel === level ? 'active' : ''}`}
                  onClick={() => setSelectedLevel(level)}
                >
                  {level === 'all' ? '📊' : LEVEL_ICONS[level]} {level}
                </button>
              ))}
            </div>
          </div>

          <div className="filter-group">
            <label>Time Range</label>
            <select
              className="form-select"
              value={timeRange}
              onChange={(e) => setTimeRange(e.target.value)}
            >
              <option value="5m">Last 5 minutes</option>
              <option value="15m">Last 15 minutes</option>
              <option value="1h">Last hour</option>
              <option value="6h">Last 6 hours</option>
              <option value="24h">Last 24 hours</option>
              <option value="7d">Last 7 days</option>
            </select>
          </div>

          <div className="filter-group flex-1">
            <label>Search</label>
            <div className="search-box">
              <span className="search-icon">🔍</span>
              <input
                type="text"
                placeholder="Search logs by message, agent, or request ID..."
                className="search-input"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>

          <div className="filter-actions">
            <button className="btn btn-secondary btn-sm">
              <span className="btn-icon">🔄</span>
              Refresh
            </button>
            <button className="btn btn-secondary btn-sm">
              <span className="btn-icon">⏸️</span>
              Pause
            </button>
          </div>
        </div>

        {/* Logs List */}
        <div className="logs-main">
          <div className="logs-list-container card">
            <div className="logs-list-header">
              <h3>Logs ({filteredLogs.length})</h3>
              <span className="live-indicator">
                <span className="pulse"></span>
                Live
              </span>
            </div>

            <div className="logs-list">
              {filteredLogs.length === 0 ? (
                <div className="empty-state">
                  <span className="empty-icon">📋</span>
                  <h3>No logs found</h3>
                  <p>Try adjusting your filters</p>
                </div>
              ) : (
                filteredLogs.map((log) => (
                  <div
                    key={log.id}
                    className={`log-item ${selectedLog?.id === log.id ? 'selected' : ''}`}
                    onClick={() => setSelectedLog(log)}
                  >
                    <div className="log-main">
                      <span className={`log-level ${LEVEL_COLORS[log.level]}`}>
                        {LEVEL_ICONS[log.level]}
                      </span>
                      <div className="log-content">
                        <div className="log-header-row">
                          <span className="log-timestamp">
                            {new Date(log.timestamp).toLocaleTimeString()}
                          </span>
                          <span className="log-agent">{log.agent}</span>
                          <span className="log-request-id">{log.metadata.requestId}</span>
                        </div>
                        <div className="log-message">{log.message}</div>
                      </div>
                    </div>
                    {log.trace && (
                      <button
                        className="trace-btn"
                        onClick={(e) => {
                          e.stopPropagation()
                          handleViewTrace(log.trace!.id)
                        }}
                      >
                        🔍 Trace
                      </button>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Log Detail */}
          {selectedLog && (
            <div className="log-detail card">
              <div className="detail-header">
                <h3>Log Details</h3>
                <button className="btn-close" onClick={() => setSelectedLog(null)}>
                  ✕
                </button>
              </div>

              <div className="detail-content">
                <div className="detail-section">
                  <label>Level</label>
                  <span className={`log-level-badge ${LEVEL_COLORS[selectedLog.level]}`}>
                    {LEVEL_ICONS[selectedLog.level]} {selectedLog.level.toUpperCase()}
                  </span>
                </div>

                <div className="detail-section">
                  <label>Timestamp</label>
                  <span>{new Date(selectedLog.timestamp).toLocaleString()}</span>
                </div>

                <div className="detail-section">
                  <label>Agent</label>
                  <span>{selectedLog.agent}</span>
                </div>

                <div className="detail-section">
                  <label>Message</label>
                  <span>{selectedLog.message}</span>
                </div>

                <div className="detail-section">
                  <label>Metadata</label>
                  <div className="metadata-grid">
                    {Object.entries(selectedLog.metadata).map(([key, value]) => (
                      <div key={key} className="metadata-item">
                        <span className="metadata-key">{key}:</span>
                        <span className="metadata-value">
                          {typeof value === 'object' ? JSON.stringify(value) : String(value)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {selectedLog.trace && (
                  <div className="detail-section">
                    <label>Distributed Trace</label>
                    <div className="trace-info">
                      <div className="trace-stat">
                        <span className="trace-label">Trace ID</span>
                        <code className="trace-value">{selectedLog.trace.id}</code>
                      </div>
                      <div className="trace-stat">
                        <span className="trace-label">Spans</span>
                        <span className="trace-value">{selectedLog.trace.spans}</span>
                      </div>
                      <div className="trace-stat">
                        <span className="trace-label">Duration</span>
                        <span className="trace-value">{selectedLog.trace.duration}ms</span>
                      </div>
                    </div>
                    <button
                      className="btn btn-primary btn-full"
                      onClick={() => handleViewTrace(selectedLog.trace!.id)}
                    >
                      View Full Trace
                    </button>
                  </div>
                )}

                <div className="detail-actions">
                  <button className="btn btn-secondary">Copy as JSON</button>
                  <button className="btn btn-secondary">Share</button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

