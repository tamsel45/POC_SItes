import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
import './Workflows.css'

const WORKFLOW_TEMPLATES = [
  {
    id: 'template-1',
    name: 'Customer Onboarding',
    description: 'Automate customer onboarding process from signup to first interaction',
    category: 'customer-service',
    steps: 5,
    icon: '🎯',
    uses: 234,
  },
  {
    id: 'template-2',
    name: 'Lead Qualification',
    description: 'Qualify and route leads based on criteria and intent',
    category: 'sales',
    steps: 4,
    icon: '📊',
    uses: 187,
  },
  {
    id: 'template-3',
    name: 'Support Ticket Triage',
    description: 'Automatically categorize and prioritize support tickets',
    category: 'support',
    steps: 6,
    icon: '🎫',
    uses: 456,
  },
  {
    id: 'template-4',
    name: 'Content Approval',
    description: 'Route content through approval workflow with notifications',
    category: 'content',
    steps: 4,
    icon: '✅',
    uses: 123,
  },
]

const USER_WORKFLOWS = [
  {
    id: 'workflow-1',
    name: 'Sales Lead Workflow',
    description: 'Qualification and routing for inbound sales leads',
    status: 'active',
    triggers: ['Form Submit', 'Chatbot'],
    steps: [
      { id: 'step-1', type: 'trigger', name: 'Form Submitted', icon: '📝' },
      { id: 'step-2', type: 'agent', name: 'Qualify Lead', icon: '🤖' },
      { id: 'step-3', type: 'condition', name: 'Check Score', icon: '❓' },
      { id: 'step-4', type: 'action', name: 'Send to CRM', icon: '📤' },
      { id: 'step-5', type: 'notification', name: 'Notify Sales', icon: '📧' },
    ],
    executions: 1247,
    successRate: 94.5,
    avgDuration: 3.2,
    lastRun: '2024-12-04T10:30:00Z',
    createdAt: '2024-11-01T00:00:00Z',
  },
  {
    id: 'workflow-2',
    name: 'Customer Support Escalation',
    description: 'Escalate complex support issues to human agents',
    status: 'active',
    triggers: ['Chatbot', 'Email'],
    steps: [
      { id: 'step-1', type: 'trigger', name: 'Support Request', icon: '💬' },
      { id: 'step-2', type: 'agent', name: 'AI Response', icon: '🤖' },
      { id: 'step-3', type: 'condition', name: 'Check Resolved', icon: '❓' },
      { id: 'step-4', type: 'action', name: 'Create Ticket', icon: '🎫' },
      { id: 'step-5', type: 'notification', name: 'Notify Team', icon: '👥' },
    ],
    executions: 3456,
    successRate: 88.3,
    avgDuration: 5.7,
    lastRun: '2024-12-04T11:15:00Z',
    createdAt: '2024-10-15T00:00:00Z',
  },
  {
    id: 'workflow-3',
    name: 'Content Moderation',
    description: 'Review and moderate user-generated content',
    status: 'paused',
    triggers: ['Content Submission'],
    steps: [
      { id: 'step-1', type: 'trigger', name: 'Content Received', icon: '📄' },
      { id: 'step-2', type: 'agent', name: 'AI Review', icon: '🤖' },
      { id: 'step-3', type: 'condition', name: 'Check Safety', icon: '❓' },
      { id: 'step-4', type: 'action', name: 'Approve/Reject', icon: '✅' },
    ],
    executions: 892,
    successRate: 96.7,
    avgDuration: 1.5,
    lastRun: '2024-12-03T16:45:00Z',
    createdAt: '2024-11-20T00:00:00Z',
  },
]

const STEP_TYPES = [
  { id: 'trigger', name: 'Trigger', icon: '⚡', color: 'blue' },
  { id: 'agent', name: 'AI Agent', icon: '🤖', color: 'purple' },
  { id: 'condition', name: 'Condition', icon: '❓', color: 'orange' },
  { id: 'action', name: 'Action', icon: '⚙️', color: 'green' },
  { id: 'notification', name: 'Notification', icon: '📧', color: 'teal' },
]

export default function Workflows() {
  const navigate = useNavigate()
  const [activeTab, setActiveTab] = useState<'workflows' | 'templates' | 'analytics'>('workflows')
  const [selectedWorkflow, setSelectedWorkflow] = useState<string | null>(null)
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('list')

  const handleCreateWorkflow = () => {
    toast.info('Workflow builder coming soon!')
    // In real app, would navigate to workflow builder
  }

  const handleToggleWorkflow = (workflowId: string, currentStatus: string) => {
    const newStatus = currentStatus === 'active' ? 'paused' : 'active'
    toast.success(`Workflow ${newStatus}`)
  }

  const handleDuplicateWorkflow = (workflowId: string) => {
    toast.success('Workflow duplicated')
  }

  const handleDeleteWorkflow = (workflowId: string) => {
    if (confirm('Are you sure you want to delete this workflow?')) {
      toast.success('Workflow deleted')
    }
  }

  const handleUseTemplate = (templateId: string) => {
    toast.success('Creating workflow from template...')
  }

  return (
    <div className="workflows-page">
      {/* Header */}
      <div className="workflows-header">
        <div>
          <h1 className="page-title">Workflows</h1>
          <p className="page-subtitle">
            Automate agent interactions with multi-step workflows
          </p>
        </div>
        <div className="header-actions">
          <button className="btn btn-secondary">
            <span className="btn-icon">📚</span>
            Browse Templates
          </button>
          <button className="btn btn-primary" onClick={handleCreateWorkflow}>
            <span className="btn-icon">➕</span>
            Create Workflow
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon blue">⚡</div>
          <div>
            <div className="stat-value">{USER_WORKFLOWS.length}</div>
            <div className="stat-label">Active Workflows</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon green">✓</div>
          <div>
            <div className="stat-value">
              {USER_WORKFLOWS.reduce((sum, w) => sum + w.executions, 0).toLocaleString()}
            </div>
            <div className="stat-label">Total Executions</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon purple">📊</div>
          <div>
            <div className="stat-value">
              {(
                USER_WORKFLOWS.reduce((sum, w) => sum + w.successRate, 0) / USER_WORKFLOWS.length
              ).toFixed(1)}
              %
            </div>
            <div className="stat-label">Avg Success Rate</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon orange">⏱️</div>
          <div>
            <div className="stat-value">
              {(
                USER_WORKFLOWS.reduce((sum, w) => sum + w.avgDuration, 0) / USER_WORKFLOWS.length
              ).toFixed(1)}
              s
            </div>
            <div className="stat-label">Avg Duration</div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="workflows-tabs">
        <button
          className={`tab ${activeTab === 'workflows' ? 'active' : ''}`}
          onClick={() => setActiveTab('workflows')}
        >
          <span className="tab-icon">⚡</span>
          My Workflows ({USER_WORKFLOWS.length})
        </button>
        <button
          className={`tab ${activeTab === 'templates' ? 'active' : ''}`}
          onClick={() => setActiveTab('templates')}
        >
          <span className="tab-icon">📋</span>
          Templates ({WORKFLOW_TEMPLATES.length})
        </button>
        <button
          className={`tab ${activeTab === 'analytics' ? 'active' : ''}`}
          onClick={() => setActiveTab('analytics')}
        >
          <span className="tab-icon">📈</span>
          Analytics
        </button>
      </div>

      {/* Tab Content */}
      <div className="tab-content">
        {/* My Workflows Tab */}
        {activeTab === 'workflows' && (
          <div className="workflows-content">
            <div className="content-controls">
              <div className="search-box">
                <span className="search-icon">🔍</span>
                <input type="text" placeholder="Search workflows..." className="search-input" />
              </div>
              <div className="view-controls">
                <button
                  className={`view-btn ${viewMode === 'grid' ? 'active' : ''}`}
                  onClick={() => setViewMode('grid')}
                >
                  ⊞
                </button>
                <button
                  className={`view-btn ${viewMode === 'list' ? 'active' : ''}`}
                  onClick={() => setViewMode('list')}
                >
                  ☰
                </button>
              </div>
            </div>

            <div className={`workflows-${viewMode}`}>
              {USER_WORKFLOWS.map((workflow) => (
                <div key={workflow.id} className="workflow-card card hover-lift">
                  <div className="workflow-header">
                    <div className="workflow-main-info">
                      <h3 className="workflow-name">{workflow.name}</h3>
                      <p className="workflow-description">{workflow.description}</p>
                    </div>
                    <span className={`status-badge ${workflow.status === 'active' ? 'success' : 'warning'}`}>
                      {workflow.status === 'active' ? '● Active' : '○ Paused'}
                    </span>
                  </div>

                  <div className="workflow-steps-preview">
                    {workflow.steps.map((step, idx) => (
                      <div key={step.id} className="step-preview">
                        <div className={`step-icon ${STEP_TYPES.find((t) => t.id === step.type)?.color}`}>
                          {step.icon}
                        </div>
                        {idx < workflow.steps.length - 1 && <div className="step-connector">→</div>}
                      </div>
                    ))}
                  </div>

                  <div className="workflow-meta">
                    <span className="meta-item">
                      <span className="meta-icon">🔄</span>
                      {workflow.executions.toLocaleString()} runs
                    </span>
                    <span className="meta-item">
                      <span className="meta-icon">✓</span>
                      {workflow.successRate}% success
                    </span>
                    <span className="meta-item">
                      <span className="meta-icon">⏱️</span>
                      {workflow.avgDuration}s avg
                    </span>
                  </div>

                  <div className="workflow-triggers">
                    {workflow.triggers.map((trigger) => (
                      <span key={trigger} className="trigger-badge">
                        {trigger}
                      </span>
                    ))}
                  </div>

                  <div className="workflow-footer">
                    <span className="last-run">
                      Last run: {new Date(workflow.lastRun).toLocaleString()}
                    </span>
                    <div className="workflow-actions">
                      <button
                        className="btn-icon-only"
                        onClick={() => handleToggleWorkflow(workflow.id, workflow.status)}
                        title={workflow.status === 'active' ? 'Pause' : 'Resume'}
                      >
                        {workflow.status === 'active' ? '⏸️' : '▶️'}
                      </button>
                      <button
                        className="btn-icon-only"
                        onClick={() => setSelectedWorkflow(workflow.id)}
                        title="Edit"
                      >
                        ✏️
                      </button>
                      <button
                        className="btn-icon-only"
                        onClick={() => handleDuplicateWorkflow(workflow.id)}
                        title="Duplicate"
                      >
                        📋
                      </button>
                      <button
                        className="btn-icon-only"
                        onClick={() => handleDeleteWorkflow(workflow.id)}
                        title="Delete"
                      >
                        🗑️
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Templates Tab */}
        {activeTab === 'templates' && (
          <div className="templates-content">
            <div className="templates-grid">
              {WORKFLOW_TEMPLATES.map((template) => (
                <div key={template.id} className="template-card card hover-lift">
                  <div className="template-icon-wrapper">
                    <span className="template-icon">{template.icon}</span>
                  </div>
                  <h3 className="template-name">{template.name}</h3>
                  <p className="template-description">{template.description}</p>
                  <div className="template-meta">
                    <span className="meta-badge">
                      <span className="meta-icon">📊</span>
                      {template.steps} steps
                    </span>
                    <span className="meta-badge">
                      <span className="meta-icon">👥</span>
                      {template.uses} uses
                    </span>
                  </div>
                  <button
                    className="btn btn-primary btn-full"
                    onClick={() => handleUseTemplate(template.id)}
                  >
                    Use Template
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Analytics Tab */}
        {activeTab === 'analytics' && (
          <div className="analytics-content">
            <div className="analytics-grid">
              {/* Execution Timeline */}
              <div className="card chart-card">
                <h3 className="card-title">Execution Timeline (Last 7 Days)</h3>
                <div className="timeline-chart">
                  <div className="timeline-bars">
                    {[45, 62, 53, 78, 67, 71, 85].map((value, idx) => (
                      <div key={idx} className="timeline-bar-item">
                        <div className="bar-wrapper">
                          <div className="bar" style={{ height: `${value}%` }}></div>
                        </div>
                        <span className="bar-label">
                          {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][idx]}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Success Rate by Workflow */}
              <div className="card chart-card">
                <h3 className="card-title">Success Rate by Workflow</h3>
                <div className="success-rates">
                  {USER_WORKFLOWS.map((workflow) => (
                    <div key={workflow.id} className="success-rate-item">
                      <span className="workflow-name-small">{workflow.name}</span>
                      <div className="progress-bar-wrapper">
                        <div
                          className="progress-bar"
                          style={{ width: `${workflow.successRate}%` }}
                        ></div>
                        <span className="progress-label">{workflow.successRate}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Step Performance */}
              <div className="card">
                <h3 className="card-title">Most Used Step Types</h3>
                <div className="step-types-list">
                  {STEP_TYPES.map((type, idx) => (
                    <div key={type.id} className="step-type-item">
                      <div className={`step-type-icon ${type.color}`}>{type.icon}</div>
                      <div className="step-type-info">
                        <div className="step-type-name">{type.name}</div>
                        <div className="step-type-count">{150 - idx * 20} uses</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recent Executions */}
              <div className="card">
                <h3 className="card-title">Recent Executions</h3>
                <div className="executions-list">
                  {USER_WORKFLOWS.slice(0, 5).map((workflow) => (
                    <div key={workflow.id} className="execution-item">
                      <div className="execution-status success">✓</div>
                      <div className="execution-info">
                        <div className="execution-workflow">{workflow.name}</div>
                        <div className="execution-time">
                          {new Date(workflow.lastRun).toLocaleString()}
                        </div>
                      </div>
                      <div className="execution-duration">{workflow.avgDuration}s</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

