import { useState } from 'react'
import { toast } from 'react-toastify'
import './Models.css'

const LLM_PROVIDERS = [
  {
    id: 'openai',
    name: 'OpenAI',
    icon: '🤖',
    status: 'connected',
    models: ['GPT-4 Turbo', 'GPT-4', 'GPT-3.5 Turbo'],
    pricing: { input: 0.01, output: 0.03 },
  },
  {
    id: 'anthropic',
    name: 'Anthropic',
    icon: '🧠',
    status: 'connected',
    models: ['Claude 3 Opus', 'Claude 3 Sonnet', 'Claude 3 Haiku'],
    pricing: { input: 0.015, output: 0.075 },
  },
  {
    id: 'azure',
    name: 'Azure OpenAI',
    icon: '☁️',
    status: 'connected',
    models: ['GPT-4', 'GPT-3.5 Turbo'],
    pricing: { input: 0.01, output: 0.03 },
  },
  {
    id: 'bedrock',
    name: 'Amazon Bedrock',
    icon: '🟠',
    status: 'not-connected',
    models: ['Claude', 'Titan', 'Jurassic-2'],
    pricing: { input: 0.008, output: 0.024 },
  },
  {
    id: 'google',
    name: 'Google AI',
    icon: '🔵',
    status: 'not-connected',
    models: ['PaLM 2', 'Gemini Pro'],
    pricing: { input: 0.0005, output: 0.0015 },
  },
  {
    id: 'cohere',
    name: 'Cohere',
    icon: '💎',
    status: 'not-connected',
    models: ['Command', 'Command Light'],
    pricing: { input: 0.002, output: 0.006 },
  },
]

const MODEL_CONFIGURATIONS = [
  {
    id: 'config-1',
    name: 'Production GPT-4',
    provider: 'openai',
    model: 'GPT-4 Turbo',
    temperature: 0.7,
    maxTokens: 1000,
    topP: 0.9,
    frequencyPenalty: 0,
    presencePenalty: 0,
    agents: 12,
    requestsLast30Days: 45678,
    avgLatency: 1.8,
  },
  {
    id: 'config-2',
    name: 'Fast Response Claude',
    provider: 'anthropic',
    model: 'Claude 3 Haiku',
    temperature: 0.5,
    maxTokens: 500,
    topP: 1,
    frequencyPenalty: 0,
    presencePenalty: 0,
    agents: 8,
    requestsLast30Days: 23456,
    avgLatency: 0.9,
  },
  {
    id: 'config-3',
    name: 'Cost-Effective GPT-3.5',
    provider: 'openai',
    model: 'GPT-3.5 Turbo',
    temperature: 0.8,
    maxTokens: 800,
    topP: 0.95,
    frequencyPenalty: 0.2,
    presencePenalty: 0.1,
    agents: 15,
    requestsLast30Days: 89012,
    avgLatency: 0.6,
  },
]

export default function Models() {
  const [activeTab, setActiveTab] = useState<'providers' | 'configurations' | 'usage'>('providers')
  const [selectedProvider, setSelectedProvider] = useState<string | null>(null)
  const [showConfigModal, setShowConfigModal] = useState(false)

  const handleConnect = (providerId: string) => {
    toast.info(`Connecting to ${providerId}...`)
    // In real app, this would open OAuth flow or API key input
  }

  const handleDisconnect = (providerId: string) => {
    if (confirm('Are you sure you want to disconnect this provider?')) {
      toast.success(`Disconnected from ${providerId}`)
    }
  }

  const handleTestConnection = (providerId: string) => {
    toast.info(`Testing connection to ${providerId}...`)
    setTimeout(() => {
      toast.success('Connection test successful!')
    }, 1500)
  }

  return (
    <div className="models-page">
      {/* Header */}
      <div className="models-header">
        <div>
          <h1 className="page-title">Models & LLMs</h1>
          <p className="page-subtitle">
            Manage AI model providers, configurations, and monitor usage
          </p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowConfigModal(true)}>
          <span className="btn-icon">➕</span>
          New Configuration
        </button>
      </div>

      {/* Tabs */}
      <div className="models-tabs">
        <button
          className={`tab ${activeTab === 'providers' ? 'active' : ''}`}
          onClick={() => setActiveTab('providers')}
        >
          <span className="tab-icon">🔌</span>
          Providers ({LLM_PROVIDERS.filter((p) => p.status === 'connected').length})
        </button>
        <button
          className={`tab ${activeTab === 'configurations' ? 'active' : ''}`}
          onClick={() => setActiveTab('configurations')}
        >
          <span className="tab-icon">⚙️</span>
          Configurations ({MODEL_CONFIGURATIONS.length})
        </button>
        <button
          className={`tab ${activeTab === 'usage' ? 'active' : ''}`}
          onClick={() => setActiveTab('usage')}
        >
          <span className="tab-icon">📊</span>
          Usage & Costs
        </button>
      </div>

      {/* Tab Content */}
      <div className="tab-content">
        {/* Providers Tab */}
        {activeTab === 'providers' && (
          <div className="providers-content">
            <div className="providers-grid">
              {LLM_PROVIDERS.map((provider) => (
                <div key={provider.id} className="provider-card card hover-lift">
                  <div className="provider-header">
                    <div className="provider-icon-name">
                      <span className="provider-icon-large">{provider.icon}</span>
                      <div>
                        <h3 className="provider-name">{provider.name}</h3>
                        <span
                          className={`status-badge ${
                            provider.status === 'connected' ? 'success' : 'secondary'
                          }`}
                        >
                          {provider.status === 'connected' ? '● Connected' : '○ Not Connected'}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="provider-models">
                    <label>Available Models:</label>
                    <div className="models-list">
                      {provider.models.map((model, idx) => (
                        <span key={idx} className="model-badge">
                          {model}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="provider-pricing">
                    <label>Pricing (per 1K tokens):</label>
                    <div className="pricing-info">
                      <span>Input: ${provider.pricing.input}</span>
                      <span>•</span>
                      <span>Output: ${provider.pricing.output}</span>
                    </div>
                  </div>

                  <div className="provider-actions">
                    {provider.status === 'connected' ? (
                      <>
                        <button
                          className="btn btn-secondary btn-sm"
                          onClick={() => handleTestConnection(provider.id)}
                        >
                          <span className="btn-icon">🧪</span>
                          Test
                        </button>
                        <button
                          className="btn btn-secondary btn-sm"
                          onClick={() => setSelectedProvider(provider.id)}
                        >
                          <span className="btn-icon">⚙️</span>
                          Configure
                        </button>
                        <button
                          className="btn btn-danger btn-sm"
                          onClick={() => handleDisconnect(provider.id)}
                        >
                          Disconnect
                        </button>
                      </>
                    ) : (
                      <button
                        className="btn btn-primary btn-full"
                        onClick={() => handleConnect(provider.id)}
                      >
                        <span className="btn-icon">🔌</span>
                        Connect Provider
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Add Custom Provider */}
            <div className="card add-provider-card">
              <span className="add-icon">➕</span>
              <h3>Add Custom Provider</h3>
              <p>Connect to your own model endpoint or self-hosted LLM</p>
              <button className="btn btn-secondary">Configure Custom Endpoint</button>
            </div>
          </div>
        )}

        {/* Configurations Tab */}
        {activeTab === 'configurations' && (
          <div className="configurations-content">
            <div className="configurations-list">
              {MODEL_CONFIGURATIONS.map((config) => {
                const provider = LLM_PROVIDERS.find((p) => p.id === config.provider)
                return (
                  <div key={config.id} className="config-card card hover-lift">
                    <div className="config-header">
                      <div className="config-main-info">
                        <span className="provider-icon">{provider?.icon}</span>
                        <div>
                          <h3 className="config-name">{config.name}</h3>
                          <p className="config-model">
                            {provider?.name} • {config.model}
                          </p>
                        </div>
                      </div>
                      <div className="config-actions">
                        <button className="btn-icon-only" title="Edit">
                          ✏️
                        </button>
                        <button className="btn-icon-only" title="Duplicate">
                          📋
                        </button>
                        <button className="btn-icon-only" title="Delete">
                          🗑️
                        </button>
                      </div>
                    </div>

                    <div className="config-params">
                      <div className="param-item">
                        <label>Temperature</label>
                        <span className="param-value">{config.temperature}</span>
                      </div>
                      <div className="param-item">
                        <label>Max Tokens</label>
                        <span className="param-value">{config.maxTokens}</span>
                      </div>
                      <div className="param-item">
                        <label>Top P</label>
                        <span className="param-value">{config.topP}</span>
                      </div>
                      <div className="param-item">
                        <label>Frequency Penalty</label>
                        <span className="param-value">{config.frequencyPenalty}</span>
                      </div>
                    </div>

                    <div className="config-stats">
                      <div className="stat">
                        <span className="stat-label">Agents Using</span>
                        <span className="stat-value">{config.agents}</span>
                      </div>
                      <div className="stat">
                        <span className="stat-label">Requests (30d)</span>
                        <span className="stat-value">
                          {config.requestsLast30Days.toLocaleString()}
                        </span>
                      </div>
                      <div className="stat">
                        <span className="stat-label">Avg Latency</span>
                        <span className="stat-value">{config.avgLatency}s</span>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {/* Usage Tab */}
        {activeTab === 'usage' && (
          <div className="usage-content">
            <div className="usage-grid">
              {/* Cost Summary */}
              <div className="card usage-summary">
                <h3 className="card-title">Cost Summary (Last 30 Days)</h3>
                <div className="cost-breakdown">
                  <div className="cost-item total">
                    <span className="cost-label">Total Spend</span>
                    <span className="cost-value">$1,245.67</span>
                  </div>
                  <div className="cost-item">
                    <span className="cost-icon">🤖</span>
                    <div>
                      <span className="cost-label">OpenAI</span>
                      <span className="cost-value">$876.23</span>
                    </div>
                  </div>
                  <div className="cost-item">
                    <span className="cost-icon">🧠</span>
                    <div>
                      <span className="cost-label">Anthropic</span>
                      <span className="cost-value">$345.12</span>
                    </div>
                  </div>
                  <div className="cost-item">
                    <span className="cost-icon">☁️</span>
                    <div>
                      <span className="cost-label">Azure OpenAI</span>
                      <span className="cost-value">$24.32</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Token Usage */}
              <div className="card">
                <h3 className="card-title">Token Usage</h3>
                <div className="token-stats">
                  <div className="token-stat">
                    <span className="token-icon">📤</span>
                    <div>
                      <div className="token-value">12.5M</div>
                      <div className="token-label">Input Tokens</div>
                    </div>
                  </div>
                  <div className="token-stat">
                    <span className="token-icon">📥</span>
                    <div>
                      <div className="token-value">8.3M</div>
                      <div className="token-label">Output Tokens</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Model Usage Chart */}
              <div className="card chart-card">
                <h3 className="card-title">Usage by Model</h3>
                <div className="chart-placeholder">
                  <div className="usage-bars">
                    <div className="usage-bar-item">
                      <span className="bar-label">GPT-4 Turbo</span>
                      <div className="bar-wrapper">
                        <div className="bar" style={{ width: '85%' }}></div>
                        <span className="bar-value">85%</span>
                      </div>
                    </div>
                    <div className="usage-bar-item">
                      <span className="bar-label">Claude 3 Haiku</span>
                      <div className="bar-wrapper">
                        <div className="bar" style={{ width: '60%' }}></div>
                        <span className="bar-value">60%</span>
                      </div>
                    </div>
                    <div className="usage-bar-item">
                      <span className="bar-label">GPT-3.5 Turbo</span>
                      <div className="bar-wrapper">
                        <div className="bar" style={{ width: '45%' }}></div>
                        <span className="bar-value">45%</span>
                      </div>
                    </div>
                    <div className="usage-bar-item">
                      <span className="bar-label">GPT-4</span>
                      <div className="bar-wrapper">
                        <div className="bar" style={{ width: '30%' }}></div>
                        <span className="bar-value">30%</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Request Volume */}
              <div className="card chart-card">
                <h3 className="card-title">Request Volume (Last 7 Days)</h3>
                <div className="chart-placeholder">
                  <div className="volume-chart">
                    <div className="volume-bar" style={{ height: '60%' }}></div>
                    <div className="volume-bar" style={{ height: '75%' }}></div>
                    <div className="volume-bar" style={{ height: '55%' }}></div>
                    <div className="volume-bar" style={{ height: '90%' }}></div>
                    <div className="volume-bar" style={{ height: '70%' }}></div>
                    <div className="volume-bar" style={{ height: '65%' }}></div>
                    <div className="volume-bar" style={{ height: '80%' }}></div>
                  </div>
                  <div className="chart-labels">
                    <span>Mon</span>
                    <span>Tue</span>
                    <span>Wed</span>
                    <span>Thu</span>
                    <span>Fri</span>
                    <span>Sat</span>
                    <span>Sun</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Config Modal */}
      {showConfigModal && (
        <div className="modal-overlay" onClick={() => setShowConfigModal(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Create Model Configuration</h2>
              <button className="modal-close" onClick={() => setShowConfigModal(false)}>
                ✕
              </button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label htmlFor="config-name">Configuration Name</label>
                <input type="text" id="config-name" className="form-input" placeholder="e.g., Production GPT-4" />
              </div>
              <div className="form-group">
                <label htmlFor="provider">Provider</label>
                <select id="provider" className="form-select">
                  <option value="">Select a provider...</option>
                  {LLM_PROVIDERS.filter((p) => p.status === 'connected').map((provider) => (
                    <option key={provider.id} value={provider.id}>
                      {provider.icon} {provider.name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="form-group">
                <label htmlFor="model">Model</label>
                <select id="model" className="form-select">
                  <option value="">Select a model...</option>
                  <option value="gpt-4-turbo">GPT-4 Turbo</option>
                  <option value="gpt-4">GPT-4</option>
                  <option value="gpt-3.5-turbo">GPT-3.5 Turbo</option>
                </select>
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={() => setShowConfigModal(false)}>
                Cancel
              </button>
              <button className="btn btn-primary" onClick={() => {
                toast.success('Configuration created!')
                setShowConfigModal(false)
              }}>
                Create Configuration
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

