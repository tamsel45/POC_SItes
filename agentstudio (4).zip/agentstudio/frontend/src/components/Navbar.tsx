import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuthStore } from '../store/authStore'
import './Navbar.css'

export default function Navbar() {
  const navigate = useNavigate()
  const { user, logout } = useAuthStore()
  const [searchQuery, setSearchQuery] = useState('')
  const [showNotifications, setShowNotifications] = useState(false)
  const [showUserMenu, setShowUserMenu] = useState(false)

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      navigate(`/agents?search=${encodeURIComponent(searchQuery)}`)
    }
  }

  return (
    <nav className="navbar">
      <div className="navbar-content">
        {/* Brand */}
        <div className="navbar-brand">
          <div className="brand-logo">
            <span className="brand-icon">🤖</span>
            <span className="brand-name">Agent Studio</span>
          </div>
          <span className="brand-badge">Enterprise</span>
        </div>

        {/* Search */}
        <div className="navbar-search">
          <form onSubmit={handleSearch} className="search-form">
            <span className="search-icon">🔍</span>
            <input
              type="text"
              placeholder="Search agents, prompts, docs... (Ctrl+K)"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="search-input"
            />
            <kbd className="search-kbd">⌘K</kbd>
          </form>
        </div>

        {/* Actions */}
        <div className="navbar-actions">
          {/* Help */}
          <button
            className="navbar-action-btn"
            title="Help & Documentation"
            onClick={() => window.open('https://docs.agentstudio.com', '_blank')}
          >
            ❓
          </button>

          {/* Notifications */}
          <div className="navbar-dropdown">
            <button
              className="navbar-action-btn"
              onClick={() => setShowNotifications(!showNotifications)}
              title="Notifications"
            >
              🔔
              <span className="notification-badge">3</span>
            </button>
            {showNotifications && (
              <div className="dropdown-menu">
                <div className="dropdown-header">
                  <h4>Notifications</h4>
                  <button className="btn-link">Mark all read</button>
                </div>
                <div className="notification-item">
                  <span className="notification-icon success">✓</span>
                  <div className="notification-content">
                    <div className="notification-title">Deployment successful</div>
                    <div className="notification-time">5 minutes ago</div>
                  </div>
                </div>
                <div className="notification-item">
                  <span className="notification-icon warning">⚠️</span>
                  <div className="notification-content">
                    <div className="notification-title">High API usage detected</div>
                    <div className="notification-time">1 hour ago</div>
                  </div>
                </div>
                <div className="notification-item">
                  <span className="notification-icon info">ℹ️</span>
                  <div className="notification-content">
                    <div className="notification-title">New team member joined</div>
                    <div className="notification-time">3 hours ago</div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Theme Toggle */}
          <button
            className="navbar-action-btn"
            title="Toggle Theme"
          >
            🌙
          </button>

          {/* User Menu */}
          <div className="navbar-dropdown">
            <button
              className="user-menu-btn"
              onClick={() => setShowUserMenu(!showUserMenu)}
            >
              <div className="user-avatar">👤</div>
              <div className="user-info">
                <div className="user-name">{user?.fullName || 'User'}</div>
                <div className="user-role">Admin</div>
              </div>
              <span className="dropdown-arrow">▼</span>
            </button>
            {showUserMenu && (
              <div className="dropdown-menu user-dropdown">
                <div className="dropdown-header">
                  <div className="user-avatar-large">👤</div>
                  <div>
                    <div className="user-name-large">{user?.fullName || 'User'}</div>
                    <div className="user-email">{user?.email}</div>
                  </div>
                </div>
                <div className="dropdown-divider"></div>
                <button className="dropdown-item" onClick={() => {
                  navigate('/profile')
                  setShowUserMenu(false)
                }}>
                  <span className="dropdown-icon">👤</span>
                  Profile Settings
                </button>
                <button className="dropdown-item" onClick={() => {
                  navigate('/settings')
                  setShowUserMenu(false)
                }}>
                  <span className="dropdown-icon">⚙️</span>
                  Settings
                </button>
                <button className="dropdown-item" onClick={() => {
                  navigate('/team')
                  setShowUserMenu(false)
                }}>
                  <span className="dropdown-icon">👥</span>
                  Team
                </button>
                <div className="dropdown-divider"></div>
                <button className="dropdown-item" onClick={handleLogout}>
                  <span className="dropdown-icon">🚪</span>
                  Sign Out
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  )
}
