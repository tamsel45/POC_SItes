import { NavLink } from 'react-router-dom'
import {
  HomeRegular,
  BotRegular,
  DocumentTextRegular,
  DatabaseRegular,
  BeakerRegular,
  ChartMultipleRegular,
  SettingsRegular,
  BookRegular,
  PeopleTeamRegular,
  ShieldTaskRegular,
  PlugConnectedRegular,
  AppsListDetailRegular,
  CloudSyncRegular,
  BrainCircuitRegular,
} from '@fluentui/react-icons'
import './Sidebar.css'

interface MenuItem {
  path: string
  icon: any
  label: string
  badge?: string
}

interface MenuSection {
  title: string
  items: MenuItem[]
}

export default function Sidebar() {
  const menuSections: MenuSection[] = [
    {
      title: 'Overview',
      items: [
        { path: '/dashboard', icon: HomeRegular, label: 'Dashboard' },
        { path: '/agents', icon: BotRegular, label: 'Agents', badge: '3' },
      ],
    },
    {
      title: 'Development',
      items: [
        { path: '/prompt-library', icon: DocumentTextRegular, label: 'Prompt Library' },
        { path: '/knowledge-base', icon: DatabaseRegular, label: 'Knowledge Bases' },
        { path: '/models', icon: BrainCircuitRegular, label: 'Models & LLMs' },
        { path: '/workflows', icon: AppsListDetailRegular, label: 'Workflows' },
      ],
    },
    {
      title: 'Testing & Monitoring',
      items: [
        { path: '/testing', icon: BeakerRegular, label: 'Test Console' },
        { path: '/analytics', icon: ChartMultipleRegular, label: 'Analytics' },
        { path: '/logs', icon: BookRegular, label: 'Logs & Traces' },
      ],
    },
    {
      title: 'Integration',
      items: [
        { path: '/integrations', icon: PlugConnectedRegular, label: 'Integrations' },
        { path: '/api-keys', icon: ShieldTaskRegular, label: 'API Keys' },
        { path: '/deployments', icon: CloudSyncRegular, label: 'Deployments' },
      ],
    },
    {
      title: 'Management',
      items: [
        { path: '/team', icon: PeopleTeamRegular, label: 'Team & Access' },
        { path: '/settings', icon: SettingsRegular, label: 'Settings' },
      ],
    },
  ]

  return (
    <aside className="sidebar">
      <div className="sidebar-content">
        {menuSections.map((section, idx) => (
          <div key={idx} className="sidebar-section">
            <div className="sidebar-section-title">{section.title}</div>
            <nav className="sidebar-nav">
              {section.items.map((item) => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  className={({ isActive }) =>
                    `sidebar-link ${isActive ? 'active' : ''}`
                  }
                >
                  <item.icon className="sidebar-icon" />
                  <span className="sidebar-label">{item.label}</span>
                  {item.badge && (
                    <span className="sidebar-badge">{item.badge}</span>
                  )}
                </NavLink>
              ))}
            </nav>
          </div>
        ))}
      </div>

      <div className="sidebar-footer">
        <div className="sidebar-info">
          <div className="sidebar-info-title">💡 Quick Tips</div>
          <div className="sidebar-info-text">
            Press <kbd>Ctrl+K</kbd> to quickly search
          </div>
        </div>
      </div>
    </aside>
  )
}
