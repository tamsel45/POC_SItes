"""
Agent management endpoints.
"""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from pydantic import BaseModel, Field
from datetime import datetime
from enum import Enum

from app.core.security import get_current_user

router = APIRouter()


class AgentStatus(str, Enum):
    active = "active"
    paused = "paused"
    inactive = "inactive"


class AgentFramework(str, Enum):
    copilot_studio = "Microsoft Copilot Studio"
    langchain = "LangChain"
    semantic_kernel = "Semantic Kernel"


class AgentBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = None
    framework: AgentFramework = AgentFramework.copilot_studio
    language_model: str = "GPT-4 Turbo"
    temperature: float = Field(0.7, ge=0.0, le=2.0)
    max_tokens: int = Field(1000, ge=1, le=4000)
    tags: List[str] = []


class AgentCreate(AgentBase):
    pass


class AgentUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    status: Optional[AgentStatus] = None
    temperature: Optional[float] = Field(None, ge=0.0, le=2.0)
    max_tokens: Optional[int] = Field(None, ge=1, le=4000)
    tags: Optional[List[str]] = None


class AgentResponse(AgentBase):
    id: str
    status: AgentStatus
    conversation_count: int
    success_rate: float
    avg_response_time: float
    created_at: datetime
    updated_at: datetime
    created_by: str

    class Config:
        from_attributes = True


class AgentListResponse(BaseModel):
    agents: List[AgentResponse]
    total: int
    page: int
    page_size: int


# Mock data for demonstration
MOCK_AGENTS = [
    {
        "id": "agent-001",
        "name": "Customer Support Agent",
        "description": "Handles customer inquiries and provides product information",
        "status": AgentStatus.active,
        "framework": AgentFramework.copilot_studio,
        "language_model": "GPT-4 Turbo",
        "temperature": 0.7,
        "max_tokens": 1000,
        "tags": ["customer-service", "production", "high-priority"],
        "conversation_count": 1247,
        "success_rate": 94.2,
        "avg_response_time": 2.1,
        "created_at": datetime(2024, 1, 15, 10, 30),
        "updated_at": datetime(2024, 12, 1, 8, 15),
        "created_by": "Arif",
    },
    {
        "id": "agent-002",
        "name": "HR Onboarding Assistant",
        "description": "Assists with employee onboarding processes",
        "status": AgentStatus.paused,
        "framework": AgentFramework.copilot_studio,
        "language_model": "GPT-4 Turbo",
        "temperature": 0.6,
        "max_tokens": 800,
        "tags": ["hr", "onboarding"],
        "conversation_count": 456,
        "success_rate": 89.0,
        "avg_response_time": 3.2,
        "created_at": datetime(2024, 1, 20, 14, 45),
        "updated_at": datetime(2024, 11, 30, 16, 20),
        "created_by": "Rupak",
    },
    {
        "id": "agent-003",
        "name": "Sales Lead Qualifier",
        "description": "Qualifies sales leads and schedules demos",
        "status": AgentStatus.inactive,
        "framework": AgentFramework.copilot_studio,
        "language_model": "GPT-4",
        "temperature": 0.8,
        "max_tokens": 1200,
        "tags": ["sales", "lead-gen"],
        "conversation_count": 89,
        "success_rate": 76.0,
        "avg_response_time": 4.5,
        "created_at": datetime(2024, 1, 10, 9, 0),
        "updated_at": datetime(2024, 11, 28, 11, 30),
        "created_by": "David",
    },
]


@router.get("", response_model=AgentListResponse)
async def list_agents(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    status: Optional[AgentStatus] = None,
    search: Optional[str] = None,
    current_user: dict = Depends(get_current_user),
):
    """
    List all agents with pagination and filtering.
    """
    agents = MOCK_AGENTS.copy()

    # Apply filters
    if status:
        agents = [a for a in agents if a["status"] == status]

    if search:
        agents = [
            a
            for a in agents
            if search.lower() in a["name"].lower() or search.lower() in a["description"].lower()
        ]

    # Pagination
    start = (page - 1) * page_size
    end = start + page_size
    paginated_agents = agents[start:end]

    return AgentListResponse(
        agents=[AgentResponse(**agent) for agent in paginated_agents],
        total=len(agents),
        page=page,
        page_size=page_size,
    )


@router.post("", response_model=AgentResponse, status_code=status.HTTP_201_CREATED)
async def create_agent(
    agent: AgentCreate,
    current_user: dict = Depends(get_current_user),
):
    """
    Create a new agent.
    """
    new_agent = {
        "id": f"agent-{len(MOCK_AGENTS) + 1:03d}",
        **agent.dict(),
        "status": AgentStatus.active,
        "conversation_count": 0,
        "success_rate": 0.0,
        "avg_response_time": 0.0,
        "created_at": datetime.utcnow(),
        "updated_at": datetime.utcnow(),
        "created_by": current_user.get("email", "Unknown"),
    }

    MOCK_AGENTS.append(new_agent)
    return AgentResponse(**new_agent)


@router.get("/{agent_id}", response_model=AgentResponse)
async def get_agent(
    agent_id: str,
    current_user: dict = Depends(get_current_user),
):
    """
    Get agent details by ID.
    """
    agent = next((a for a in MOCK_AGENTS if a["id"] == agent_id), None)
    if not agent:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Agent {agent_id} not found",
        )

    return AgentResponse(**agent)


@router.put("/{agent_id}", response_model=AgentResponse)
async def update_agent(
    agent_id: str,
    agent_update: AgentUpdate,
    current_user: dict = Depends(get_current_user),
):
    """
    Update an existing agent.
    """
    agent = next((a for a in MOCK_AGENTS if a["id"] == agent_id), None)
    if not agent:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Agent {agent_id} not found",
        )

    # Update fields
    update_data = agent_update.dict(exclude_unset=True)
    for field, value in update_data.items():
        agent[field] = value

    agent["updated_at"] = datetime.utcnow()

    return AgentResponse(**agent)


@router.delete("/{agent_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_agent(
    agent_id: str,
    current_user: dict = Depends(get_current_user),
):
    """
    Delete an agent.
    """
    agent_idx = next((i for i, a in enumerate(MOCK_AGENTS) if a["id"] == agent_id), None)
    if agent_idx is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Agent {agent_id} not found",
        )

    MOCK_AGENTS.pop(agent_idx)
    return None


@router.post("/{agent_id}/invoke")
async def invoke_agent(
    agent_id: str,
    input_text: str,
    debug: bool = False,
    current_user: dict = Depends(get_current_user),
):
    """
    Invoke an agent with input text.
    """
    agent = next((a for a in MOCK_AGENTS if a["id"] == agent_id), None)
    if not agent:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Agent {agent_id} not found",
        )

    # Mock response
    response = {
        "agent_id": agent_id,
        "response": f"Thank you for your message: '{input_text}'. I'm here to help you!",
        "tokens_in": 15,
        "tokens_out": 18,
        "latency": 1.8,
        "timestamp": datetime.utcnow().isoformat(),
    }

    if debug:
        response["debug_info"] = {
            "model": agent["language_model"],
            "temperature": agent["temperature"],
            "max_tokens": agent["max_tokens"],
            "kb_queries": [
                {"query": "customer support", "results": 5, "top_score": 0.94}
            ],
        }

    return response

