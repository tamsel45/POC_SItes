"""
Knowledge base management endpoints.
"""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from pydantic import BaseModel
from datetime import datetime
from enum import Enum

from app.core.security import get_current_user

router = APIRouter()


class DocumentStatus(str, Enum):
    processing = "processing"
    complete = "complete"
    error = "error"


class DocumentType(str, Enum):
    pdf = "pdf"
    docx = "docx"
    txt = "txt"
    md = "md"
    html = "html"
    csv = "csv"
    web = "web"


class DocumentBase(BaseModel):
    name: str
    type: DocumentType
    size: int


class DocumentResponse(DocumentBase):
    id: str
    agent_id: str
    status: DocumentStatus
    chunks: int
    embeddings_complete: bool
    uploaded_at: datetime
    last_indexed: Optional[datetime]

    class Config:
        from_attributes = True


class DocumentListResponse(BaseModel):
    documents: List[DocumentResponse]
    total: int
    total_size: int


class KnowledgeBaseStats(BaseModel):
    total_documents: int
    total_chunks: int
    vector_store_size: int
    embedding_model: str
    last_full_reindex: Optional[datetime]
    avg_retrieval_time: float


# Mock data
MOCK_DOCUMENTS = [
    {
        "id": "doc-001",
        "agent_id": "agent-001",
        "name": "Product_Catalog_2024.pdf",
        "type": DocumentType.pdf,
        "size": 2516582,  # 2.4 MB
        "status": DocumentStatus.complete,
        "chunks": 45,
        "embeddings_complete": True,
        "uploaded_at": datetime(2024, 1, 20, 14, 30),
        "last_indexed": datetime(2024, 11, 29, 10, 15),
    },
    {
        "id": "doc-002",
        "agent_id": "agent-001",
        "name": "Return_Policy.docx",
        "type": DocumentType.docx,
        "size": 87040,  # 85 KB
        "status": DocumentStatus.complete,
        "chunks": 8,
        "embeddings_complete": True,
        "uploaded_at": datetime(2024, 1, 18, 9, 45),
        "last_indexed": datetime(2024, 11, 27, 16, 20),
    },
]


@router.post("/upload", response_model=List[DocumentResponse])
async def upload_documents(
    files: List[UploadFile] = File(...),
    agent_id: str = Form(...),
    chunk_size: int = Form(512),
    chunk_overlap: int = Form(50),
    auto_embed: bool = Form(True),
    current_user: dict = Depends(get_current_user),
):
    """
    Upload documents to knowledge base.
    """
    uploaded_docs = []

    for file in files:
        # Read file content
        content = await file.read()

        # Validate file type
        file_extension = file.filename.split(".")[-1].lower()
        if file_extension not in ["pdf", "docx", "txt", "md", "html", "csv"]:
            continue

        # Create document record
        new_doc = {
            "id": f"doc-{len(MOCK_DOCUMENTS) + len(uploaded_docs) + 1:03d}",
            "agent_id": agent_id,
            "name": file.filename,
            "type": DocumentType(file_extension),
            "size": len(content),
            "status": DocumentStatus.processing if auto_embed else DocumentStatus.complete,
            "chunks": 0,  # Will be calculated during processing
            "embeddings_complete": False,
            "uploaded_at": datetime.utcnow(),
            "last_indexed": None,
        }

        MOCK_DOCUMENTS.append(new_doc)
        uploaded_docs.append(DocumentResponse(**new_doc))

        # TODO: Process document - chunk, embed, store in vector DB

    return uploaded_docs


@router.get("/{agent_id}/documents", response_model=DocumentListResponse)
async def list_documents(
    agent_id: str,
    current_user: dict = Depends(get_current_user),
):
    """
    List all documents for an agent.
    """
    agent_docs = [d for d in MOCK_DOCUMENTS if d["agent_id"] == agent_id]

    return DocumentListResponse(
        documents=[DocumentResponse(**doc) for doc in agent_docs],
        total=len(agent_docs),
        total_size=sum(d["size"] for d in agent_docs),
    )


@router.get("/{agent_id}/stats", response_model=KnowledgeBaseStats)
async def get_knowledge_base_stats(
    agent_id: str,
    current_user: dict = Depends(get_current_user),
):
    """
    Get knowledge base statistics for an agent.
    """
    agent_docs = [d for d in MOCK_DOCUMENTS if d["agent_id"] == agent_id]

    return KnowledgeBaseStats(
        total_documents=len(agent_docs),
        total_chunks=sum(d["chunks"] for d in agent_docs),
        vector_store_size=sum(d["size"] for d in agent_docs),
        embedding_model="text-embedding-ada-002",
        last_full_reindex=datetime(2024, 11, 24, 8, 0),
        avg_retrieval_time=0.8,
    )


@router.post("/{document_id}/reindex")
async def reindex_document(
    document_id: str,
    current_user: dict = Depends(get_current_user),
):
    """
    Reindex a document to update embeddings.
    """
    doc = next((d for d in MOCK_DOCUMENTS if d["id"] == document_id), None)
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")

    # TODO: Implement reindexing logic
    doc["status"] = DocumentStatus.processing
    doc["last_indexed"] = datetime.utcnow()

    return {"detail": "Reindexing started", "document_id": document_id}


@router.delete("/{document_id}")
async def delete_document(
    document_id: str,
    current_user: dict = Depends(get_current_user),
):
    """
    Delete a document from knowledge base.
    """
    doc_idx = next((i for i, d in enumerate(MOCK_DOCUMENTS) if d["id"] == document_id), None)
    if doc_idx is None:
        raise HTTPException(status_code=404, detail="Document not found")

    MOCK_DOCUMENTS.pop(doc_idx)
    return {"detail": "Document deleted"}

