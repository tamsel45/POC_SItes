"""
Prompt management endpoints.
"""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from datetime import datetime

from app.core.security import get_current_user

router = APIRouter()


class Variable(BaseModel):
    name: str
    description: str
    default_value: str


class FewShotExample(BaseModel):
    user_input: str
    assistant_output: str


class PromptBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    content: str = Field(..., min_length=1)
    variables: List[Variable] = []
    few_shot_examples: List[FewShotExample] = []


class PromptCreate(PromptBase):
    agent_id: str


class PromptResponse(PromptBase):
    id: str
    agent_id: str
    version: str
    created_at: datetime
    updated_at: datetime
    created_by: str

    class Config:
        from_attributes = True


class PromptTestRequest(BaseModel):
    prompt: str
    input: str
    variables: dict = {}


class PromptTestResponse(BaseModel):
    response: str
    tokens_in: int
    tokens_out: int
    latency: float


@router.post("", response_model=PromptResponse, status_code=status.HTTP_201_CREATED)
async def create_prompt(
    prompt: PromptCreate,
    current_user: dict = Depends(get_current_user),
):
    """
    Create a new prompt.
    """
    new_prompt = {
        "id": f"prompt-{datetime.utcnow().timestamp()}",
        **prompt.dict(),
        "version": "v1.0",
        "created_at": datetime.utcnow(),
        "updated_at": datetime.utcnow(),
        "created_by": current_user.get("email", "Unknown"),
    }

    return PromptResponse(**new_prompt)


@router.get("/{agent_id}", response_model=List[PromptResponse])
async def list_prompts(
    agent_id: str,
    current_user: dict = Depends(get_current_user),
):
    """
    List all prompts for an agent.
    """
    # Mock data
    prompts = [
        {
            "id": "prompt-001",
            "agent_id": agent_id,
            "name": "Customer Support System Prompt",
            "content": """You are an expert customer support agent for Acme Corporation. Your role is to:

1. Greet customers warmly and professionally
2. Understand their issue through active listening
3. Provide accurate solutions from the knowledge base
4. Escalate complex issues to human agents when needed

Guidelines:
- Always be polite and empathetic
- Keep responses concise (under 150 words)
- Use {{customer_name}} for personalization
- Reference policy {{return_policy}} when needed

If you don't know the answer, say "Let me connect you with a specialist who can help."
""",
            "version": "v3.2",
            "variables": [
                {
                    "name": "customer_name",
                    "description": "User's display name",
                    "default_value": "there",
                },
                {
                    "name": "return_policy",
                    "description": "30-day return policy text",
                    "default_value": "Our 30-day return policy allows...",
                },
            ],
            "few_shot_examples": [
                {
                    "user_input": "I want to return my order",
                    "assistant_output": "I'd be happy to help with your return. According to our {{return_policy}}, you can return items within 30 days...",
                }
            ],
            "created_at": datetime(2024, 1, 15, 10, 30),
            "updated_at": datetime(2024, 12, 1, 8, 15),
            "created_by": "admin@agentstudio.com",
        }
    ]

    return [PromptResponse(**p) for p in prompts]


@router.post("/test", response_model=PromptTestResponse)
async def test_prompt(
    request: PromptTestRequest,
    current_user: dict = Depends(get_current_user),
):
    """
    Test a prompt with sample input.
    """
    # Mock response - in production, this would call Azure OpenAI
    import time
    start_time = time.time()

    # Simulate processing
    time.sleep(0.5)

    response_text = f"Based on your input '{request.input}', here's my response using the provided prompt. This is a simulated response for testing purposes."

    return PromptTestResponse(
        response=response_text,
        tokens_in=len(request.prompt.split()) + len(request.input.split()),
        tokens_out=len(response_text.split()),
        latency=time.time() - start_time,
    )

