"""
Placeholder for core init.
"""

