# Start Frontend Development Server

Write-Host "Starting Agent Studio Frontend..." -ForegroundColor Cyan
Write-Host ""

Set-Location frontend

Write-Host "Frontend running at: http://localhost:3000" -ForegroundColor Green
Write-Host ""
Write-Host "Press Ctrl+C to stop the server" -ForegroundColor Yellow
Write-Host ""

npm run dev

