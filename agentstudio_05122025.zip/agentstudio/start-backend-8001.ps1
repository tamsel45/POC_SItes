# Start Agent Studio Backend on Port 8001

Write-Host "================================" -ForegroundColor Cyan
Write-Host "Starting Agent Studio Backend" -ForegroundColor Cyan
Write-Host "================================" -ForegroundColor Cyan
Write-Host ""

# Set environment variables
$env:SECRET_KEY = "super-secret-key-change-in-production-min-32-chars-long"
$env:DEBUG = "true"
$env:ALLOWED_ORIGINS = "http://localhost:3000,http://localhost:5173"

Write-Host "Backend will start on: http://127.0.0.1:8001" -ForegroundColor Green
Write-Host "API Docs will be at: http://127.0.0.1:8001/api/v1/docs" -ForegroundColor Green
Write-Host ""
Write-Host "Press Ctrl+C to stop the server" -ForegroundColor Yellow
Write-Host ""

cd backend
python -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8001

