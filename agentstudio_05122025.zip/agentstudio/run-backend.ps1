# Start Backend Server

Write-Host "Starting Agent Studio Backend..." -ForegroundColor Cyan
Write-Host ""

Set-Location backend

# Activate virtual environment
.\venv\Scripts\Activate.ps1

# Set environment variables for local testing
$env:SECRET_KEY = "super-secret-key-change-in-production-min-32-chars-long"
$env:DEBUG = "true"
$env:ALLOWED_ORIGINS = "http://localhost:3000,http://localhost:5173"
$env:REDIS_URL = "redis://localhost:6379"

# Start the server
Write-Host "Backend running at: http://localhost:8000" -ForegroundColor Green
Write-Host "API Docs at: http://localhost:8000/api/v1/docs" -ForegroundColor Green
Write-Host ""
Write-Host "Press Ctrl+C to stop the server" -ForegroundColor Yellow
Write-Host ""

uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

