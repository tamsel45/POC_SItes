"""
Tests package initialization.
"""

