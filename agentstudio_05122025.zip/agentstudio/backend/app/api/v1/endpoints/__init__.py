"""
Placeholder for endpoints init.
"""

