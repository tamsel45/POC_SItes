"""
Analytics and monitoring endpoints.
"""
from typing import List
from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel
from datetime import datetime, timedelta
import random

from app.core.security import get_current_user

router = APIRouter()


class MetricsResponse(BaseModel):
    total_conversations: int
    success_rate: float
    avg_latency: float
    user_satisfaction: float


class TrendDataPoint(BaseModel):
    date: str
    count: int


class IntentData(BaseModel):
    intent: str
    percentage: float
    count: int


class ErrorBreakdown(BaseModel):
    type: str
    count: int
    percentage: float


class CostBreakdown(BaseModel):
    category: str
    amount: float
    percentage: float


class AnalyticsResponse(BaseModel):
    metrics: MetricsResponse
    conversation_trends: List[TrendDataPoint]
    response_time_distribution: List[dict]
    top_intents: List[IntentData]
    error_breakdown: List[ErrorBreakdown]
    cost_breakdown: List[CostBreakdown]


@router.get("/{agent_id}", response_model=AnalyticsResponse)
async def get_agent_analytics(
    agent_id: str,
    period: str = Query("30d", regex="^(7d|30d|90d)$"),
    current_user: dict = Depends(get_current_user),
):
    """
    Get comprehensive analytics for an agent.
    """
    # Generate mock data based on period
    days = int(period[:-1])

    # Generate conversation trends
    trends = []
    base_date = datetime.utcnow() - timedelta(days=days)
    for i in range(days):
        date = base_date + timedelta(days=i)
        trends.append(
            TrendDataPoint(
                date=date.strftime("%Y-%m-%d"),
                count=random.randint(300, 600),
            )
        )

    # Response time distribution
    response_time_dist = [
        {"bucket": "<1s", "count": 2847},
        {"bucket": "1-2s", "count": 5234},
        {"bucket": "2-3s", "count": 3156},
        {"bucket": "3-5s", "count": 892},
        {"bucket": ">5s", "count": 327},
    ]

    # Top intents
    top_intents = [
        IntentData(intent="Product Returns", percentage=28.0, count=3487),
        IntentData(intent="Order Status", percentage=22.0, count=2740),
        IntentData(intent="Account Issues", percentage=18.0, count=2242),
        IntentData(intent="Product Information", percentage=15.0, count=1868),
        IntentData(intent="Shipping Questions", percentage=12.0, count=1495),
        IntentData(intent="Other", percentage=5.0, count=624),
    ]

    # Error breakdown
    error_breakdown = [
        ErrorBreakdown(type="Timeout (>30s)", count=312, percentage=43.0),
        ErrorBreakdown(type="Invalid Response", count=189, percentage=26.0),
        ErrorBreakdown(type="Knowledge Base Miss", count=145, percentage=20.0),
        ErrorBreakdown(type="API Errors", count=78, percentage=11.0),
    ]

    # Cost breakdown
    cost_breakdown = [
        CostBreakdown(category="LLM API Calls", amount=987.23, percentage=79.0),
        CostBreakdown(category="Embeddings", amount=156.34, percentage=13.0),
        CostBreakdown(category="Storage", amount=78.90, percentage=6.0),
        CostBreakdown(category="Compute", amount=23.20, percentage=2.0),
    ]

    return AnalyticsResponse(
        metrics=MetricsResponse(
            total_conversations=12456,
            success_rate=94.2,
            avg_latency=2.3,
            user_satisfaction=4.6,
        ),
        conversation_trends=trends,
        response_time_distribution=response_time_dist,
        top_intents=top_intents,
        error_breakdown=error_breakdown,
        cost_breakdown=cost_breakdown,
    )


@router.get("/{agent_id}/export")
async def export_analytics(
    agent_id: str,
    period: str = Query("30d"),
    format: str = Query("csv", regex="^(csv|json|pdf)$"),
    current_user: dict = Depends(get_current_user),
):
    """
    Export analytics data in various formats.
    """
    # TODO: Implement actual export logic
    return {
        "detail": f"Analytics export for agent {agent_id} (period: {period}) in {format} format",
        "download_url": f"/downloads/analytics-{agent_id}-{period}.{format}",
    }

