"""
Prompt management endpoints.
"""
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from datetime import datetime

from app.core.security import get_current_user

router = APIRouter()


class Variable(BaseModel):
    name: str
    description: str
    default_value: str


class FewShotExample(BaseModel):
    user_input: str
    assistant_output: str


class PromptBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    content: str = Field(..., min_length=1)
    variables: List[Variable] = []
    few_shot_examples: List[FewShotExample] = []


class PromptCreate(PromptBase):
    agent_id: str


class PromptResponse(PromptBase):
    id: str
    agent_id: str
    version: str
    created_at: datetime
    updated_at: datetime
    created_by: str

    class Config:
        from_attributes = True


class PromptTestRequest(BaseModel):
    prompt: str
    input: str
    variables: dict = {}
    model: Optional[str] = "gpt-4-turbo"
    temperature: Optional[float] = 0.7
    maxTokens: Optional[int] = 1000


class PromptTestResponse(BaseModel):
    response: str
    tokens_in: int
    tokens_out: int
    latency: float


@router.post("", response_model=PromptResponse, status_code=status.HTTP_201_CREATED)
async def create_prompt(
    prompt: PromptCreate,
    current_user: dict = Depends(get_current_user),
):
    """
    Create a new prompt.
    """
    new_prompt = {
        "id": f"prompt-{datetime.utcnow().timestamp()}",
        **prompt.dict(),
        "version": "v1.0",
        "created_at": datetime.utcnow(),
        "updated_at": datetime.utcnow(),
        "created_by": current_user.get("email", "Unknown"),
    }

    return PromptResponse(**new_prompt)


@router.get("/{agent_id}", response_model=List[PromptResponse])
async def list_prompts(
    agent_id: str,
    current_user: dict = Depends(get_current_user),
):
    """
    List all prompts for an agent.
    """
    # Mock data
    prompts = [
        {
            "id": "prompt-001",
            "agent_id": agent_id,
            "name": "Knowledge Base Q&A System Prompt",
            "content": """You are a knowledge base assistant for Orchestra AI. Your role is to:

1. Answer questions using ONLY information from the retrieved knowledge base chunks
2. Always cite your sources with document names and page numbers
3. Maintain factual accuracy and admit when information is not available
4. Provide concise, well-structured responses

Guidelines:
- Use {{query}} to understand the user's question
- Reference {{knowledge_base}} for context
- Keep responses under 200 words unless more detail is requested
- Always include source citations in format: [Document Name, Page X]

If the information is not in the knowledge base, say "I don't have that information in the current knowledge base. Please contact {{contact_person}} for assistance."
""",
            "version": "v3.2",
            "variables": [
                {
                    "name": "query",
                    "description": "User's question or query",
                    "default_value": "",
                },
                {
                    "name": "knowledge_base",
                    "description": "Name of the knowledge base being queried",
                    "default_value": "Product Catalog",
                },
                {
                    "name": "contact_person",
                    "description": "Contact person for questions outside KB",
                    "default_value": "your team lead",
                },
            ],
            "few_shot_examples": [
                {
                    "user_input": "What are the specifications for the X200 series?",
                    "assistant_output": "The X200 series specifications include: 128GB RAM, 2TB SSD storage, and Intel Core i9 processor. [Product Catalog 2024, Page 45]",
                }
            ],
            "created_at": datetime(2024, 1, 15, 10, 30),
            "updated_at": datetime(2024, 12, 1, 8, 15),
            "created_by": "Anup Menon",
        }
    ]

    return [PromptResponse(**p) for p in prompts]


@router.post("/test", response_model=PromptTestResponse)
async def test_prompt(
    request: PromptTestRequest,
    current_user: dict = Depends(get_current_user),
):
    """
    Test a prompt with sample input.
    """
    # Mock response - in production, this would call Azure OpenAI
    import time
    start_time = time.time()

    # Simulate processing
    time.sleep(0.5)

    response_text = f"Based on your input '{request.input}', here's my response using the provided prompt. This is a simulated response for testing purposes."

    return PromptTestResponse(
        response=response_text,
        tokens_in=len(request.prompt.split()) + len(request.input.split()),
        tokens_out=len(response_text.split()),
        latency=time.time() - start_time,
    )

