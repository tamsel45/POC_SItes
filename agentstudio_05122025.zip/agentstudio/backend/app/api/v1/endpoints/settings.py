from fastapi import APIRouter
from pydantic import BaseModel
from typing import Optional

router = APIRouter()


class SettingsUpdate(BaseModel):
    # General
    workspaceName: Optional[str] = None
    timezone: Optional[str] = None
    language: Optional[str] = None
    
    # Security
    twoFactorEnabled: Optional[bool] = None
    sessionTimeout: Optional[str] = None
    
    # Notifications
    emailNotifications: Optional[bool] = None
    slackNotifications: Optional[bool] = None
    webhookNotifications: Optional[bool] = None


@router.get("")
async def get_settings():
    """Get user settings"""
    return {
        "workspaceName": "My Workspace",
        "timezone": "America/New_York",
        "language": "en",
        "twoFactorEnabled": False,
        "sessionTimeout": "30",
        "emailNotifications": True,
        "slackNotifications": False,
        "webhookNotifications": False
    }


@router.put("")
async def update_settings(data: SettingsUpdate):
    """Update user settings"""
    return {
        "success": True,
        "message": "Settings updated successfully",
        "data": data.dict()
    }


class PasswordChange(BaseModel):
    currentPassword: str
    newPassword: str


@router.post("/change-password")
async def change_password(data: PasswordChange):
    """Change user password"""
    # In production, validate current password and hash new one
    return {
        "success": True,
        "message": "Password changed successfully"
    }

