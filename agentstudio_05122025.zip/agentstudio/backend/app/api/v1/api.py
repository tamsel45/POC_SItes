"""
API router aggregator.
"""
from fastapi import APIRouter

from app.api.v1.endpoints import (
    agents, 
    prompts, 
    knowledge_base, 
    testing, 
    analytics, 
    auth,
    users,
    settings,
    deployments,
    models
)

api_router = APIRouter()

# Include all endpoint routers
api_router.include_router(auth.router, prefix="/auth", tags=["Authentication"])
api_router.include_router(agents.router, prefix="/agents", tags=["Agents"])
api_router.include_router(prompts.router, prefix="/prompts", tags=["Prompts"])
api_router.include_router(knowledge_base.router, prefix="/knowledge-base", tags=["Knowledge Base"])
api_router.include_router(testing.router, prefix="/testing", tags=["Testing"])
api_router.include_router(analytics.router, prefix="/analytics", tags=["Analytics"])
api_router.include_router(users.router, prefix="/users", tags=["Users"])
api_router.include_router(settings.router, prefix="/settings", tags=["Settings"])
api_router.include_router(deployments.router, prefix="/deployments", tags=["Deployments"])
api_router.include_router(models.router, prefix="/models", tags=["Models"])

