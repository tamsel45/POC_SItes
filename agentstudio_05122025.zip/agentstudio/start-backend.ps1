# Agent Studio - Simple Local Test

Write-Host "================================" -ForegroundColor Cyan
Write-Host "Agent Studio Local Test" -ForegroundColor Cyan
Write-Host "================================" -ForegroundColor Cyan
Write-Host ""

# Set environment variables
$env:SECRET_KEY = "super-secret-key-change-in-production-min-32-chars-long"
$env:DEBUG = "true"
$env:ALLOWED_ORIGINS = "http://localhost:3000,http://localhost:5173"

Write-Host "Starting backend server..." -ForegroundColor Yellow
Write-Host ""

cd backend
python -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000

