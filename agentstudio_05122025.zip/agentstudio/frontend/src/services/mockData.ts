// Mock data for standalone frontend development - Orchestra AI Platform
// Reflects current Orchestra capabilities: MAESTRO, CLIENTELE, DocIntel, Knowledge Base, RAG

export const mockAgents = [
  {
    id: 'maestro-001',
    name: 'Product Information Q&A',
    description: 'Answers questions about product catalog using Knowledge Base RAG',
    status: 'active',
    framework: 'MAESTRO',
    language_model: 'Llama 3.1 70B',
    temperature: 0.2,
    max_tokens: 2000,
    tags: ['knowledge-base', 'rag', 'production'],
    conversation_count: 2456,
    success_rate: 96.8,
    avg_response_time: 2.8,
    created_at: '2024-01-15T10:00:00Z',
    updated_at: '2024-12-01T10:00:00Z',
    created_by: 'Subha',
    knowledge_base_id: 'kb-product-catalog',
    app_type: 'knowledge_base_qa',
  },
  {
    id: 'maestro-002',
    name: 'HR Policy Assistant',
    description: 'Employee handbook and benefits Q&A using Document Intelligence',
    status: 'active',
    framework: 'MAESTRO',
    language_model: 'Llama 3.1 8B',
    temperature: 0.1,
    max_tokens: 1500,
    tags: ['hr', 'document-qa', 'production'],
    conversation_count: 1834,
    success_rate: 94.5,
    avg_response_time: 2.1,
    created_at: '2024-02-10T09:00:00Z',
    updated_at: '2024-11-28T09:00:00Z',
    created_by: 'Harikrishnan',
    knowledge_base_id: 'kb-hr-policies',
    app_type: 'document_qa',
  },
  {
    id: 'maestro-003',
    name: 'Market Research Assistant',
    description: 'Answers questions about market research reports and commentary',
    status: 'active',
    framework: 'MAESTRO',
    language_model: 'Mistral Large 2',
    temperature: 0.3,
    max_tokens: 3000,
    tags: ['research', 'market-analysis', 'production'],
    conversation_count: 3421,
    success_rate: 92.3,
    avg_response_time: 3.2,
    created_at: '2024-02-15T10:00:00Z',
    updated_at: '2024-12-02T11:00:00Z',
    created_by: 'Marc Batrand',
    knowledge_base_id: 'kb-market-research',
    app_type: 'knowledge_base_qa',
  },
  {
    id: 'docintel-001',
    name: 'Contract Review Assistant',
    description: 'Extract key terms from legal contracts using Document Intelligence',
    status: 'testing',
    framework: 'DocIntel',
    language_model: 'GPT-4 Turbo (Azure)',
    temperature: 0.0,
    max_tokens: 4000,
    tags: ['legal', 'extraction', 'staging'],
    conversation_count: 156,
    success_rate: 98.2,
    avg_response_time: 4.5,
    created_at: '2024-11-01T14:00:00Z',
    updated_at: '2024-12-03T14:00:00Z',
    created_by: 'Sathish',
    app_type: 'document_intelligence',
    documents_processed: 127,
  },
  {
    id: 'clientele-001',
    name: 'Client Intelligence API',
    description: 'Custom CLIENTELE integration for client data aggregation',
    status: 'active',
    framework: 'CLIENTELE',
    language_model: 'Mixtral 8x7B',
    temperature: 0.5,
    max_tokens: 2000,
    tags: ['api', 'integration', 'production'],
    conversation_count: 8934,
    success_rate: 99.7,
    avg_response_time: 1.8,
    created_at: '2024-09-15T10:00:00Z',
    updated_at: '2024-12-04T10:00:00Z',
    created_by: 'Mark Web',
    app_type: 'custom_integration',
    daily_requests: 2456,
  },
]

export const mockPrompts = [
  {
    id: 'prompt-001',
    agent_id: 'maestro-001',
    name: 'Product Catalog Q&A System Prompt',
    content: `You are an expert product information assistant. Your role is to:

1. Answer questions about products using the provided knowledge base
2. Provide accurate specifications, pricing, and availability
3. Cite specific sources from the knowledge base
4. Admit when information is not available

Guidelines:
- Always ground responses in the retrieved knowledge base chunks
- Keep responses concise and factual (under 200 words)
- Include product codes when relevant
- Format technical specifications clearly

If you cannot find the information in the knowledge base, respond: "I don't have that information in the current product catalog. Please contact sales for details."`,
    version: 'v2.1',
    variables: [],
    few_shot_examples: [
      {
        user_input: 'What are the specs for the X200 series?',
        assistant_output:
          'According to the product catalog, the X200 series features: 128GB storage, 8GB RAM, 6.5" display. Available in three colors. Product code: X200-STD.',
      },
    ],
    created_at: '2024-01-15T10:00:00Z',
    updated_at: '2024-12-01T10:00:00Z',
    created_by: 'Subha',
  },
  {
    id: 'prompt-002',
    agent_id: 'maestro-003',
    name: 'Market Research Analysis Prompt',
    content: `You are a market research analyst assistant. Analyze and synthesize information from market research reports.

Your responsibilities:
1. Answer questions about market trends, sectors, and economic data
2. Summarize findings from multiple research documents
3. Highlight key statistics and developments
4. Provide balanced, data-driven insights

Guidelines:
- Cite specific reports and page numbers when possible
- Acknowledge limitations and data recency
- Use precise terminology for financial/market concepts
- Temperature: 0.3 for balanced creativity and accuracy

Always disclose: "This analysis is based on available research reports as of [date]. Markets change rapidly; consult current sources for trading decisions."`,
    version: 'v1.5',
    variables: [],
    few_shot_examples: [],
    created_at: '2024-02-15T10:00:00Z',
    updated_at: '2024-12-02T11:00:00Z',
    created_by: 'Marc Batrand',
  },
]

export const mockDocuments = [
  {
    id: 'doc-001',
    filename: 'Q3_2024_Market_Report.pdf',
    knowledge_base_id: 'kb-market-research',
    type: 'pdf',
    size: 3245678,
    size_bytes: 3245678,
    page_count: 47,
    chunks: 183,
    chunks_created: 183,
    status: 'indexed',
    embeddings_complete: true,
    uploaded_at: '2024-10-15T14:00:00Z',
    last_indexed: '2024-10-15T15:30:00Z',
    uploaded_by: 'Marc Batrand',
    extraction_quality_score: 0.94,
    metadata: {
      quarter: 'Q3',
      year: '2024',
      report_type: 'market_analysis',
      sectors: ['technology', 'healthcare', 'finance'],
    },
  },
  {
    id: 'doc-002',
    filename: 'Employee_Handbook_2024.docx',
    knowledge_base_id: 'kb-hr-policies',
    type: 'docx',
    size: 456789,
    size_bytes: 456789,
    page_count: 89,
    chunks: 234,
    chunks_created: 234,
    status: 'indexed',
    embeddings_complete: true,
    uploaded_at: '2024-01-10T09:00:00Z',
    last_indexed: '2024-01-10T10:30:00Z',
    uploaded_by: 'Harikrishnan',
    extraction_quality_score: 0.98,
    metadata: {
      year: '2024',
      document_type: 'policy',
      effective_date: '2024-01-01',
    },
  },
  {
    id: 'doc-003',
    filename: 'Product_Specifications_2024.pdf',
    knowledge_base_id: 'kb-product-catalog',
    type: 'pdf',
    size: 1847296,
    size_bytes: 1847296,
    page_count: 156,
    chunks: 412,
    chunks_created: 412,
    status: 'indexed',
    embeddings_complete: true,
    uploaded_at: '2024-01-15T10:00:00Z',
    last_indexed: '2024-11-30T16:00:00Z',
    uploaded_by: 'Subha',
    extraction_quality_score: 0.96,
    metadata: {
      year: '2024',
      document_type: 'specification',
      category: 'products',
    },
  },
  {
    id: 'doc-004',
    filename: 'Trade_Confirmation_Batch_20241201.pdf',
    knowledge_base_id: 'kb-trade-docs',
    type: 'pdf',
    size: 12456789,
    size_bytes: 12456789,
    page_count: 523,
    chunks: 351,
    chunks_created: 351,
    status: 'processing',
    embeddings_complete: false,
    uploaded_at: '2024-12-01T16:00:00Z',
    last_indexed: null,
    uploaded_by: 'Karthikeyan',
    processing_progress: 67,
    metadata: {
      date: '2024-12-01',
      document_type: 'trade_confirmation',
      batch_id: 'BATCH_20241201',
    },
  },
  {
    id: 'doc-005',
    filename: 'Semiconductor_Industry_Report_Nov2024.pdf',
    knowledge_base_id: 'kb-market-research',
    type: 'pdf',
    size: 5234891,
    size_bytes: 5234891,
    page_count: 234,
    chunks: 567,
    chunks_created: 567,
    status: 'indexed',
    embeddings_complete: true,
    uploaded_at: '2024-11-28T10:00:00Z',
    last_indexed: '2024-11-28T12:45:00Z',
    uploaded_by: 'Marc Batrand',
    extraction_quality_score: 0.91,
    metadata: {
      month: 'November',
      year: '2024',
      report_type: 'industry_analysis',
      sector: 'semiconductor',
    },
  },
]

export const mockKnowledgeBaseStats = {
  total_documents: 456,
  total_chunks: 12543,
  vector_store_size: 125456789,
  embedding_model: 'text-embedding-ada-002',
  vector_store: 'pinecone',
  last_full_reindex: '2024-12-02T09:00:00Z',
  avg_retrieval_time: 0.145,
  knowledge_bases: [
    {
      id: 'kb-market-research',
      name: 'Market Research Repository',
      document_count: 456,
      total_chunks: 12543,
      queries_7d: 18234,
    },
    {
      id: 'kb-product-catalog',
      name: 'Product Catalog 2024',
      document_count: 23,
      total_chunks: 1847,
      queries_7d: 12456,
    },
    {
      id: 'kb-hr-policies',
      name: 'HR Policies & Handbook',
      document_count: 34,
      total_chunks: 1234,
      queries_7d: 8945,
    },
    {
      id: 'kb-compliance-docs',
      name: 'Compliance & Regulatory',
      document_count: 178,
      total_chunks: 8921,
      queries_7d: 6012,
    },
  ],
}

export const mockAnalytics = {
  metrics: {
    total_queries: 45678,
    total_conversations: 45678,
    success_rate: 94.2,
    avg_latency: 2.8,
    avg_response_time_seconds: 2.8,
    user_satisfaction: 93.7,
    uptime_percentage: 99.94,
    active_maestro_apps: 23,
    active_clientele_apps: 8,
    active_users: 234,
  },
  token_usage: {
    total_tokens: 125456789,
    input_tokens: 78234567,
    output_tokens: 47222222,
    estimated_cost_usd: 3456.78,
  },
  model_distribution: [
    { name: 'Llama 3.1 8B', percentage: 35, count: 15987, color: '#0078d4' },
    { name: 'Llama 3.1 70B', percentage: 28, count: 12795, color: '#107c10' },
    { name: 'GPT-4 Turbo (Azure)', percentage: 20, count: 9139, color: '#881798' },
    { name: 'Mixtral 8x7B', percentage: 12, count: 5482, color: '#faa500' },
    { name: 'Mistral Large 2', percentage: 5, count: 2283, color: '#d13438' },
  ],
  conversation_trends: Array.from({ length: 30 }, (_, i) => ({
    date: `Day ${i + 1}`,
    queries: Math.floor(Math.random() * 800) + 1200,
    success: Math.floor(Math.random() * 750) + 1150,
  })),
  response_time_distribution: [
    { bucket: '<1s', count: 5234 },
    { bucket: '1-2s', count: 12456 },
    { bucket: '2-3s', count: 18234 },
    { bucket: '3-5s', count: 7891 },
    { bucket: '>5s', count: 1863 },
  ],
  top_knowledge_bases: [
    { name: 'Market Research', queries: 18234, percentage: 40.0 },
    { name: 'Product Catalog', queries: 12456, percentage: 27.0 },
    { name: 'HR Policies', queries: 8945, percentage: 20.0 },
    { name: 'Compliance Docs', queries: 6012, percentage: 13.0 },
  ],
  query_categories: [
    { category: 'Market Analysis', percentage: 32.0, count: 14617 },
    { category: 'Product Information', percentage: 24.0, count: 10963 },
    { category: 'HR Policies', percentage: 18.0, count: 8222 },
    { category: 'Compliance Queries', percentage: 15.0, count: 6852 },
    { category: 'Document Extraction', percentage: 8.0, count: 3654 },
    { category: 'Other', percentage: 3.0, count: 1370 },
  ],
  error_breakdown: [
    { type: 'Retrieval Timeout', count: 187, percentage: 38.0 },
    { type: 'No Relevant Chunks', count: 145, percentage: 29.0 },
    { type: 'Model API Error', count: 98, percentage: 20.0 },
    { type: 'Token Limit Exceeded', count: 67, percentage: 13.0 },
  ],
  cost_breakdown: [
    { category: 'LLM API Calls (Azure GPT-4)', amount: 1234.56, percentage: 36.0 },
    { category: 'LLM API Calls (Llama Models)', amount: 987.45, percentage: 29.0 },
    { category: 'LLM API Calls (Mistral Models)', amount: 654.32, percentage: 19.0 },
    { category: 'Embeddings', amount: 456.34, percentage: 13.0 },
    { category: 'Vector Store (Pinecone)', amount: 67.89, percentage: 2.0 },
    { category: 'Document Storage', amount: 56.22, percentage: 1.0 },
  ],
  user_satisfaction: {
    thumbs_up: 3456,
    thumbs_down: 234,
    satisfaction_rate: 93.7,
    avg_rating: 4.7,
  },
  recent_queries: [
    {
      id: 'query-001',
      query: 'What were Q3 earnings for the tech sector?',
      knowledge_base: 'Market Research',
      response_time_ms: 2834,
      chunks_retrieved: 5,
      timestamp: '2024-12-04T14:23:45Z',
      feedback: 'thumbs_up',
    },
    {
      id: 'query-002',
      query: 'What is the remote work policy?',
      knowledge_base: 'HR Policies',
      response_time_ms: 1654,
      chunks_retrieved: 3,
      timestamp: '2024-12-04T10:15:22Z',
      feedback: 'thumbs_up',
    },
    {
      id: 'query-003',
      query: 'Summarize semiconductor regulation developments',
      knowledge_base: 'Market Research',
      response_time_ms: 3421,
      chunks_retrieved: 8,
      timestamp: '2024-12-04T16:45:11Z',
      feedback: null,
    },
  ],
}

// Helper function to simulate API delay
export const delay = (ms: number = 300) =>
  new Promise((resolve) => setTimeout(resolve, ms))

