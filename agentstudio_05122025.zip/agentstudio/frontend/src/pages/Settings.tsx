import { useState, useEffect } from 'react'
import { toast } from 'react-toastify'
import { apiClient } from '../services/api'
import './Settings.css'

export default function Settings() {
  const [activeTab, setActiveTab] = useState<'general' | 'security' | 'notifications' | 'billing'>('general')
  const [isSaving, setIsSaving] = useState(false)
  const [hasChanges, setHasChanges] = useState(false)
  
  // General Settings
  const [workspaceName, setWorkspaceName] = useState('My Workspace')
  const [timezone, setTimezone] = useState('America/New_York')
  const [language, setLanguage] = useState('en')
  const [initialGeneral, setInitialGeneral] = useState({ workspaceName: 'My Workspace', timezone: 'America/New_York', language: 'en' })
  
  // Security Settings
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(false)
  const [sessionTimeout, setSessionTimeout] = useState('30')
  const [initialSecurity, setInitialSecurity] = useState({ twoFactorEnabled: false, sessionTimeout: '30' })
  
  // Notification Settings
  const [emailNotifications, setEmailNotifications] = useState(true)
  const [slackNotifications, setSlackNotifications] = useState(false)
  const [webhookNotifications, setWebhookNotifications] = useState(false)
  const [initialNotifications, setInitialNotifications] = useState({ emailNotifications: true, slackNotifications: false, webhookNotifications: false })

  // Load settings on mount
  useEffect(() => {
    loadSettings()
  }, [])

  // Track changes for current tab
  useEffect(() => {
    if (activeTab === 'general') {
      setHasChanges(
        workspaceName !== initialGeneral.workspaceName ||
        timezone !== initialGeneral.timezone ||
        language !== initialGeneral.language
      )
    } else if (activeTab === 'security') {
      setHasChanges(
        twoFactorEnabled !== initialSecurity.twoFactorEnabled ||
        sessionTimeout !== initialSecurity.sessionTimeout
      )
    } else if (activeTab === 'notifications') {
      setHasChanges(
        emailNotifications !== initialNotifications.emailNotifications ||
        slackNotifications !== initialNotifications.slackNotifications ||
        webhookNotifications !== initialNotifications.webhookNotifications
      )
    }
  }, [activeTab, workspaceName, timezone, language, twoFactorEnabled, sessionTimeout, emailNotifications, slackNotifications, webhookNotifications])

  const loadSettings = async () => {
    try {
      const response = await apiClient.get('/settings')
      const settings = response.data
      
      // General
      setWorkspaceName(settings.workspaceName || 'My Workspace')
      setTimezone(settings.timezone || 'America/New_York')
      setLanguage(settings.language || 'en')
      setInitialGeneral({ workspaceName: settings.workspaceName, timezone: settings.timezone, language: settings.language })
      
      // Security
      setTwoFactorEnabled(settings.twoFactorEnabled || false)
      setSessionTimeout(settings.sessionTimeout || '30')
      setInitialSecurity({ twoFactorEnabled: settings.twoFactorEnabled, sessionTimeout: settings.sessionTimeout })
      
      // Notifications
      setEmailNotifications(settings.emailNotifications ?? true)
      setSlackNotifications(settings.slackNotifications || false)
      setWebhookNotifications(settings.webhookNotifications || false)
      setInitialNotifications({ emailNotifications: settings.emailNotifications, slackNotifications: settings.slackNotifications, webhookNotifications: settings.webhookNotifications })
    } catch (error) {
      console.log('Using default settings')
    }
  }

  const handleSave = async () => {
    setIsSaving(true)
    try {
      let updateData = {}
      
      if (activeTab === 'general') {
        updateData = { workspaceName, timezone, language }
        setInitialGeneral({ workspaceName, timezone, language })
      } else if (activeTab === 'security') {
        updateData = { twoFactorEnabled, sessionTimeout }
        setInitialSecurity({ twoFactorEnabled, sessionTimeout })
      } else if (activeTab === 'notifications') {
        updateData = { emailNotifications, slackNotifications, webhookNotifications }
        setInitialNotifications({ emailNotifications, slackNotifications, webhookNotifications })
      }
      
      await apiClient.put('/settings', updateData)
      toast.success(`✅ ${activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} settings saved successfully!`)
      setHasChanges(false)
    } catch (error: any) {
      console.error('Settings update error:', error)
      toast.error(error.response?.data?.detail || 'Failed to save settings')
    } finally {
      setIsSaving(false)
    }
  }

  const handleChangePassword = () => {
    const currentPassword = prompt('Enter current password:')
    if (!currentPassword) return
    
    const newPassword = prompt('Enter new password:')
    if (!newPassword) return
    
    const confirmPassword = prompt('Confirm new password:')
    if (newPassword !== confirmPassword) {
      toast.error('Passwords do not match')
      return
    }
    
    apiClient.post('/auth/change-password', { currentPassword, newPassword })
      .then(() => toast.success('Password changed successfully'))
      .catch(() => toast.error('Failed to change password'))
  }

  return (
    <div className="settings-page">
      {/* Header */}
      <div className="settings-header">
        <div>
          <h1 className="page-title">Settings</h1>
          <p className="page-subtitle">Manage workspace and account settings</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="settings-tabs">
        <button
          className={`tab ${activeTab === 'general' ? 'active' : ''}`}
          onClick={() => setActiveTab('general')}
        >
          <span className="tab-icon">⚙️</span>
          General
        </button>
        <button
          className={`tab ${activeTab === 'security' ? 'active' : ''}`}
          onClick={() => setActiveTab('security')}
        >
          <span className="tab-icon">🔒</span>
          Security
        </button>
        <button
          className={`tab ${activeTab === 'notifications' ? 'active' : ''}`}
          onClick={() => setActiveTab('notifications')}
        >
          <span className="tab-icon">🔔</span>
          Notifications
        </button>
        <button
          className={`tab ${activeTab === 'billing' ? 'active' : ''}`}
          onClick={() => setActiveTab('billing')}
        >
          <span className="tab-icon">💳</span>
          Billing
        </button>
      </div>

      {/* Tab Content */}
      <div className="settings-content">
        {/* General Tab */}
        {activeTab === 'general' && (
          <div className="settings-section card">
            <h3 className="section-title">General Settings</h3>
            
            <div className="form-group">
              <label htmlFor="workspace-name">Workspace Name</label>
              <input
                type="text"
                id="workspace-name"
                className="form-input"
                value={workspaceName}
                onChange={(e) => setWorkspaceName(e.target.value)}
              />
            </div>

            <div className="form-group">
              <label htmlFor="timezone">Timezone</label>
              <select
                id="timezone"
                className="form-select"
                value={timezone}
                onChange={(e) => setTimezone(e.target.value)}
              >
                <option value="America/New_York">Eastern Time (ET)</option>
                <option value="America/Chicago">Central Time (CT)</option>
                <option value="America/Denver">Mountain Time (MT)</option>
                <option value="America/Los_Angeles">Pacific Time (PT)</option>
                <option value="UTC">UTC</option>
              </select>
            </div>

            <div className="form-group">
              <label htmlFor="language">Language</label>
              <select
                id="language"
                className="form-select"
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
              >
                <option value="en">English</option>
                <option value="es">Spanish</option>
                <option value="fr">French</option>
                <option value="de">German</option>
                <option value="zh">Chinese</option>
              </select>
            </div>

            <div className="form-actions">
              <button 
                className="btn btn-primary" 
                onClick={handleSave}
                disabled={isSaving || !hasChanges}
              >
                {isSaving ? '💾 Saving...' : hasChanges ? '💾 Save Changes' : '✅ Saved'}
              </button>
            </div>
          </div>
        )}

        {/* Security Tab */}
        {activeTab === 'security' && (
          <div className="settings-section card">
            <h3 className="section-title">Security Settings</h3>
            
            <div className="setting-item">
              <div className="setting-info">
                <div className="setting-name">Two-Factor Authentication</div>
                <div className="setting-description">
                  Add an extra layer of security to your account
                </div>
              </div>
              <label className="toggle-switch">
                <input
                  type="checkbox"
                  checked={twoFactorEnabled}
                  onChange={(e) => setTwoFactorEnabled(e.target.checked)}
                />
                <span className="toggle-slider"></span>
              </label>
            </div>

            <div className="form-group">
              <label htmlFor="session-timeout">Session Timeout (minutes)</label>
              <select
                id="session-timeout"
                className="form-select"
                value={sessionTimeout}
                onChange={(e) => setSessionTimeout(e.target.value)}
              >
                <option value="15">15 minutes</option>
                <option value="30">30 minutes</option>
                <option value="60">1 hour</option>
                <option value="120">2 hours</option>
                <option value="never">Never</option>
              </select>
            </div>

            <div className="form-group">
              <label>Password</label>
              <button className="btn btn-secondary" onClick={handleChangePassword}>Change Password</button>
            </div>

            <div className="form-actions">
              <button 
                className="btn btn-primary" 
                onClick={handleSave}
                disabled={isSaving || !hasChanges}
              >
                {isSaving ? '💾 Saving...' : hasChanges ? '💾 Save Changes' : '✅ Saved'}
              </button>
            </div>
          </div>
        )}

        {/* Notifications Tab */}
        {activeTab === 'notifications' && (
          <div className="settings-section card">
            <h3 className="section-title">Notification Preferences</h3>
            
            <div className="setting-item">
              <div className="setting-info">
                <div className="setting-name">Email Notifications</div>
                <div className="setting-description">
                  Receive updates and alerts via email
                </div>
              </div>
              <label className="toggle-switch">
                <input
                  type="checkbox"
                  checked={emailNotifications}
                  onChange={(e) => setEmailNotifications(e.target.checked)}
                />
                <span className="toggle-slider"></span>
              </label>
            </div>

            <div className="setting-item">
              <div className="setting-info">
                <div className="setting-name">Slack Notifications</div>
                <div className="setting-description">
                  Send alerts to your Slack workspace
                </div>
              </div>
              <label className="toggle-switch">
                <input
                  type="checkbox"
                  checked={slackNotifications}
                  onChange={(e) => setSlackNotifications(e.target.checked)}
                />
                <span className="toggle-slider"></span>
              </label>
            </div>

            <div className="setting-item">
              <div className="setting-info">
                <div className="setting-name">Webhook Notifications</div>
                <div className="setting-description">
                  Send events to custom webhook endpoints
                </div>
              </div>
              <label className="toggle-switch">
                <input
                  type="checkbox"
                  checked={webhookNotifications}
                  onChange={(e) => setWebhookNotifications(e.target.checked)}
                />
                <span className="toggle-slider"></span>
              </label>
            </div>

            <div className="form-actions">
              <button 
                className="btn btn-primary" 
                onClick={handleSave}
                disabled={isSaving || !hasChanges}
              >
                {isSaving ? '💾 Saving...' : hasChanges ? '💾 Save Changes' : '✅ Saved'}
              </button>
            </div>
          </div>
        )}

        {/* Billing Tab */}
        {activeTab === 'billing' && (
          <div className="settings-section card">
            <h3 className="section-title">Billing & Subscription</h3>
            
            <div className="billing-info">
              <div className="plan-card">
                <div className="plan-header">
                  <h4>Professional Plan</h4>
                  <span className="plan-price">$99/month</span>
                </div>
                <ul className="plan-features">
                  <li>✓ Unlimited agents</li>
                  <li>✓ 100,000 requests/month</li>
                  <li>✓ Advanced analytics</li>
                  <li>✓ Priority support</li>
                </ul>
                <button className="btn btn-secondary">Upgrade Plan</button>
              </div>

              <div className="billing-details">
                <h4>Payment Method</h4>
                <div className="payment-method">
                  <span className="card-icon">💳</span>
                  <div>
                    <div>Visa ending in 4242</div>
                    <div className="card-expiry">Expires 12/2025</div>
                  </div>
                  <button className="btn btn-secondary btn-sm">Update</button>
                </div>

                <h4>Billing History</h4>
                <div className="billing-history">
                  <div className="history-item">
                    <span>Dec 1, 2024</span>
                    <span>$99.00</span>
                    <button className="btn-link">Download</button>
                  </div>
                  <div className="history-item">
                    <span>Nov 1, 2024</span>
                    <span>$99.00</span>
                    <button className="btn-link">Download</button>
                  </div>
                  <div className="history-item">
                    <span>Oct 1, 2024</span>
                    <span>$99.00</span>
                    <button className="btn-link">Download</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

