import { useState } from 'react'
import { useParams } from 'react-router-dom'
import {
  Card,
  Button,
  Input,
  Textarea,
  Select,
  Tab,
  TabList,
  Switch,
  Badge,
} from '@fluentui/react-components'
import {
  PlayRegular,
  SaveRegular,
  HistoryRegular,
  ChartMultipleRegular,
  DeleteRegular,
  CopyRegular,
  ArrowRepeatAllRegular,
} from '@fluentui/react-icons'
import { toast } from 'react-toastify'
import { testingApi } from '../services/api'
import './TestingConsole.css'

interface Message {
  role: 'user' | 'assistant' | 'system'
  content: string
  timestamp: Date
  metadata?: {
    latency?: number
    tokens_in?: number
    tokens_out?: number
    cost?: number
    model?: string
  }
}

export default function TestingConsole() {
  const { id } = useParams()
  const [activeTab, setActiveTab] = useState('single')
  const [messages, setMessages] = useState<Message[]>([])
  const [inputText, setInputText] = useState('')
  const [loading, setLoading] = useState(false)
  const [testHistory, setTestHistory] = useState<any[]>([])
  const [compareMode, setCompareMode] = useState(false)
  const [selectedTests, setSelectedTests] = useState<string[]>([])
  
  // A/B Comparison State
  const [compareInputs, setCompareInputs] = useState([
    { input: 'What is artificial intelligence?', loading: false, response: null as any },
    { input: 'What is artificial intelligence?', loading: false, response: null as any },
  ])
  const [compareConfigA, setCompareConfigA] = useState({
    model: 'GPT-4 Turbo',
    temperature: 0.7,
    systemPrompt: 'You are a helpful AI assistant.',
  })
  const [compareConfigB, setCompareConfigB] = useState({
    model: 'GPT-3.5 Turbo',
    temperature: 0.5,
    systemPrompt: 'You are a helpful AI assistant.',
  })

  // Single Test State
  const [systemPrompt, setSystemPrompt] = useState('')
  const [temperature, setTemperature] = useState(0.7)
  const [debugMode, setDebugMode] = useState(true)

  // Batch Test State
  const [batchTests, setBatchTests] = useState([
    { input: 'Hello, how can you help me?', expected: '' },
    { input: 'What are your capabilities?', expected: '' },
  ])

  const handleSendMessage = async () => {
    if (!inputText.trim()) return

    const userMessage: Message = {
      role: 'user',
      content: inputText,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInputText('')
    setLoading(true)

    try {
      const response = await testingApi.runSingle(id!, inputText, debugMode)

      const assistantMessage: Message = {
        role: 'assistant',
        content: response.data.output,
        timestamp: new Date(),
        metadata: {
          latency: response.data.latency,
          tokens_in: response.data.tokens_in,
          tokens_out: response.data.tokens_out,
          cost: response.data.tokens_in * 0.00001 + response.data.tokens_out * 0.00003,
          model: response.data.debug?.model || 'GPT-4 Turbo',
        },
      }

      setMessages((prev) => [...prev, assistantMessage])
      
      // Add to history
      setTestHistory((prev) => [
        {
          id: Date.now().toString(),
          input: inputText,
          output: response.data.output,
          metadata: assistantMessage.metadata,
          timestamp: new Date(),
        },
        ...prev,
      ].slice(0, 50))
    } catch (error) {
      toast.error('Failed to send message')
    } finally {
      setLoading(false)
    }
  }

  const handleRunBatchTests = async () => {
    setLoading(true)
    try {
      const response = await testingApi.runBatch({
        agent_id: id!,
        test_cases: batchTests.map((test) => ({
          input: test.input,
          expected_output: test.expected,
          expected_keywords: [],
        })),
      })
      toast.success(`Batch test completed! ${response.data.passed} passed, ${response.data.failed} failed`)
    } catch (error) {
      toast.error('Failed to run batch tests')
    } finally {
      setLoading(false)
    }
  }

  const addBatchTest = () => {
    setBatchTests([...batchTests, { input: '', expected: '' }])
  }

  const removeBatchTest = (index: number) => {
    setBatchTests(batchTests.filter((_, i) => i !== index))
  }

  const updateBatchTest = (index: number, field: 'input' | 'expected', value: string) => {
    const updated = [...batchTests]
    updated[index][field] = value
    setBatchTests(updated)
  }
  
  const handleCompareTest = async (configIndex: number) => {
    const config = configIndex === 0 ? compareConfigA : compareConfigB
    const input = compareInputs[0].input // Use the same input for both
    
    if (!input.trim()) {
      toast.warning('Please enter test input')
      return
    }
    
    const updatedInputs = [...compareInputs]
    updatedInputs[configIndex].loading = true
    setCompareInputs(updatedInputs)
    
    try {
      const response = await testingApi.runSingle(id || 'test-agent', input, true)
      
      updatedInputs[configIndex].response = {
        output: response.data.output,
        latency: response.data.latency,
        tokens_in: response.data.tokens_in,
        tokens_out: response.data.tokens_out,
        cost: response.data.tokens_in * 0.00001 + response.data.tokens_out * 0.00003,
        model: config.model,
        temperature: config.temperature,
      }
      updatedInputs[configIndex].loading = false
      setCompareInputs(updatedInputs)
    } catch (error) {
      toast.error(`Failed to run test ${configIndex === 0 ? 'A' : 'B'}`)
      updatedInputs[configIndex].loading = false
      setCompareInputs(updatedInputs)
    }
  }
  
  const handleRunBothComparison = async () => {
    await Promise.all([handleCompareTest(0), handleCompareTest(1)])
  }

  return (
    <div className="testing-console">
      {/* Header */}
      <div className="console-header">
        <div>
          <h1 className="page-title">Testing Console</h1>
          <p className="page-subtitle">Test and debug your AI agents in real-time</p>
        </div>
        <div className="header-actions">
          <Button icon={<HistoryRegular />}>View History</Button>
          <Button icon={<ChartMultipleRegular />}>Compare Results</Button>
          <Button icon={<SaveRegular />}>Save Session</Button>
        </div>
      </div>

      {/* Tabs */}
      <Card className="tabs-card">
        <TabList
          selectedValue={activeTab}
          onTabSelect={(_, data) => setActiveTab(data.value as string)}
          size="large"
        >
          <Tab value="single" icon={<PlayRegular />}>
            Single Test
          </Tab>
          <Tab value="batch" icon={<ArrowRepeatAllRegular />}>
            Batch Testing
          </Tab>
          <Tab value="history" icon={<HistoryRegular />}>
            Test History ({testHistory.length})
          </Tab>
          <Tab value="compare">A/B Comparison</Tab>
        </TabList>
      </Card>

      {/* Single Test */}
      {activeTab === 'single' && (
        <div className="console-layout">
          {/* Chat Area */}
          <Card className="chat-card">
            <div className="chat-header">
              <h3 className="chat-title">💬 Conversation</h3>
              <div className="chat-controls">
                <Switch checked={debugMode} onChange={(_, data) => setDebugMode(data.checked)} />
                <span className="control-label">Debug Mode</span>
                <Button
                  icon={<DeleteRegular />}
                  appearance="subtle"
                  size="small"
                  onClick={() => setMessages([])}
                >
                  Clear
                </Button>
              </div>
            </div>

            <div className="messages-container">
              {messages.length === 0 ? (
                <div className="empty-chat">
                  <div className="empty-icon">💬</div>
                  <h3>Start a conversation</h3>
                  <p>Send a message to test your agent</p>
                </div>
              ) : (
                messages.map((msg, idx) => (
                  <div key={idx} className={`message ${msg.role}`}>
                    <div className="message-header">
                      <div className="message-avatar">
                        {msg.role === 'user' ? '👤' : '🤖'}
                      </div>
                      <div className="message-info">
                        <span className="message-role">
                          {msg.role === 'user' ? 'You' : 'Agent'}
                        </span>
                        <span className="message-time">
                          {msg.timestamp.toLocaleTimeString()}
                        </span>
                      </div>
                      <Button icon={<CopyRegular />} appearance="subtle" size="small" />
                    </div>
                    <div className="message-content">{msg.content}</div>
                    {msg.metadata && (
                      <div className="message-metadata">
                        <Badge appearance="tint" size="small">
                          ⚡ {msg.metadata.latency?.toFixed(2)}s
                        </Badge>
                        <Badge appearance="tint" size="small">
                          📊 {msg.metadata.tokens_in} → {msg.metadata.tokens_out} tokens
                        </Badge>
                        <Badge appearance="tint" size="small">
                          💰 ${msg.metadata.cost?.toFixed(4)}
                        </Badge>
                        <Badge appearance="tint" size="small">
                          {msg.metadata.model}
                        </Badge>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>

            <div className="input-area">
              <Textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault()
                    handleSendMessage()
                  }
                }}
                placeholder="Type your message... (Shift+Enter for new line)"
                className="message-input"
                rows={3}
                disabled={loading}
              />
              <Button
                icon={<PlayRegular />}
                appearance="primary"
                onClick={handleSendMessage}
                disabled={loading}
                size="large"
              >
                {loading ? 'Sending...' : 'Send'}
              </Button>
            </div>
          </Card>

          {/* Settings Panel */}
          <Card className="settings-panel">
            <h3 className="panel-title">⚙️ Test Settings</h3>
            
            <div className="settings-form">
              <div className="form-field">
                <label>System Prompt Override</label>
                <Textarea
                  value={systemPrompt}
                  onChange={(e) => setSystemPrompt(e.target.value)}
                  placeholder="Optional: Override the agent's system prompt"
                  rows={4}
                />
              </div>

              <div className="form-field">
                <label>Temperature: {temperature}</label>
                <input
                  type="range"
                  min="0"
                  max="2"
                  step="0.1"
                  value={temperature}
                  onChange={(e) => setTemperature(parseFloat(e.target.value))}
                  className="slider"
                />
                <div className="slider-labels">
                  <span>Deterministic</span>
                  <span>Creative</span>
                </div>
              </div>

              <div className="form-field">
                <label>Model</label>
                <Select defaultValue="gpt-4-turbo">
                  <option value="gpt-4-turbo">GPT-4 Turbo</option>
                  <option value="gpt-4">GPT-4</option>
                  <option value="gpt-3.5-turbo">GPT-3.5 Turbo</option>
                </Select>
              </div>
            </div>

            <div className="stats-section">
              <h4>Session Stats</h4>
              <div className="stats-grid">
                <div className="stat">
                  <div className="stat-value">{messages.length / 2}</div>
                  <div className="stat-label">Exchanges</div>
                </div>
                <div className="stat">
                  <div className="stat-value">
                    {messages
                      .reduce((sum, m) => sum + (m.metadata?.tokens_in || 0) + (m.metadata?.tokens_out || 0), 0)}
                  </div>
                  <div className="stat-label">Total Tokens</div>
                </div>
                <div className="stat">
                  <div className="stat-value">
                    ${messages
                      .reduce((sum, m) => sum + (m.metadata?.cost || 0), 0)
                      .toFixed(4)}
                  </div>
                  <div className="stat-label">Total Cost</div>
                </div>
              </div>
            </div>
          </Card>
        </div>
      )}

      {/* Batch Testing */}
      {activeTab === 'batch' && (
        <Card className="batch-card">
          <div className="batch-header">
            <div>
              <h3 className="batch-title">Batch Test Cases</h3>
              <p className="batch-subtitle">Run multiple tests simultaneously</p>
            </div>
            <div className="batch-actions">
              <Button icon={<PlayRegular />} appearance="primary" onClick={handleRunBatchTests} disabled={loading}>
                {loading ? 'Running...' : `Run ${batchTests.length} Tests`}
              </Button>
              <Button onClick={addBatchTest}>Add Test Case</Button>
            </div>
          </div>

          <div className="batch-list">
            {batchTests.map((test, idx) => (
              <Card key={idx} className="batch-test-card">
                <div className="test-number">#{idx + 1}</div>
                <div className="test-fields">
                  <div className="form-field">
                    <label>Input</label>
                    <Textarea
                      value={test.input}
                      onChange={(e) => updateBatchTest(idx, 'input', e.target.value)}
                      placeholder="Enter test input..."
                      rows={3}
                    />
                  </div>
                  <div className="form-field">
                    <label>Expected Output (Optional)</label>
                    <Textarea
                      value={test.expected}
                      onChange={(e) => updateBatchTest(idx, 'expected', e.target.value)}
                      placeholder="Expected response..."
                      rows={3}
                    />
                  </div>
                </div>
                <Button
                  icon={<DeleteRegular />}
                  appearance="subtle"
                  onClick={() => removeBatchTest(idx)}
                />
              </Card>
            ))}
          </div>
        </Card>
      )}

      {/* Test History */}
      {activeTab === 'history' && (
        <Card className="history-card">
          <div className="history-header">
            <h3>Test History</h3>
            <Button>Export CSV</Button>
          </div>

          <div className="history-list">
            {testHistory.map((test) => (
              <Card key={test.id} className="history-item">
                <div className="history-main">
                  <div className="history-input">
                    <label>Input:</label>
                    <p>{test.input}</p>
                  </div>
                  <div className="history-output">
                    <label>Output:</label>
                    <p>{test.output}</p>
                  </div>
                </div>
                <div className="history-meta">
                  <span>{test.timestamp.toLocaleString()}</span>
                  <Badge>⚡ {test.metadata.latency?.toFixed(2)}s</Badge>
                  <Badge>💰 ${test.metadata.cost?.toFixed(4)}</Badge>
                </div>
              </Card>
            ))}

            {testHistory.length === 0 && (
              <div className="empty-state">
                <div className="empty-icon">📋</div>
                <h3>No test history yet</h3>
                <p>Run some tests to see them here</p>
              </div>
            )}
          </div>
        </Card>
      )}

      {/* A/B Comparison */}
      {activeTab === 'compare' && (
        <div className="compare-layout">
          <Card className="compare-input-card">
            <h3 className="section-title">Test Input</h3>
            <Textarea
              value={compareInputs[0].input}
              onChange={(e) => {
                const updated = [...compareInputs]
                updated[0].input = e.target.value
                updated[1].input = e.target.value
                setCompareInputs(updated)
              }}
              placeholder="Enter the same prompt to test with different configurations..."
              rows={4}
              className="compare-input"
            />
            <div className="compare-actions">
              <Button
                icon={<PlayRegular />}
                appearance="primary"
                onClick={handleRunBothComparison}
                disabled={compareInputs[0].loading || compareInputs[1].loading}
                size="large"
              >
                {compareInputs[0].loading || compareInputs[1].loading ? 'Running...' : '🔄 Run Both Tests'}
              </Button>
            </div>
          </Card>

          <div className="compare-grid">
            {/* Configuration A */}
            <Card className="compare-config-card config-a">
              <div className="config-header">
                <h3>Configuration A</h3>
                <Button
                  icon={<PlayRegular />}
                  appearance="primary"
                  onClick={() => handleCompareTest(0)}
                  disabled={compareInputs[0].loading}
                  size="small"
                >
                  Test A
                </Button>
              </div>

              <div className="config-settings">
                <div className="form-field">
                  <label>Model</label>
                  <Select
                    value={compareConfigA.model}
                    onChange={(e) => setCompareConfigA({ ...compareConfigA, model: e.target.value })}
                  >
                    <option value="GPT-4 Turbo">GPT-4 Turbo</option>
                    <option value="GPT-4">GPT-4</option>
                    <option value="GPT-3.5 Turbo">GPT-3.5 Turbo</option>
                    <option value="Claude 3 Opus">Claude 3 Opus</option>
                  </Select>
                </div>

                <div className="form-field">
                  <label>Temperature: {compareConfigA.temperature}</label>
                  <input
                    type="range"
                    min="0"
                    max="2"
                    step="0.1"
                    value={compareConfigA.temperature}
                    onChange={(e) => setCompareConfigA({ ...compareConfigA, temperature: parseFloat(e.target.value) })}
                    className="slider"
                  />
                </div>

                <div className="form-field">
                  <label>System Prompt</label>
                  <Textarea
                    value={compareConfigA.systemPrompt}
                    onChange={(e) => setCompareConfigA({ ...compareConfigA, systemPrompt: e.target.value })}
                    rows={3}
                    placeholder="System prompt..."
                  />
                </div>
              </div>

              {compareInputs[0].loading && (
                <div className="loading-state">
                  <div className="spinner"></div>
                  <p>Running test A...</p>
                </div>
              )}

              {compareInputs[0].response && !compareInputs[0].loading && (
                <div className="compare-result">
                  <h4>Response A</h4>
                  <div className="result-content">
                    {compareInputs[0].response.output}
                  </div>
                  <div className="result-metrics">
                    <Badge appearance="tint">⚡ {compareInputs[0].response.latency?.toFixed(2)}s</Badge>
                    <Badge appearance="tint">
                      📊 {compareInputs[0].response.tokens_in} → {compareInputs[0].response.tokens_out} tokens
                    </Badge>
                    <Badge appearance="tint">💰 ${compareInputs[0].response.cost?.toFixed(4)}</Badge>
                  </div>
                </div>
              )}
            </Card>

            {/* Configuration B */}
            <Card className="compare-config-card config-b">
              <div className="config-header">
                <h3>Configuration B</h3>
                <Button
                  icon={<PlayRegular />}
                  appearance="primary"
                  onClick={() => handleCompareTest(1)}
                  disabled={compareInputs[1].loading}
                  size="small"
                >
                  Test B
                </Button>
              </div>

              <div className="config-settings">
                <div className="form-field">
                  <label>Model</label>
                  <Select
                    value={compareConfigB.model}
                    onChange={(e) => setCompareConfigB({ ...compareConfigB, model: e.target.value })}
                  >
                    <option value="GPT-4 Turbo">GPT-4 Turbo</option>
                    <option value="GPT-4">GPT-4</option>
                    <option value="GPT-3.5 Turbo">GPT-3.5 Turbo</option>
                    <option value="Claude 3 Opus">Claude 3 Opus</option>
                  </Select>
                </div>

                <div className="form-field">
                  <label>Temperature: {compareConfigB.temperature}</label>
                  <input
                    type="range"
                    min="0"
                    max="2"
                    step="0.1"
                    value={compareConfigB.temperature}
                    onChange={(e) => setCompareConfigB({ ...compareConfigB, temperature: parseFloat(e.target.value) })}
                    className="slider"
                  />
                </div>

                <div className="form-field">
                  <label>System Prompt</label>
                  <Textarea
                    value={compareConfigB.systemPrompt}
                    onChange={(e) => setCompareConfigB({ ...compareConfigB, systemPrompt: e.target.value })}
                    rows={3}
                    placeholder="System prompt..."
                  />
                </div>
              </div>

              {compareInputs[1].loading && (
                <div className="loading-state">
                  <div className="spinner"></div>
                  <p>Running test B...</p>
                </div>
              )}

              {compareInputs[1].response && !compareInputs[1].loading && (
                <div className="compare-result">
                  <h4>Response B</h4>
                  <div className="result-content">
                    {compareInputs[1].response.output}
                  </div>
                  <div className="result-metrics">
                    <Badge appearance="tint">⚡ {compareInputs[1].response.latency?.toFixed(2)}s</Badge>
                    <Badge appearance="tint">
                      📊 {compareInputs[1].response.tokens_in} → {compareInputs[1].response.tokens_out} tokens
                    </Badge>
                    <Badge appearance="tint">💰 ${compareInputs[1].response.cost?.toFixed(4)}</Badge>
                  </div>
                </div>
              )}
            </Card>
          </div>

          {/* Comparison Summary */}
          {compareInputs[0].response && compareInputs[1].response && (
            <Card className="comparison-summary">
              <h3>Comparison Summary</h3>
              <div className="summary-grid">
                <div className="summary-item">
                  <label>Latency Difference</label>
                  <div className="summary-value">
                    {Math.abs(compareInputs[0].response.latency - compareInputs[1].response.latency).toFixed(2)}s
                    {compareInputs[0].response.latency < compareInputs[1].response.latency ? ' ✓ A faster' : ' ✓ B faster'}
                  </div>
                </div>
                <div className="summary-item">
                  <label>Token Difference</label>
                  <div className="summary-value">
                    {Math.abs(
                      (compareInputs[0].response.tokens_in + compareInputs[0].response.tokens_out) -
                      (compareInputs[1].response.tokens_in + compareInputs[1].response.tokens_out)
                    )} tokens
                  </div>
                </div>
                <div className="summary-item">
                  <label>Cost Difference</label>
                  <div className="summary-value">
                    ${Math.abs(compareInputs[0].response.cost - compareInputs[1].response.cost).toFixed(4)}
                  </div>
                </div>
              </div>
            </Card>
          )}
        </div>
      )}
    </div>
  )
}
