import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Button, Input, Label, Card } from '@fluentui/react-components'
import { toast } from 'react-toastify'
import { useAuthStore } from '../store/authStore'
import './Login.css'

export default function Login() {
  const navigate = useNavigate()
  const { login } = useAuthStore()
  const [email, setEmail] = useState('anup.menon@orchestra.ai')
  const [password, setPassword] = useState('admin123')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      await login(email, password)
      toast.success('Login successful!')
      navigate('/dashboard')
    } catch (error) {
      toast.error('Login failed. Please check your credentials.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="login-container">
      <Card className="login-card">
        <div className="login-header">
          <h1>🤖 Agent Studio</h1>
          <p>Enterprise AI Agent Management Platform</p>
        </div>

        <form onSubmit={handleSubmit} className="login-form">
          <div className="form-field">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder="anup.menon@orchestra.ai"
            />
          </div>

          <div className="form-field">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              placeholder="Enter your password"
            />
          </div>

          <Button
            appearance="primary"
            type="submit"
            disabled={loading}
            className="login-button"
          >
            {loading ? 'Logging in...' : 'Login'}
          </Button>
        </form>

        <div className="login-footer">
          <p>Demo credentials: anup.menon@orchestra.ai / admin123</p>
        </div>
      </Card>
    </div>
  )
}

