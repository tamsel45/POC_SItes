import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
import './Governance.css'

const SECURITY_POLICIES = [
  {
    id: 'policy-001',
    name: 'PII Detection & Blocking',
    category: 'Data Protection',
    status: 'enabled',
    severity: 'critical',
    description: 'Detects and blocks personally identifiable information in queries',
    blockedCount: 47,
    alertCount: 123,
    sensitivity: 85,
  },
  {
    id: 'policy-002',
    name: 'Prompt Injection Protection',
    category: 'OWASP LLM01',
    status: 'enabled',
    severity: 'high',
    description: 'Prevents malicious prompt injection attacks',
    blockedCount: 12,
    alertCount: 28,
    sensitivity: 90,
  },
  {
    id: 'policy-003',
    name: 'Data Exfiltration Monitoring',
    category: 'Data Protection',
    status: 'enabled',
    severity: 'critical',
    description: 'Monitors and blocks attempts to extract sensitive data',
    blockedCount: 5,
    alertCount: 15,
    sensitivity: 80,
  },
  {
    id: 'policy-004',
    name: 'Sensitive Information Disclosure',
    category: 'OWASP LLM06',
    status: 'enabled',
    severity: 'high',
    description: 'Prevents leakage of confidential information',
    blockedCount: 23,
    alertCount: 67,
    sensitivity: 75,
  },
]

const OWASP_CHECKLIST = [
  { id: 'llm01', name: 'Prompt Injection', enabled: true, status: 'protected' },
  { id: 'llm02', name: 'Insecure Output Handling', enabled: true, status: 'protected' },
  { id: 'llm03', name: 'Training Data Poisoning', enabled: false, status: 'monitoring' },
  { id: 'llm04', name: 'Model Denial of Service', enabled: true, status: 'protected' },
  { id: 'llm05', name: 'Supply Chain Vulnerabilities', enabled: false, status: 'not_applicable' },
  { id: 'llm06', name: 'Sensitive Information Disclosure', enabled: true, status: 'protected' },
  { id: 'llm07', name: 'Insecure Plugin Design', enabled: false, status: 'not_applicable' },
  { id: 'llm08', name: 'Excessive Agency', enabled: true, status: 'protected' },
  { id: 'llm09', name: 'Overreliance', enabled: true, status: 'monitoring' },
  { id: 'llm10', name: 'Model Theft', enabled: false, status: 'not_applicable' },
]

export default function Governance() {
  const navigate = useNavigate()
  const [policies, setPolicies] = useState(SECURITY_POLICIES)
  const [showCreateModal, setShowCreateModal] = useState(false)

  const securityScore = 98
  const violationsLast24h = 87
  const complianceStatus = 'Compliant'

  const handleTogglePolicy = (policyId: string) => {
    setPolicies(
      policies.map((p) =>
        p.id === policyId ? { ...p, status: p.status === 'enabled' ? 'disabled' : 'enabled' } : p
      )
    )
    toast.success('Policy status updated')
  }

  const handleSensitivityChange = (policyId: string, value: number) => {
    setPolicies(policies.map((p) => (p.id === policyId ? { ...p, sensitivity: value } : p)))
  }

  return (
    <div className="governance-page">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1 className="page-title">Governance & Security</h1>
          <p className="page-subtitle">Centralized policy management and compliance monitoring</p>
        </div>
        <div className="header-actions">
          <button className="btn btn-secondary" onClick={() => navigate('/governance/violations')}>
            <span className="btn-icon">⚠️</span>
            View Violations
          </button>
          <button className="btn btn-primary" onClick={() => setShowCreateModal(true)}>
            <span className="btn-icon">➕</span>
            Create Policy
          </button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="metrics-grid">
        <div className="metric-card security-score">
          <div className="metric-icon-wrapper">
            <span className="metric-icon">🛡️</span>
          </div>
          <div className="metric-content">
            <div className="metric-label">Security Score</div>
            <div className="metric-value">{securityScore}/100</div>
            <div className="metric-trend positive">+2 from last week</div>
          </div>
        </div>

        <div className="metric-card violations">
          <div className="metric-icon-wrapper warning">
            <span className="metric-icon">⚠️</span>
          </div>
          <div className="metric-content">
            <div className="metric-label">Violations (24h)</div>
            <div className="metric-value">{violationsLast24h}</div>
            <div className="metric-breakdown">
              <span className="blocked">47 blocked</span> · <span className="alerted">40 alerted</span>
            </div>
          </div>
        </div>

        <div className="metric-card compliance">
          <div className="metric-icon-wrapper success">
            <span className="metric-icon">✓</span>
          </div>
          <div className="metric-content">
            <div className="metric-label">Compliance Status</div>
            <div className="metric-value">{complianceStatus}</div>
            <div className="metric-subtext">GDPR · SOC2 · ISO 27001</div>
          </div>
        </div>

        <div className="metric-card owasp">
          <div className="metric-icon-wrapper">
            <span className="metric-icon">🔒</span>
          </div>
          <div className="metric-content">
            <div className="metric-label">OWASP LLM Top 10</div>
            <div className="metric-value">6/10 Protected</div>
            <div className="metric-subtext">4 monitoring/N/A</div>
          </div>
        </div>
      </div>

      {/* OWASP LLM Top 10 Checklist */}
      <div className="card">
        <div className="card-header">
          <h2 className="card-title">OWASP LLM Top 10 Protection</h2>
          <button className="btn btn-secondary btn-sm">View Details</button>
        </div>
        <div className="owasp-checklist">
          {OWASP_CHECKLIST.map((item) => (
            <div key={item.id} className={`owasp-item ${item.status}`}>
              <div className="owasp-item-left">
                <div className={`owasp-status-icon ${item.status}`}>
                  {item.status === 'protected' && '✓'}
                  {item.status === 'monitoring' && '👁️'}
                  {item.status === 'not_applicable' && '—'}
                </div>
                <div>
                  <div className="owasp-name">{item.name}</div>
                  <div className="owasp-id">{item.id.toUpperCase()}</div>
                </div>
              </div>
              <div className="owasp-item-right">
                <span className={`badge ${item.status}`}>
                  {item.status === 'protected' && 'Protected'}
                  {item.status === 'monitoring' && 'Monitoring'}
                  {item.status === 'not_applicable' && 'N/A'}
                </span>
                <label className="toggle-switch">
                  <input type="checkbox" checked={item.enabled} readOnly />
                  <span className="toggle-slider"></span>
                </label>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Security Policies */}
      <div className="card">
        <div className="card-header">
          <h2 className="card-title">Active Security Policies</h2>
          <div className="card-filters">
            <select className="filter-select">
              <option value="all">All Categories</option>
              <option value="data-protection">Data Protection</option>
              <option value="owasp">OWASP LLM</option>
              <option value="custom">Custom Rules</option>
            </select>
            <select className="filter-select">
              <option value="all">All Statuses</option>
              <option value="enabled">Enabled</option>
              <option value="disabled">Disabled</option>
            </select>
          </div>
        </div>

        <div className="policies-list">
          {policies.map((policy) => (
            <div key={policy.id} className="policy-card">
              <div className="policy-header">
                <div className="policy-header-left">
                  <div className="policy-name">{policy.name}</div>
                  <div className="policy-meta">
                    <span className={`badge severity-${policy.severity}`}>{policy.severity}</span>
                    <span className="policy-category">{policy.category}</span>
                  </div>
                </div>
                <label className="toggle-switch">
                  <input
                    type="checkbox"
                    checked={policy.status === 'enabled'}
                    onChange={() => handleTogglePolicy(policy.id)}
                  />
                  <span className="toggle-slider"></span>
                </label>
              </div>

              <p className="policy-description">{policy.description}</p>

              <div className="policy-stats">
                <div className="stat-item">
                  <span className="stat-icon blocked">🚫</span>
                  <span className="stat-value">{policy.blockedCount}</span>
                  <span className="stat-label">Blocked</span>
                </div>
                <div className="stat-item">
                  <span className="stat-icon alerted">🔔</span>
                  <span className="stat-value">{policy.alertCount}</span>
                  <span className="stat-label">Alerted</span>
                </div>
              </div>

              <div className="policy-sensitivity">
                <div className="sensitivity-label">
                  Detection Sensitivity: <strong>{policy.sensitivity}%</strong>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={policy.sensitivity}
                  onChange={(e) => handleSensitivityChange(policy.id, parseInt(e.target.value))}
                  className="sensitivity-slider"
                />
                <div className="sensitivity-scale">
                  <span>Permissive</span>
                  <span>Balanced</span>
                  <span>Strict</span>
                </div>
              </div>

              <div className="policy-actions">
                <button className="btn btn-secondary btn-sm">Test Policy</button>
                <button className="btn btn-secondary btn-sm">View Logs</button>
                <button className="btn btn-secondary btn-sm">Edit</button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Alert Configuration */}
      <div className="card">
        <div className="card-header">
          <h2 className="card-title">Alert Configuration</h2>
        </div>
        <div className="alert-config">
          <div className="config-section">
            <h3>Notification Channels</h3>
            <div className="config-options">
              <label className="checkbox-label">
                <input type="checkbox" defaultChecked />
                <span>Email Notifications</span>
              </label>
              <label className="checkbox-label">
                <input type="checkbox" defaultChecked />
                <span>Slack Integration</span>
              </label>
              <label className="checkbox-label">
                <input type="checkbox" />
                <span>PagerDuty Alerts</span>
              </label>
            </div>
          </div>

          <div className="config-section">
            <h3>Alert Modes</h3>
            <div className="radio-group">
              <label className="radio-label">
                <input type="radio" name="mode" value="alert" defaultChecked />
                <span>Alert Only (Log violations)</span>
              </label>
              <label className="radio-label">
                <input type="radio" name="mode" value="block" />
                <span>Auto-Block (Prevent violations)</span>
              </label>
              <label className="radio-label">
                <input type="radio" name="mode" value="hybrid" />
                <span>Hybrid (Block critical, alert others)</span>
              </label>
            </div>
          </div>
        </div>
      </div>

      {/* Create Policy Modal */}
      {showCreateModal && (
        <div className="modal-overlay" onClick={() => setShowCreateModal(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Create Security Policy</h2>
              <button className="modal-close" onClick={() => setShowCreateModal(false)}>
                ✕
              </button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label>Policy Name</label>
                <input type="text" className="form-input" placeholder="e.g., Credit Card Detection" />
              </div>
              <div className="form-group">
                <label>Category</label>
                <select className="form-select">
                  <option value="data-protection">Data Protection</option>
                  <option value="owasp">OWASP LLM</option>
                  <option value="custom">Custom Rule</option>
                </select>
              </div>
              <div className="form-group">
                <label>Detection Rule</label>
                <textarea
                  className="form-textarea"
                  rows={4}
                  placeholder="if query contains REGEX pattern..."
                />
              </div>
              <div className="form-group">
                <label>Action</label>
                <select className="form-select">
                  <option value="block">Block Request</option>
                  <option value="alert">Alert Only</option>
                  <option value="redact">Redact & Continue</option>
                </select>
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={() => setShowCreateModal(false)}>
                Cancel
              </button>
              <button
                className="btn btn-primary"
                onClick={() => {
                  toast.success('Policy created successfully!')
                  setShowCreateModal(false)
                }}
              >
                Create Policy
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

