import { useState } from 'react'
import { toast } from 'react-toastify'
import './GuardrailsFilter.css'

export default function GuardrailsFilter() {
  const [filters, setFilters] = useState({
    harmfulContent: true,
    sensitiveData: true,
    profanity: true,
    violence: true,
    pii: true,
    proprietary: true,
  })

  const [sensitivity, setSensitivity] = useState({
    harmfulContent: 80,
    sensitiveData: 100,
    profanity: 100,
    violence: 100,
    pii: 100,
    proprietary: 80,
  })

  const stats = {
    status: 'active',
    threatsBlockedToday: 45,
    totalProcessed: 12456,
    blockRate: 0.36,
  }

  const recentBlocks = [
    {
      id: 'block-001',
      timestamp: '15:23',
      type: 'pii',
      description: 'PII detected in query (SSN pattern)',
      severity: 'critical',
      content: 'Query contained: "My SSN is ***-**-****"',
    },
    {
      id: 'block-002',
      timestamp: '14:56',
      type: 'harmful',
      description: 'Harmful content blocked (violence)',
      severity: 'high',
      content: 'Violent content detected and blocked',
    },
    {
      id: 'block-003',
      timestamp: '14:12',
      type: 'sensitive',
      description: 'Sensitive data filter (credit card)',
      severity: 'critical',
      content: 'Credit card number pattern detected',
    },
    {
      id: 'block-004',
      timestamp: '13:45',
      type: 'profanity',
      description: 'Profanity/hate speech blocked',
      severity: 'medium',
      content: 'Inappropriate language filtered',
    },
    {
      id: 'block-005',
      timestamp: '13:12',
      type: 'proprietary',
      description: 'Proprietary information leak prevented',
      severity: 'high',
      content: 'Attempted to share internal API keys',
    },
  ]

  const detectionMethods = [
    { name: 'Keyword matching', enabled: true, accuracy: 95 },
    { name: 'Pattern recognition', enabled: true, accuracy: 98 },
    { name: 'ML-based classification', enabled: true, accuracy: 92 },
    { name: 'Contextual analysis', enabled: true, accuracy: 88 },
  ]

  const toggleFilter = (filterName: string) => {
    setFilters((prev) => ({
      ...prev,
      [filterName]: !prev[filterName as keyof typeof prev],
    }))
    toast.success(`${filterName} filter ${filters[filterName as keyof typeof filters] ? 'disabled' : 'enabled'}`)
  }

  const updateSensitivity = (filterName: string, value: number) => {
    setSensitivity((prev) => ({
      ...prev,
      [filterName]: value,
    }))
  }

  const testFilter = () => {
    toast.info('Running filter test...')
    setTimeout(() => {
      toast.success('Filter test completed: All checks passed!')
    }, 1500)
  }

  return (
    <div className="guardrails-page">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1 className="page-title">
            <span className="layer-badge navy">Layer 1</span>
            Guardrails Filter
          </h1>
          <p className="page-subtitle">
            Content Protection & Safety Filters - Catches harmful and sensitive content
          </p>
        </div>
        <div className="header-actions">
          <button className="btn btn-secondary" onClick={testFilter}>
            <span className="btn-icon">🧪</span>
            Test Filter
          </button>
          <button className="btn btn-secondary" onClick={() => toast.info('Viewing blocked content log...')}>
            <span className="btn-icon">📋</span>
            View Blocked Content
          </button>
          <button className="btn btn-primary">
            <span className="btn-icon">⚙️</span>
            Configure Rules
          </button>
        </div>
      </div>

      {/* Status Dashboard */}
      <div className="status-dashboard">
        <div className="status-card active">
          <div className="status-icon">✓</div>
          <div className="status-info">
            <div className="status-label">Status</div>
            <div className="status-value">ACTIVE</div>
          </div>
        </div>
        <div className="status-card">
          <div className="status-icon">🛡️</div>
          <div className="status-info">
            <div className="status-label">Threats Blocked Today</div>
            <div className="status-value">{stats.threatsBlockedToday}</div>
          </div>
        </div>
        <div className="status-card">
          <div className="status-icon">📊</div>
          <div className="status-info">
            <div className="status-label">Total Processed</div>
            <div className="status-value">{stats.totalProcessed.toLocaleString()}</div>
          </div>
        </div>
        <div className="status-card">
          <div className="status-icon">📈</div>
          <div className="status-info">
            <div className="status-label">Block Rate</div>
            <div className="status-value">{stats.blockRate}%</div>
          </div>
        </div>
      </div>

      {/* Content Filters */}
      <div className="card filters-card">
        <h2 className="card-title">Content Filters</h2>
        <p className="card-description">
          Configure which types of content should be filtered and their sensitivity levels
        </p>
        
        <div className="filters-grid">
          <div className="filter-item">
            <div className="filter-header">
              <div className="filter-info">
                <span className="filter-icon">⚠️</span>
                <span className="filter-name">Harmful Content Detection</span>
              </div>
              <label className="toggle-switch">
                <input
                  type="checkbox"
                  checked={filters.harmfulContent}
                  onChange={() => toggleFilter('harmfulContent')}
                />
                <span className="toggle-slider"></span>
              </label>
            </div>
            {filters.harmfulContent && (
              <div className="sensitivity-control">
                <label className="sensitivity-label">
                  Sensitivity: {sensitivity.harmfulContent}%
                </label>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={sensitivity.harmfulContent}
                  onChange={(e) => updateSensitivity('harmfulContent', parseInt(e.target.value))}
                  className="sensitivity-slider"
                />
              </div>
            )}
          </div>

          <div className="filter-item">
            <div className="filter-header">
              <div className="filter-info">
                <span className="filter-icon">🔒</span>
                <span className="filter-name">Sensitive Data Filter</span>
              </div>
              <label className="toggle-switch">
                <input
                  type="checkbox"
                  checked={filters.sensitiveData}
                  onChange={() => toggleFilter('sensitiveData')}
                />
                <span className="toggle-slider"></span>
              </label>
            </div>
            {filters.sensitiveData && (
              <div className="sensitivity-control">
                <label className="sensitivity-label">
                  Sensitivity: {sensitivity.sensitiveData}%
                </label>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={sensitivity.sensitiveData}
                  onChange={(e) => updateSensitivity('sensitiveData', parseInt(e.target.value))}
                  className="sensitivity-slider"
                />
              </div>
            )}
          </div>

          <div className="filter-item">
            <div className="filter-header">
              <div className="filter-info">
                <span className="filter-icon">🚫</span>
                <span className="filter-name">Profanity/Hate Speech</span>
              </div>
              <label className="toggle-switch">
                <input
                  type="checkbox"
                  checked={filters.profanity}
                  onChange={() => toggleFilter('profanity')}
                />
                <span className="toggle-slider"></span>
              </label>
            </div>
            {filters.profanity && (
              <div className="sensitivity-control">
                <label className="sensitivity-label">
                  Sensitivity: {sensitivity.profanity}%
                </label>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={sensitivity.profanity}
                  onChange={(e) => updateSensitivity('profanity', parseInt(e.target.value))}
                  className="sensitivity-slider"
                />
              </div>
            )}
          </div>

          <div className="filter-item">
            <div className="filter-header">
              <div className="filter-info">
                <span className="filter-icon">⚔️</span>
                <span className="filter-name">Violence/Illegal Content</span>
              </div>
              <label className="toggle-switch">
                <input
                  type="checkbox"
                  checked={filters.violence}
                  onChange={() => toggleFilter('violence')}
                />
                <span className="toggle-slider"></span>
              </label>
            </div>
            {filters.violence && (
              <div className="sensitivity-control">
                <label className="sensitivity-label">
                  Sensitivity: {sensitivity.violence}%
                </label>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={sensitivity.violence}
                  onChange={(e) => updateSensitivity('violence', parseInt(e.target.value))}
                  className="sensitivity-slider"
                />
              </div>
            )}
          </div>

          <div className="filter-item">
            <div className="filter-header">
              <div className="filter-info">
                <span className="filter-icon">🆔</span>
                <span className="filter-name">Personal Identifiable Info (PII)</span>
              </div>
              <label className="toggle-switch">
                <input
                  type="checkbox"
                  checked={filters.pii}
                  onChange={() => toggleFilter('pii')}
                />
                <span className="toggle-slider"></span>
              </label>
            </div>
            {filters.pii && (
              <div className="sensitivity-control">
                <label className="sensitivity-label">
                  Sensitivity: {sensitivity.pii}%
                </label>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={sensitivity.pii}
                  onChange={(e) => updateSensitivity('pii', parseInt(e.target.value))}
                  className="sensitivity-slider"
                />
              </div>
            )}
          </div>

          <div className="filter-item">
            <div className="filter-header">
              <div className="filter-info">
                <span className="filter-icon">🔐</span>
                <span className="filter-name">Proprietary Information Leak</span>
              </div>
              <label className="toggle-switch">
                <input
                  type="checkbox"
                  checked={filters.proprietary}
                  onChange={() => toggleFilter('proprietary')}
                />
                <span className="toggle-slider"></span>
              </label>
            </div>
            {filters.proprietary && (
              <div className="sensitivity-control">
                <label className="sensitivity-label">
                  Sensitivity: {sensitivity.proprietary}%
                </label>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={sensitivity.proprietary}
                  onChange={(e) => updateSensitivity('proprietary', parseInt(e.target.value))}
                  className="sensitivity-slider"
                />
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="content-row">
        {/* Detection Methods */}
        <div className="card">
          <h2 className="card-title">Detection Methods</h2>
          <div className="detection-methods">
            {detectionMethods.map((method, idx) => (
              <div key={idx} className="detection-method">
                <div className="method-header">
                  <span className="method-icon">{method.enabled ? '✓' : '○'}</span>
                  <span className="method-name">{method.name}</span>
                </div>
                <div className="method-accuracy">
                  <div className="accuracy-bar">
                    <div
                      className="accuracy-fill"
                      style={{ width: `${method.accuracy}%` }}
                    />
                  </div>
                  <span className="accuracy-label">{method.accuracy}% accuracy</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Blocks */}
        <div className="card">
          <h2 className="card-title">Recent Blocks</h2>
          <div className="recent-blocks">
            {recentBlocks.map((block) => (
              <div key={block.id} className={`block-item severity-${block.severity}`}>
                <div className="block-header">
                  <span className="block-time">{block.timestamp}</span>
                  <span className={`severity-badge ${block.severity}`}>
                    {block.severity.toUpperCase()}
                  </span>
                </div>
                <div className="block-description">{block.description}</div>
                <div className="block-content">{block.content}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

