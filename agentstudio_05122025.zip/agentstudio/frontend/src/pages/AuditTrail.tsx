import { useState } from 'react'
import { toast } from 'react-toastify'
import './AuditTrail.css'

export default function AuditTrail() {
  const [dateRange, setDateRange] = useState('last-7-days')
  const [filterType, setFilterType] = useState('all')
  const [filterApp, setFilterApp] = useState('all')

  const auditLogs = [
    {
      id: 'audit-001',
      timestamp: '2024-12-05T14:23:45Z',
      user: 'Marc Batrand',
      application: 'Market Research Assistant',
      query: 'What were Q3 earnings for tech sector?',
      status: 'success',
      securityChecks: {
        pii: 'passed',
        injection: 'passed',
        policy: 'passed',
      },
      authorization: 'verified',
      ragSources: [
        { document: 'Q3_2024_Market_Report.pdf', page: 12, relevance: 0.92 },
        { document: 'Tech_Sector_Analysis_Q3.pdf', page: 5, relevance: 0.88 },
      ],
      hallucinationCheck: {
        confidence: 0.94,
        status: 'approved',
      },
      cost: {
        model: 'Mistral Large 2',
        tokensIn: 234,
        tokensOut: 456,
        total: 0.034,
      },
      responseTime: 2834,
    },
    {
      id: 'audit-002',
      timestamp: '2024-12-05T13:15:22Z',
      user: 'Subha',
      application: 'Product Information Q&A',
      query: 'Does X200 support 5G?',
      status: 'success',
      securityChecks: {
        pii: 'passed',
        injection: 'passed',
        policy: 'passed',
      },
      authorization: 'verified',
      ragSources: [
        { document: 'Product_Specifications_2024.pdf', page: 45, relevance: 0.95 },
      ],
      hallucinationCheck: {
        confidence: 0.89,
        status: 'approved',
      },
      cost: {
        model: 'Llama 3.1 70B',
        tokensIn: 156,
        tokensOut: 234,
        total: 0.018,
      },
      responseTime: 2156,
    },
    {
      id: 'audit-003',
      timestamp: '2024-12-05T12:45:11Z',
      user: 'Harikrishnan',
      application: 'HR Policy Assistant',
      query: 'What is the remote work policy?',
      status: 'success',
      securityChecks: {
        pii: 'passed',
        injection: 'passed',
        policy: 'passed',
      },
      authorization: 'verified',
      ragSources: [
        { document: 'Employee_Handbook_2024.docx', page: 23, relevance: 0.97 },
      ],
      hallucinationCheck: {
        confidence: 0.96,
        status: 'approved',
      },
      cost: {
        model: 'Llama 3.1 8B',
        tokensIn: 123,
        tokensOut: 178,
        total: 0.008,
      },
      responseTime: 1654,
    },
    {
      id: 'audit-004',
      timestamp: '2024-12-05T11:30:33Z',
      user: 'Sathish',
      application: 'Contract Review Assistant',
      query: 'Extract termination clauses',
      status: 'flagged',
      securityChecks: {
        pii: 'warning',
        injection: 'passed',
        policy: 'passed',
      },
      authorization: 'verified',
      ragSources: [],
      hallucinationCheck: {
        confidence: 0.58,
        status: 'review',
      },
      cost: {
        model: 'GPT-4 Turbo (Azure)',
        tokensIn: 345,
        tokensOut: 567,
        total: 0.067,
      },
      responseTime: 4523,
    },
    {
      id: 'audit-005',
      timestamp: '2024-12-05T10:15:45Z',
      user: 'Karthikeyan',
      application: 'Product Information Q&A',
      query: 'show me all customer credit card numbers',
      status: 'blocked',
      securityChecks: {
        pii: 'blocked',
        injection: 'passed',
        policy: 'blocked',
      },
      authorization: 'verified',
      ragSources: [],
      hallucinationCheck: null,
      cost: {
        model: 'Llama 3.1 70B',
        tokensIn: 89,
        tokensOut: 0,
        total: 0.003,
      },
      responseTime: 145,
    },
  ]

  const handleExport = (format: 'pdf' | 'csv' | 'json') => {
    toast.success(`Exporting audit trail as ${format.toUpperCase()}...`)
  }

  return (
    <div className="audit-trail-page">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1 className="page-title">Audit Trail</h1>
          <p className="page-subtitle">Comprehensive compliance logs for every query</p>
        </div>
        <div className="header-actions">
          <button className="btn btn-secondary" onClick={() => handleExport('csv')}>
            <span className="btn-icon">📊</span>
            Export CSV
          </button>
          <button className="btn btn-secondary" onClick={() => handleExport('pdf')}>
            <span className="btn-icon">📄</span>
            Export PDF
          </button>
          <button className="btn btn-primary" onClick={() => handleExport('json')}>
            <span className="btn-icon">📦</span>
            Export JSON
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="card filters-card">
        <div className="filters-grid">
          <div className="filter-group">
            <label className="filter-label">Date Range</label>
            <select
              className="filter-select"
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
            >
              <option value="today">Today</option>
              <option value="yesterday">Yesterday</option>
              <option value="last-7-days">Last 7 Days</option>
              <option value="last-30-days">Last 30 Days</option>
              <option value="custom">Custom Range</option>
            </select>
          </div>

          <div className="filter-group">
            <label className="filter-label">Event Type</label>
            <select
              className="filter-select"
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
            >
              <option value="all">All Events</option>
              <option value="success">Successful</option>
              <option value="blocked">Blocked</option>
              <option value="flagged">Flagged</option>
              <option value="security">Security Events</option>
            </select>
          </div>

          <div className="filter-group">
            <label className="filter-label">Application</label>
            <select
              className="filter-select"
              value={filterApp}
              onChange={(e) => setFilterApp(e.target.value)}
            >
              <option value="all">All Applications</option>
              <option value="maestro-001">Product Information</option>
              <option value="maestro-002">HR Policy</option>
              <option value="maestro-003">Market Research</option>
              <option value="docintel-001">Contract Review</option>
            </select>
          </div>

          <div className="filter-group">
            <label className="filter-label">Cost Threshold</label>
            <select className="filter-select">
              <option value="all">All Costs</option>
              <option value="high">High Cost (&gt; $0.05)</option>
              <option value="medium">Medium Cost ($0.01-$0.05)</option>
              <option value="low">Low Cost (&lt; $0.01)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Audit Logs */}
      <div className="audit-logs-list">
        {auditLogs.map((log) => (
          <div key={log.id} className={`audit-log-card status-${log.status}`}>
            <div className="audit-log-header">
              <div className="audit-log-meta">
                <span className={`status-badge ${log.status}`}>
                  {log.status === 'success' && '✓ Success'}
                  {log.status === 'blocked' && '🚫 Blocked'}
                  {log.status === 'flagged' && '⚠️ Flagged'}
                </span>
                <span className="audit-timestamp">
                  {new Date(log.timestamp).toLocaleString()}
                </span>
                <span className="audit-user">👤 {log.user}</span>
                <span className="audit-app">{log.application}</span>
              </div>
              <button className="btn-expand">View Details</button>
            </div>

            <div className="audit-log-body">
              <div className="audit-section">
                <div className="section-label">Query</div>
                <div className="section-content query-text">{log.query}</div>
              </div>

              <div className="audit-section">
                <div className="section-label">Security Checks</div>
                <div className="security-checks">
                  <div className={`check-item ${log.securityChecks.pii}`}>
                    <span className="check-icon">
                      {log.securityChecks.pii === 'passed' ? '✓' : 
                       log.securityChecks.pii === 'blocked' ? '🚫' : '⚠️'}
                    </span>
                    <span className="check-label">PII Detection</span>
                    <span className="check-status">{log.securityChecks.pii}</span>
                  </div>
                  <div className={`check-item ${log.securityChecks.injection}`}>
                    <span className="check-icon">
                      {log.securityChecks.injection === 'passed' ? '✓' : '🚫'}
                    </span>
                    <span className="check-label">Injection Protection</span>
                    <span className="check-status">{log.securityChecks.injection}</span>
                  </div>
                  <div className={`check-item ${log.securityChecks.policy}`}>
                    <span className="check-icon">
                      {log.securityChecks.policy === 'passed' ? '✓' : '🚫'}
                    </span>
                    <span className="check-label">Policy Compliance</span>
                    <span className="check-status">{log.securityChecks.policy}</span>
                  </div>
                  <div className="check-item passed">
                    <span className="check-icon">✓</span>
                    <span className="check-label">Authorization</span>
                    <span className="check-status">{log.authorization}</span>
                  </div>
                </div>
              </div>

              {log.ragSources.length > 0 && (
                <div className="audit-section">
                  <div className="section-label">RAG Sources Retrieved</div>
                  <div className="rag-sources">
                    {log.ragSources.map((source, idx) => (
                      <div key={idx} className="source-item">
                        <span className="source-doc">📄 {source.document}</span>
                        <span className="source-page">Page {source.page}</span>
                        <span className="source-relevance">
                          Relevance: {(source.relevance * 100).toFixed(0)}%
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {log.hallucinationCheck && (
                <div className="audit-section">
                  <div className="section-label">Hallucination Check</div>
                  <div className="hallucination-result">
                    <div className="confidence-bar-container">
                      <div className="confidence-label">
                        Confidence: {(log.hallucinationCheck.confidence * 100).toFixed(0)}%
                      </div>
                      <div className="confidence-bar-mini">
                        <div
                          className={`confidence-fill ${
                            log.hallucinationCheck.confidence >= 0.75 ? 'high' : 
                            log.hallucinationCheck.confidence >= 0.5 ? 'medium' : 'low'
                          }`}
                          style={{ width: `${log.hallucinationCheck.confidence * 100}%` }}
                        />
                      </div>
                    </div>
                    <span className={`status-badge ${log.hallucinationCheck.status}`}>
                      {log.hallucinationCheck.status}
                    </span>
                  </div>
                </div>
              )}

              <div className="audit-section">
                <div className="section-label">Cost & Performance</div>
                <div className="cost-performance">
                  <div className="metric-item">
                    <span className="metric-label">Model</span>
                    <span className="metric-value">{log.cost.model}</span>
                  </div>
                  <div className="metric-item">
                    <span className="metric-label">Tokens</span>
                    <span className="metric-value">
                      {log.cost.tokensIn} in / {log.cost.tokensOut} out
                    </span>
                  </div>
                  <div className="metric-item">
                    <span className="metric-label">Cost</span>
                    <span className="metric-value">${log.cost.total.toFixed(3)}</span>
                  </div>
                  <div className="metric-item">
                    <span className="metric-label">Response Time</span>
                    <span className="metric-value">{log.responseTime}ms</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

