import { useQuery } from '@tanstack/react-query'
import { useNavigate } from 'react-router-dom'
import { Card, Button, Tab, TabList } from '@fluentui/react-components'
import {
  AddRegular,
  ArrowTrendingRegular,
  CheckmarkCircleRegular,
  DismissCircleRegular,
  ClockRegular,
  MoneyRegular,
} from '@fluentui/react-icons'
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts'
import { agentApi } from '../services/api'
import './Dashboard.css'

const COLORS = ['#0078d4', '#107c10', '#faa500', '#d13438', '#881798', '#00b294']

export default function Dashboard() {
  const navigate = useNavigate()
  const { data: agentsData } = useQuery({
    queryKey: ['agents'],
    queryFn: () => agentApi.list(),
  })

  const agents = agentsData?.data?.agents || []

  // Mock comprehensive data
  const usageData = Array.from({ length: 30 }, (_, i) => ({
    date: `${i + 1}`,
    requests: Math.floor(Math.random() * 500) + 300,
    success: Math.floor(Math.random() * 450) + 280,
    errors: Math.floor(Math.random() * 50) + 10,
  }))

  const performanceData = Array.from({ length: 24 }, (_, i) => ({
    hour: `${i}:00`,
    latency: Math.random() * 2 + 1,
    throughput: Math.floor(Math.random() * 100) + 50,
  }))

  const modelUsage = [
    { name: 'GPT-4 Turbo (Azure)', value: 35, color: COLORS[0] },
    { name: 'Llama 3.1 8B', value: 28, color: COLORS[1] },
    { name: 'Mixtral 8x7B', value: 22, color: COLORS[2] },
    { name: 'Llama 3.1 70B', value: 10, color: COLORS[3] },
    { name: 'Llama 3.1 405B', value: 5, color: COLORS[4] },
  ]

  const metrics = {
    activeAgents: agents.filter((a: any) => a.status === 'active').length,
    totalRequests: 156789,
    avgLatency: 1.84,
    successRate: 98.2,
    costToday: 247.35,
    costMonth: 6842.50,
  }

  const recentActivity = [
    { type: 'security', message: 'Policy violation blocked - PII exposure attempt', time: '2 mins ago', status: 'warning' },
    { type: 'budget', message: 'Budget alert: 85% of monthly limit reached', time: '5 mins ago', status: 'warning' },
    { type: 'hallucination', message: 'High hallucination confidence drop detected', time: '10 mins ago', status: 'info' },
    { type: 'deploy', message: 'MAESTRO app "Product Information Q&A" deployed to production', time: '15 mins ago', status: 'success' },
    { type: 'update', message: 'Knowledge base "Market Research" updated with 45 new documents', time: '32 mins ago', status: 'info' },
    { type: 'index', message: 'Vector embeddings indexed for "HR Policies" (234 chunks)', time: '1 hour ago', status: 'success' },
  ]

  return (
    <div className="dashboard">
      {/* Header */}
      <div className="dashboard-header">
        <div>
          <h1 className="dashboard-title">Dashboard Overview</h1>
          <p className="dashboard-subtitle">Monitor your AI agents and infrastructure</p>
        </div>
        <div className="dashboard-actions">
          <Button 
            icon={<AddRegular />} 
            appearance="primary"
            onClick={() => navigate('/agents/create')}
          >
            Create Agent
          </Button>
          <Button 
            icon={<ArrowTrendingRegular />}
            onClick={() => navigate('/analytics')}
          >
            View Full Analytics
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="metrics-grid">
        {/* Security Score */}
        <Card className="metric-card hover-lift" onClick={() => navigate('/governance')}>
          <div className="metric-icon-wrapper blue">
            <span className="metric-icon">🛡️</span>
          </div>
          <div className="metric-content">
            <div className="metric-label">Security Score</div>
            <div className="metric-value">98/100</div>
            <div className="metric-change positive">
              <ArrowTrendingRegular /> +2 from last week
            </div>
          </div>
        </Card>

        {/* Budget & Cost */}
        <Card className="metric-card hover-lift" onClick={() => navigate('/cost-management')}>
          <div className="metric-icon-wrapper orange">
            <MoneyRegular className="metric-icon-svg" />
          </div>
          <div className="metric-content">
            <div className="metric-label">Budget Used</div>
            <div className="metric-value">68%</div>
            <div className="metric-subtext">
              ${metrics.costToday} today · ${metrics.costMonth} this month
            </div>
          </div>
        </Card>

        {/* Hallucination Protection */}
        <Card className="metric-card hover-lift" onClick={() => navigate('/hallucination')}>
          <div className="metric-icon-wrapper purple">
            <span className="metric-icon">⚠️</span>
          </div>
          <div className="metric-content">
            <div className="metric-label">Detections Today</div>
            <div className="metric-value">23</div>
            <div className="metric-subtext">
              Avg confidence: 87% · 5 auto-rejected
            </div>
          </div>
        </Card>

        {/* Active Agents */}
        <Card className="metric-card hover-lift" onClick={() => navigate('/agents')}>
          <div className="metric-icon-wrapper green">
            <span className="metric-icon">🤖</span>
          </div>
          <div className="metric-content">
            <div className="metric-label">Active Agents</div>
            <div className="metric-value">{metrics.activeAgents}</div>
            <div className="metric-change positive">
              <ArrowTrendingRegular /> +2 this week
            </div>
          </div>
        </Card>

        {/* Policy Violations */}
        <Card className="metric-card hover-lift" onClick={() => navigate('/governance')}>
          <div className="metric-icon-wrapper red">
            <span className="metric-icon">🚫</span>
          </div>
          <div className="metric-content">
            <div className="metric-label">Violations (24h)</div>
            <div className="metric-value">87</div>
            <div className="metric-subtext">
              47 blocked · 40 alerted
            </div>
          </div>
        </Card>

        {/* Success Rate */}
        <Card className="metric-card hover-lift" onClick={() => navigate('/analytics')}>
          <div className="metric-icon-wrapper teal">
            <CheckmarkCircleRegular className="metric-icon-svg" />
          </div>
          <div className="metric-content">
            <div className="metric-label">Success Rate</div>
            <div className="metric-value">{metrics.successRate}%</div>
            <div className="metric-change positive">
              <ArrowTrendingRegular /> +0.8% vs yesterday
            </div>
          </div>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="charts-row">
        {/* Usage Trends */}
        <Card className="chart-card">
          <div className="chart-header">
            <div>
              <h2 className="chart-title">Request Volume</h2>
              <p className="chart-subtitle">Last 30 days</p>
            </div>
            <TabList defaultSelectedValue="requests" size="small">
              <Tab value="requests">Requests</Tab>
              <Tab value="success">Success</Tab>
              <Tab value="errors">Errors</Tab>
            </TabList>
          </div>
          <div className="chart-body">
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={usageData}>
                <defs>
                  <linearGradient id="colorRequests" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0078d4" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#0078d4" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#edebe9" />
                <XAxis dataKey="date" stroke="#8a8886" style={{ fontSize: 12 }} />
                <YAxis stroke="#8a8886" style={{ fontSize: 12 }} />
                <Tooltip
                  contentStyle={{
                    background: 'white',
                    border: '1px solid #d2d0ce',
                    borderRadius: 8,
                    boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="requests"
                  stroke="#0078d4"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorRequests)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        {/* Model Usage */}
        <Card className="chart-card">
          <div className="chart-header">
            <div>
              <h2 className="chart-title">Model Distribution</h2>
              <p className="chart-subtitle">By request count</p>
            </div>
          </div>
          <div className="chart-body">
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={modelUsage}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={2}
                  dataKey="value"
                  label={(entry) => `${entry.value}%`}
                >
                  {modelUsage.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="chart-legend">
              {modelUsage.map((item, idx) => (
                <div key={idx} className="legend-item">
                  <span className="legend-dot" style={{ background: item.color }} />
                  <span className="legend-label">{item.name}</span>
                  <span className="legend-value">{item.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </Card>
      </div>

      {/* Performance Chart */}
      <Card className="chart-card-wide">
        <div className="chart-header">
          <div>
            <h2 className="chart-title">Performance Metrics</h2>
            <p className="chart-subtitle">Latency and throughput over last 24 hours</p>
          </div>
        </div>
        <div className="chart-body">
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={performanceData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#edebe9" />
              <XAxis dataKey="hour" stroke="#8a8886" style={{ fontSize: 12 }} />
              <YAxis yAxisId="left" stroke="#8a8886" style={{ fontSize: 12 }} />
              <YAxis yAxisId="right" orientation="right" stroke="#8a8886" style={{ fontSize: 12 }} />
              <Tooltip />
              <Line
                yAxisId="left"
                type="monotone"
                dataKey="latency"
                stroke="#0078d4"
                strokeWidth={2}
                dot={false}
                name="Latency (s)"
              />
              <Line
                yAxisId="right"
                type="monotone"
                dataKey="throughput"
                stroke="#107c10"
                strokeWidth={2}
                dot={false}
                name="Throughput (req/s)"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </Card>

      {/* Bottom Row */}
      <div className="bottom-row">
        {/* Recent Activity */}
        <Card className="activity-card">
          <h2 className="section-title">Recent Activity</h2>
          <div className="activity-list">
            {recentActivity.map((activity, idx) => (
              <div key={idx} className="activity-item">
                <div className={`activity-indicator ${activity.status}`} />
                <div className="activity-content">
                  <div className="activity-message">{activity.message}</div>
                  <div className="activity-time">{activity.time}</div>
                </div>
              </div>
            ))}
          </div>
        </Card>

            {/* Quick Actions */}
            <Card className="quick-actions-card">
              <h2 className="section-title">Quick Actions</h2>
              <div className="quick-actions-grid">
                <button className="quick-action-btn" onClick={() => navigate('/governance')}>
                  <span className="quick-action-icon">🛡️</span>
                  <span className="quick-action-label">Create Policy</span>
                </button>
                <button className="quick-action-btn" onClick={() => navigate('/governance')}>
                  <span className="quick-action-icon">⚠️</span>
                  <span className="quick-action-label">View Violations</span>
                </button>
                <button className="quick-action-btn" onClick={() => navigate('/cost-management')}>
                  <span className="quick-action-icon">💰</span>
                  <span className="quick-action-label">Check Costs</span>
                </button>
                <button className="quick-action-btn" onClick={() => navigate('/testing')}>
                  <span className="quick-action-icon">🧪</span>
                  <span className="quick-action-label">Test Agent</span>
                </button>
                <button className="quick-action-btn" onClick={() => navigate('/knowledge-base')}>
                  <span className="quick-action-icon">📚</span>
                  <span className="quick-action-label">Upload Docs</span>
                </button>
                <button className="quick-action-btn" onClick={() => navigate('/audit')}>
                  <span className="quick-action-icon">📋</span>
                  <span className="quick-action-label">View Audit</span>
                </button>
              </div>
            </Card>
      </div>
    </div>
  )
}
