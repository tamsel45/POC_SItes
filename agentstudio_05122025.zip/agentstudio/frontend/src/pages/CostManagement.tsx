import { useState } from 'react'
import { toast } from 'react-toastify'
import './CostManagement.css'

export default function CostManagement() {
  const [monthlyBudget, setMonthlyBudget] = useState(10000)
  const currentSpend = 6842.50
  const projectedSpend = 9200
  const budgetUsed = (currentSpend / monthlyBudget) * 100

  const costBreakdown = [
    { model: 'Llama 3.1 8B', cost: 1987.45, percentage: 29, color: '#0078d4' },
    { model: 'GPT-4 Turbo (Azure)', cost: 2134.56, percentage: 31, color: '#107c10' },
    { model: 'Mixtral 8x7B', cost: 1456.32, percentage: 21, color: '#faa500' },
    { model: 'Llama 3.1 70B', cost: 876.54, percentage: 13, color: '#d13438' },
    { model: 'Mistral Large 2', cost: 387.63, percentage: 6, color: '#881798' },
  ]

  const costByApplication = [
    { name: 'Product Information Q&A', cost: 2345.67, queries: 18234 },
    { name: 'Market Research Assistant', cost: 1876.43, queries: 12456 },
    { name: 'HR Policy Assistant', cost: 1234.56, queries: 8945 },
    { name: 'Contract Review', cost: 876.32, queries: 456 },
    { name: 'Client Intelligence API', cost: 509.52, queries: 2456 },
  ]

  const optimizationRecommendations = [
    {
      id: 'opt-1',
      type: 'model_switch',
      title: 'Switch to Llama 3.1 8B for HR queries',
      potential_savings: 450,
      impact: 'low',
      description: 'HR Policy Assistant queries have simple patterns. Llama 3.1 8B can handle 95% of queries at lower cost.',
    },
    {
      id: 'opt-2',
      type: 'caching',
      title: 'Enable caching for repeated queries',
      potential_savings: 320,
      impact: 'medium',
      description: '23% of queries are near-duplicates. Semantic caching can reduce redundant LLM calls.',
    },
    {
      id: 'opt-3',
      type: 'token_optimization',
      title: 'Reduce max_tokens for Product Q&A',
      potential_savings: 180,
      impact: 'low',
      description: 'Average response is 456 tokens but max_tokens is set to 2000. Optimize to 1000 tokens.',
    },
  ]

  return (
    <div className="cost-management-page">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1 className="page-title">Cost Management</h1>
          <p className="page-subtitle">Monitor and optimize LLM spending across your organization</p>
        </div>
        <div className="header-actions">
          <button className="btn btn-secondary">
            <span className="btn-icon">📊</span>
            Export Report
          </button>
          <button className="btn btn-primary">
            <span className="btn-icon">⚙️</span>
            Configure Budgets
          </button>
        </div>
      </div>

      {/* Budget Overview */}
      <div className="budget-overview card">
        <h2 className="card-title">Monthly Budget</h2>
        <div className="budget-progress">
          <div className="budget-amount">
            <div className="current-spend">
              <span className="label">Current Spend</span>
              <span className="value">${currentSpend.toLocaleString()}</span>
            </div>
            <div className="budget-limit">
              <span className="label">Budget Limit</span>
              <span className="value">${monthlyBudget.toLocaleString()}</span>
            </div>
          </div>
          <div className="progress-bar-container">
            <div className="progress-bar-bg">
              <div
                className={`progress-bar-fill ${budgetUsed > 90 ? 'danger' : budgetUsed > 80 ? 'warning' : 'success'}`}
                style={{ width: `${Math.min(budgetUsed, 100)}%` }}
              />
            </div>
            <div className="progress-labels">
              <span>0%</span>
              <span className={budgetUsed > 90 ? 'text-danger' : budgetUsed > 80 ? 'text-warning' : ''}>
                {budgetUsed.toFixed(1)}% Used
              </span>
              <span>100%</span>
            </div>
          </div>
          <div className="projected-spend">
            <span className="label">Projected Month-End:</span>
            <span className={`value ${projectedSpend > monthlyBudget ? 'text-danger' : ''}`}>
              ${projectedSpend.toLocaleString()}
            </span>
            {projectedSpend > monthlyBudget && (
              <span className="warning-badge">⚠️ Over Budget</span>
            )}
          </div>
        </div>
      </div>

      {/* Cost Breakdown */}
      <div className="cost-breakdown-grid">
        <div className="card">
          <h2 className="card-title">Cost by Model</h2>
          <div className="cost-chart">
            {costBreakdown.map((item) => (
              <div key={item.model} className="cost-bar-item">
                <div className="cost-bar-label">
                  <span className="model-name">{item.model}</span>
                  <span className="cost-amount">${item.cost.toLocaleString()}</span>
                </div>
                <div className="cost-bar-wrapper">
                  <div
                    className="cost-bar-fill"
                    style={{ width: `${item.percentage}%`, backgroundColor: item.color }}
                  />
                  <span className="cost-percentage">{item.percentage}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <h2 className="card-title">Cost by Application</h2>
          <div className="application-costs">
            {costByApplication.map((app) => (
              <div key={app.name} className="app-cost-item">
                <div className="app-cost-info">
                  <div className="app-name">{app.name}</div>
                  <div className="app-queries">{app.queries.toLocaleString()} queries</div>
                </div>
                <div className="app-cost-amount">${app.cost.toLocaleString()}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Optimization Recommendations */}
      <div className="card">
        <div className="card-header">
          <h2 className="card-title">Cost Optimization Recommendations</h2>
          <div className="total-savings">
            Potential Monthly Savings: <strong>${optimizationRecommendations.reduce((sum, opt) => sum + opt.potential_savings, 0)}</strong>
          </div>
        </div>
        <div className="recommendations-list">
          {optimizationRecommendations.map((rec) => (
            <div key={rec.id} className="recommendation-card">
              <div className="rec-header">
                <div className="rec-icon">{rec.type === 'model_switch' ? '🔄' : rec.type === 'caching' ? '💾' : '⚡'}</div>
                <div className="rec-content">
                  <div className="rec-title">{rec.title}</div>
                  <div className="rec-description">{rec.description}</div>
                </div>
                <div className="rec-savings">
                  <div className="savings-amount">${rec.potential_savings}/mo</div>
                  <span className={`badge impact-${rec.impact}`}>{rec.impact} impact</span>
                </div>
              </div>
              <div className="rec-actions">
                <button className="btn btn-secondary btn-sm">Learn More</button>
                <button className="btn btn-primary btn-sm">Apply Optimization</button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Budget Alerts */}
      <div className="card">
        <h2 className="card-title">Budget Alert Configuration</h2>
        <div className="alert-settings">
          <div className="alert-setting-item">
            <label className="checkbox-label">
              <input type="checkbox" defaultChecked />
              <span>Alert at 80% of budget</span>
            </label>
          </div>
          <div className="alert-setting-item">
            <label className="checkbox-label">
              <input type="checkbox" defaultChecked />
              <span>Alert at 90% of budget</span>
            </label>
          </div>
          <div className="alert-setting-item">
            <label className="checkbox-label">
              <input type="checkbox" defaultChecked />
              <span>Alert at 100% of budget</span>
            </label>
          </div>
          <div className="alert-setting-item">
            <label className="checkbox-label">
              <input type="checkbox" />
              <span>Auto-switch to cheaper models at 90%</span>
            </label>
          </div>
        </div>
      </div>
    </div>
  )
}

