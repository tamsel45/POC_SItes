import { useParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { Card, Select, Button } from '@fluentui/react-components'
import { AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { analyticsApi } from '../services/api'
import './Analytics.css'

const COLORS = ['#0078d4', '#107c10', '#faa500', '#d13438', '#881798', '#00b294']

export default function Analytics() {
  const { id } = useParams()

  const { data } = useQuery({
    queryKey: ['analytics', id],
    queryFn: () => analyticsApi.get(id!, '30d'),
  })

  const analytics = data?.data

  if (!analytics) {
    return <div>Loading analytics...</div>
  }

  return (
    <div className="analytics">
      <div className="analytics-header">
        <h1>📊 Analytics & Monitoring</h1>
        <div className="analytics-actions">
          <Select defaultValue="30d">
            <option value="7d">Last 7 Days</option>
            <option value="30d">Last 30 Days</option>
            <option value="90d">Last 90 Days</option>
          </Select>
          <Button>📥 Export Report</Button>
          <Button>📧 Schedule Email</Button>
        </div>
      </div>

      <div className="metrics-grid">
        <Card className="metric-card-large">
          <h3>Total Conversations</h3>
          <div className="metric-value-large">{analytics.metrics.total_conversations.toLocaleString()}</div>
          <div className="metric-change positive">↑ 18%</div>
        </Card>

        <Card className="metric-card-large">
          <h3>Success Rate</h3>
          <div className="metric-value-large">{analytics.metrics.success_rate}%</div>
          <div className="metric-change positive">↑ 2%</div>
        </Card>

        <Card className="metric-card-large">
          <h3>Avg Latency</h3>
          <div className="metric-value-large">{analytics.metrics.avg_latency}s</div>
          <div className="metric-change positive">↓ 15%</div>
        </Card>

        <Card className="metric-card-large">
          <h3>User Satisfaction</h3>
          <div className="metric-value-large">{analytics.metrics.user_satisfaction}/5.0</div>
          <div className="metric-change positive">↑ 0.3</div>
        </Card>
      </div>

      <Card className="chart-card">
        <h2>📈 Conversation Trends</h2>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={analytics.conversation_trends}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Area type="monotone" dataKey="count" stroke="#0078d4" fill="#0078d4" fillOpacity={0.3} />
          </AreaChart>
        </ResponsiveContainer>
      </Card>

      <div className="charts-grid">
        <Card className="chart-card">
          <h2>⏱️ Response Time Distribution</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={analytics.response_time_distribution}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="bucket" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="count" fill="#0078d4" />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card className="chart-card">
          <h2>🎯 Top Intents</h2>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={analytics.top_intents}
                dataKey="percentage"
                nameKey="intent"
                cx="50%"
                cy="50%"
                outerRadius={80}
                label
              >
                {analytics.top_intents.map((entry: any, index: number) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </Card>
      </div>

      <div className="info-grid">
        <Card className="info-card">
          <h2>⚠️ Error Analysis</h2>
          <div className="error-list">
            <p><strong>Total Errors:</strong> {analytics.error_breakdown.reduce((sum: number, e: any) => sum + e.count, 0)} (5.8%)</p>
            {analytics.error_breakdown.map((error: any, idx: number) => (
              <div key={idx} className="error-item">
                <span>{error.type}</span>
                <span>{error.count} ({error.percentage}%)</span>
              </div>
            ))}
          </div>
        </Card>

        <Card className="info-card">
          <h2>💰 Cost Analysis</h2>
          <div className="cost-list">
            <p><strong>Total Cost:</strong> ${analytics.cost_breakdown.reduce((sum: number, c: any) => sum + c.amount, 0).toFixed(2)}</p>
            {analytics.cost_breakdown.map((cost: any, idx: number) => (
              <div key={idx} className="cost-item">
                <span>{cost.category}</span>
                <span>${cost.amount.toFixed(2)} ({cost.percentage}%)</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  )
}

