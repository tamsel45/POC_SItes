import { useState } from 'react'
import { toast } from 'react-toastify'
import { apiClient } from '../services/api'
import './Deployments.css'

const MOCK_DEPLOYMENTS = [
  {
    id: 'deploy-1',
    agent: 'Product Information Q&A (MAESTRO)',
    agentId: 'maestro-001',
    environment: 'production',
    version: 'v2.1.0',
    status: 'running',
    url: 'https://api.orchestra.ai/prod/maestro-001',
    replicas: 3,
    cpu: '45%',
    memory: '62%',
    requests24h: 18234,
    uptime: '99.97%',
    deployedAt: '2024-12-01T10:00:00Z',
    deployedBy: 'Subha',
  },
  {
    id: 'deploy-2',
    agent: 'Market Research Assistant (MAESTRO)',
    agentId: 'maestro-003',
    environment: 'production',
    version: 'v1.5.2',
    status: 'running',
    url: 'https://api.orchestra.ai/prod/maestro-003',
    replicas: 2,
    cpu: '38%',
    memory: '54%',
    requests24h: 12456,
    uptime: '99.94%',
    deployedAt: '2024-12-02T11:00:00Z',
    deployedBy: 'Marc Batrand',
  },
  {
    id: 'deploy-3',
    agent: 'Contract Review Assistant (DocIntel)',
    agentId: 'docintel-001',
    environment: 'staging',
    version: 'v0.9.5-beta',
    status: 'running',
    url: 'https://api.orchestra.ai/staging/docintel-001',
    replicas: 1,
    cpu: '23%',
    memory: '41%',
    requests24h: 456,
    uptime: '99.82%',
    deployedAt: '2024-12-03T14:00:00Z',
    deployedBy: 'Sathish',
  },
  {
    id: 'deploy-4',
    agent: 'Client Intelligence API (CLIENTELE)',
    agentId: 'clientele-001',
    environment: 'production',
    version: 'v3.2.1',
    status: 'running',
    url: 'https://api.orchestra.ai/prod/clientele-001',
    replicas: 4,
    cpu: '52%',
    memory: '68%',
    requests24h: 8934,
    uptime: '99.99%',
    deployedAt: '2024-09-15T10:00:00Z',
    deployedBy: 'Mark Web',
  },
]

const STATUS_COLORS: Record<string, string> = {
  running: 'success',
  stopped: 'secondary',
  deploying: 'warning',
  failed: 'danger',
}

const STATUS_ICONS: Record<string, string> = {
  running: '✓',
  stopped: '○',
  deploying: '⟳',
  failed: '✕',
}

export default function Deployments() {
  const [deployments, setDeployments] = useState(MOCK_DEPLOYMENTS)
  const [selectedEnv, setSelectedEnv] = useState('all')
  const [actionLoading, setActionLoading] = useState<string | null>(null)

  const filteredDeployments = deployments.filter(
    (d) => selectedEnv === 'all' || d.environment === selectedEnv
  )

  const runningCount = deployments.filter((d) => d.status === 'running').length
  const totalRequests = deployments.reduce((sum, d) => sum + d.requests24h, 0)

  const handleStart = async (deploymentId: string) => {
    setActionLoading(deploymentId)
    try {
      await apiClient.post(`/deployments/${deploymentId}/start`)
      
      // Update local state
      setDeployments(deployments.map(d => 
        d.id === deploymentId ? { ...d, status: 'running' } : d
      ))
      
      toast.success('✅ Deployment started successfully')
    } catch (error: any) {
      console.error('Start error:', error)
      toast.error(error.response?.data?.detail || 'Failed to start deployment')
    } finally {
      setActionLoading(null)
    }
  }

  const handleStop = async (deploymentId: string) => {
    if (!confirm('Are you sure you want to stop this deployment?')) return
    
    setActionLoading(deploymentId)
    try {
      await apiClient.post(`/deployments/${deploymentId}/stop`)
      
      // Update local state
      setDeployments(deployments.map(d => 
        d.id === deploymentId ? { ...d, status: 'stopped', cpu: '0%', memory: '0%' } : d
      ))
      
      toast.success('✅ Deployment stopped')
    } catch (error: any) {
      console.error('Stop error:', error)
      toast.error(error.response?.data?.detail || 'Failed to stop deployment')
    } finally {
      setActionLoading(null)
    }
  }

  const handleRestart = async (deploymentId: string) => {
    setActionLoading(deploymentId)
    try {
      await apiClient.post(`/deployments/${deploymentId}/restart`)
      
      // Update local state
      setDeployments(deployments.map(d => 
        d.id === deploymentId ? { ...d, status: 'deploying' } : d
      ))
      
      toast.success('✅ Deployment restarting...')
      
      // Simulate restart completion
      setTimeout(() => {
        setDeployments(prev => prev.map(d => 
          d.id === deploymentId ? { ...d, status: 'running' } : d
        ))
      }, 2000)
    } catch (error: any) {
      console.error('Restart error:', error)
      toast.error(error.response?.data?.detail || 'Failed to restart deployment')
    } finally {
      setActionLoading(null)
    }
  }

  return (
    <div className="deployments-page">
      {/* Header */}
      <div className="deployments-header">
        <div>
          <h1 className="page-title">Deployments</h1>
          <p className="page-subtitle">
            Manage agent deployments across environments
          </p>
        </div>
        <button className="btn btn-primary" onClick={() => handleDeploy('new')}>
          <span className="btn-icon">🚀</span>
          New Deployment
        </button>
      </div>

      {/* Stats */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon green">✓</div>
          <div>
            <div className="stat-value">{runningCount}</div>
            <div className="stat-label">Running</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon blue">📊</div>
          <div>
            <div className="stat-value">{totalRequests.toLocaleString()}</div>
            <div className="stat-label">Requests (24h)</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon purple">⚡</div>
          <div>
            <div className="stat-value">99.9%</div>
            <div className="stat-label">Avg Uptime</div>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon orange">🔄</div>
          <div>
            <div className="stat-value">{deployments.reduce((sum, d) => sum + d.replicas, 0)}</div>
            <div className="stat-label">Total Replicas</div>
          </div>
        </div>
      </div>

      {/* Environment Filter */}
      <div className="env-filter">
        <button
          className={`env-btn ${selectedEnv === 'all' ? 'active' : ''}`}
          onClick={() => setSelectedEnv('all')}
        >
          All Environments
        </button>
        <button
          className={`env-btn ${selectedEnv === 'production' ? 'active' : ''}`}
          onClick={() => setSelectedEnv('production')}
        >
          🟢 Production
        </button>
        <button
          className={`env-btn ${selectedEnv === 'staging' ? 'active' : ''}`}
          onClick={() => setSelectedEnv('staging')}
        >
          🟡 Staging
        </button>
        <button
          className={`env-btn ${selectedEnv === 'development' ? 'active' : ''}`}
          onClick={() => setSelectedEnv('development')}
        >
          🔵 Development
        </button>
      </div>

      {/* Deployments List */}
      <div className="deployments-list">
        {filteredDeployments.map((deployment) => (
          <div key={deployment.id} className="deployment-card card hover-lift">
            <div className="deployment-header">
              <div className="deployment-main-info">
                <h3 className="deployment-agent">{deployment.agent}</h3>
                <div className="deployment-meta">
                  <span className="env-badge env-{deployment.environment}">
                    {deployment.environment}
                  </span>
                  <span className="version-badge">{deployment.version}</span>
                </div>
              </div>
              <span className={`status-badge ${STATUS_COLORS[deployment.status]}`}>
                {STATUS_ICONS[deployment.status]} {deployment.status}
              </span>
            </div>

            <div className="deployment-url">
              <code>{deployment.url}</code>
              <button className="btn-icon-only" onClick={() => {
                navigator.clipboard.writeText(deployment.url)
                toast.success('URL copied!')
              }}>
                📋
              </button>
            </div>

            <div className="deployment-metrics">
              <div className="metric-item">
                <div className="metric-label">Replicas</div>
                <div className="metric-value">{deployment.replicas}</div>
              </div>
              <div className="metric-item">
                <div className="metric-label">CPU</div>
                <div className="metric-value">{deployment.cpu}</div>
              </div>
              <div className="metric-item">
                <div className="metric-label">Memory</div>
                <div className="metric-value">{deployment.memory}</div>
              </div>
              <div className="metric-item">
                <div className="metric-label">Uptime</div>
                <div className="metric-value">{deployment.uptime}</div>
              </div>
              <div className="metric-item">
                <div className="metric-label">Requests (24h)</div>
                <div className="metric-value">{deployment.requests24h.toLocaleString()}</div>
              </div>
            </div>

            <div className="deployment-footer">
              <div className="deployment-info">
                <span>
                  Deployed {new Date(deployment.deployedAt).toLocaleDateString()} by{' '}
                  {deployment.deployedBy}
                </span>
              </div>
              <div className="deployment-actions">
                {deployment.status === 'running' ? (
                  <>
                    <button
                      className="btn btn-secondary btn-sm"
                      onClick={() => handleRestart(deployment.id)}
                    >
                      🔄 Restart
                    </button>
                    <button
                      className="btn btn-danger btn-sm"
                      onClick={() => handleStop(deployment.id)}
                    >
                      ⏸️ Stop
                    </button>
                  </>
                ) : (
                  <button
                    className="btn btn-primary btn-sm"
                    onClick={() => handleStart(deployment.id)}
                    disabled={actionLoading === deployment.id}
                  >
                    {actionLoading === deployment.id ? '⟳ Starting...' : '▶️ Start'}
                  </button>
                )}
                <button className="btn btn-secondary btn-sm">View Logs</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

