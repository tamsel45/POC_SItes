import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'
import { agentApi } from '../services/api'
import './AgentCreate.css'

export default function AgentCreate() {
  const navigate = useNavigate()
  const [isSubmitting, setIsSubmitting] = useState(false)
  
  // Form state
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [framework, setFramework] = useState('Microsoft Copilot Studio')
  const [languageModel, setLanguageModel] = useState('GPT-4 Turbo')
  const [temperature, setTemperature] = useState(0.7)
  const [maxTokens, setMaxTokens] = useState(2000)
  const [tags, setTags] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!name.trim()) {
      toast.error('Please enter an agent name')
      return
    }

    setIsSubmitting(true)
    try {
      const response = await agentApi.create({
        name: name.trim(),
        description: description.trim(),
        framework,
        language_model: languageModel,
        temperature,
        max_tokens: maxTokens,
        tags: tags.split(',').map(t => t.trim()).filter(t => t)
      })

      const agentId = response.data?.id
      toast.success('✅ Agent created successfully!')
      
      // Navigate to the new agent's detail page
      if (agentId) {
        navigate(`/agents/${agentId}`)
      } else {
        navigate('/agents')
      }
    } catch (error: any) {
      console.error('Create agent error:', error)
      toast.error(error.response?.data?.detail || 'Failed to create agent')
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="agent-create-page">
      {/* Header */}
      <div className="create-header">
        <button className="btn-back" onClick={() => navigate('/agents')}>
          ← Back to Agents
        </button>
        <h1 className="page-title">Create New Agent</h1>
        <p className="page-subtitle">Configure your AI agent's settings and parameters</p>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="create-form">
        <div className="form-section card">
          <h3 className="section-title">Basic Information</h3>
          
          <div className="form-group">
            <label htmlFor="name" className="required">Agent Name</label>
            <input
              type="text"
              id="name"
              className="form-input"
              placeholder="e.g., Product Catalog Q&A, Market Research Assistant"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="description">Description</label>
            <textarea
              id="description"
              className="form-textarea"
              rows={3}
              placeholder="Describe what this agent does..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>

          <div className="form-row">
            <div className="form-group">
              <label htmlFor="framework">Framework</label>
              <select
                id="framework"
                className="form-select"
                value={framework}
                onChange={(e) => setFramework(e.target.value)}
              >
                <option value="Microsoft Copilot Studio">Microsoft Copilot Studio</option>
                <option value="LangChain">LangChain</option>
                <option value="Semantic Kernel">Semantic Kernel</option>
                <option value="Custom">Custom</option>
              </select>
            </div>

            <div className="form-group">
              <label htmlFor="language-model">Language Model</label>
              <select
                id="language-model"
                className="form-select"
                value={languageModel}
                onChange={(e) => setLanguageModel(e.target.value)}
              >
                <option value="GPT-4 Turbo">GPT-4 Turbo</option>
                <option value="GPT-4">GPT-4</option>
                <option value="GPT-3.5 Turbo">GPT-3.5 Turbo</option>
                <option value="Claude 3 Opus">Claude 3 Opus</option>
                <option value="Claude 3 Sonnet">Claude 3 Sonnet</option>
                <option value="Claude 3 Haiku">Claude 3 Haiku</option>
              </select>
            </div>
          </div>

          <div className="form-group">
            <label htmlFor="tags">Tags (comma-separated)</label>
            <input
              type="text"
              id="tags"
              className="form-input"
              placeholder="e.g., support, customer-service, production"
              value={tags}
              onChange={(e) => setTags(e.target.value)}
            />
          </div>
        </div>

        <div className="form-section card">
          <h3 className="section-title">Model Configuration</h3>
          
          <div className="form-group">
            <label htmlFor="temperature">
              Temperature: <strong>{temperature.toFixed(1)}</strong>
            </label>
            <input
              type="range"
              id="temperature"
              min="0"
              max="2"
              step="0.1"
              value={temperature}
              onChange={(e) => setTemperature(parseFloat(e.target.value))}
              className="slider"
            />
            <div className="slider-labels">
              <span>Precise (0)</span>
              <span>Creative (2)</span>
            </div>
            <p className="form-hint">
              Lower values make the output more focused and deterministic. Higher values make it more creative.
            </p>
          </div>

          <div className="form-group">
            <label htmlFor="max-tokens">
              Max Tokens: <strong>{maxTokens}</strong>
            </label>
            <input
              type="range"
              id="max-tokens"
              min="100"
              max="4000"
              step="100"
              value={maxTokens}
              onChange={(e) => setMaxTokens(parseInt(e.target.value))}
              className="slider"
            />
            <div className="slider-labels">
              <span>100</span>
              <span>4000</span>
            </div>
            <p className="form-hint">
              Maximum number of tokens to generate in the response.
            </p>
          </div>
        </div>

        <div className="form-actions">
          <button
            type="button"
            className="btn btn-secondary"
            onClick={() => navigate('/agents')}
            disabled={isSubmitting}
          >
            Cancel
          </button>
          <button
            type="submit"
            className="btn btn-primary"
            disabled={isSubmitting}
          >
            {isSubmitting ? '⏳ Creating...' : '🚀 Create Agent'}
          </button>
        </div>
      </form>
    </div>
  )
}

