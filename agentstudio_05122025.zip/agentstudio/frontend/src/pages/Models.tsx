import { useState } from 'react'
import { toast } from 'react-toastify'
import { apiClient } from '../services/api'
import './Models.css'

const LLM_PROVIDERS = [
  {
    id: 'azure',
    name: 'Azure OpenAI',
    icon: '☁️',
    status: 'connected',
    models: ['GPT-4o', 'GPT-4 Turbo', 'GPT-4', 'GPT-3.5 Turbo'],
    pricing: { input: 0.01, output: 0.03 },
  },
  {
    id: 'llama',
    name: 'Meta Llama',
    icon: '🦙',
    status: 'connected',
    models: ['Llama 3.1 405B', 'Llama 3.1 70B', 'Llama 3.1 8B', 'Llama 3 70B', 'Llama 3 8B', 'Llama 2 70B', 'Llama 2 13B', 'Llama 2 7B'],
    pricing: { input: 0.0008, output: 0.0024 },
  },
  {
    id: 'mistral',
    name: 'Mistral AI',
    icon: '🌪️',
    status: 'connected',
    models: ['Mistral Large 2', 'Mistral Large', 'Mixtral 8x22B', 'Mixtral 8x7B', 'Mistral 7B'],
    pricing: { input: 0.001, output: 0.003 },
  },
]

const MODEL_CONFIGURATIONS = [
  {
    id: 'config-1',
    name: 'Production GPT-4 (Azure)',
    provider: 'azure',
    model: 'GPT-4 Turbo',
    temperature: 0.7,
    maxTokens: 1000,
    topP: 0.9,
    frequencyPenalty: 0,
    presencePenalty: 0,
    agents: 12,
    requestsLast30Days: 45678,
    avgLatency: 1.8,
  },
  {
    id: 'config-2',
    name: 'Fast Llama 3.1 8B',
    provider: 'llama',
    model: 'Llama 3.1 8B',
    temperature: 0.5,
    maxTokens: 2048,
    topP: 1,
    frequencyPenalty: 0,
    presencePenalty: 0,
    agents: 8,
    requestsLast30Days: 23456,
    avgLatency: 0.6,
  },
  {
    id: 'config-3',
    name: 'Mistral Mixtral 8x7B',
    provider: 'mistral',
    model: 'Mixtral 8x7B',
    temperature: 0.8,
    maxTokens: 4096,
    topP: 0.95,
    frequencyPenalty: 0.2,
    presencePenalty: 0.1,
    agents: 15,
    requestsLast30Days: 34567,
    avgLatency: 0.9,
  },
  {
    id: 'config-4',
    name: 'High-Capacity Llama 3.1 405B',
    provider: 'llama',
    model: 'Llama 3.1 405B',
    temperature: 0.6,
    maxTokens: 8192,
    topP: 0.9,
    frequencyPenalty: 0,
    presencePenalty: 0,
    agents: 5,
    requestsLast30Days: 12456,
    avgLatency: 2.4,
  },
]

export default function Models() {
  const [activeTab, setActiveTab] = useState<'providers' | 'configurations' | 'usage'>('providers')
  const [selectedProvider, setSelectedProvider] = useState<string | null>(null)
  const [showConfigModal, setShowConfigModal] = useState(false)
  const [providers, setProviders] = useState(LLM_PROVIDERS)
  const [configurations, setConfigurations] = useState(MODEL_CONFIGURATIONS)
  const [saving, setSaving] = useState(false)

  const handleConnect = async (providerId: string) => {
    try {
      const apiKey = prompt(`Enter API key for ${providerId}:`)
      if (!apiKey) return
      
      await apiClient.post('/models/providers/connect', { providerId, apiKey })
      
      setProviders(providers.map(p => 
        p.id === providerId ? { ...p, status: 'connected' } : p
      ))
      
      toast.success(`✅ Connected to ${providerId}`)
    } catch (error: any) {
      console.error('Connect error:', error)
      toast.error(error.response?.data?.detail || 'Failed to connect provider')
    }
  }

  const handleDisconnect = async (providerId: string) => {
    if (!confirm('Are you sure you want to disconnect this provider?')) return
    
    try {
      await apiClient.post('/models/providers/disconnect', { providerId })
      
      setProviders(providers.map(p => 
        p.id === providerId ? { ...p, status: 'not-connected' } : p
      ))
      
      toast.success(`✅ Disconnected from ${providerId}`)
    } catch (error: any) {
      console.error('Disconnect error:', error)
      toast.error(error.response?.data?.detail || 'Failed to disconnect provider')
    }
  }

  const handleTestConnection = async (providerId: string) => {
    try {
      toast.info(`Testing connection to ${providerId}...`)
      await apiClient.post('/models/providers/test', { providerId })
      toast.success('✅ Connection test successful!')
    } catch (error: any) {
      console.error('Test error:', error)
      toast.error(error.response?.data?.detail || 'Connection test failed')
    }
  }
  
  const handleSaveConfiguration = async (config: any) => {
    setSaving(true)
    try {
      if (config.id) {
        await apiClient.put(`/models/configurations/${config.id}`, config)
        setConfigurations(configurations.map(c => c.id === config.id ? config : c))
        toast.success('✅ Configuration updated')
      } else {
        const response = await apiClient.post('/models/configurations', config)
        setConfigurations([...configurations, { ...config, id: response.data.id }])
        toast.success('✅ Configuration created')
      }
      setShowConfigModal(false)
    } catch (error: any) {
      console.error('Save error:', error)
      toast.error(error.response?.data?.detail || 'Failed to save configuration')
    } finally {
      setSaving(false)
    }
  }
  
  const handleDeleteConfiguration = async (configId: string) => {
    if (!confirm('Are you sure you want to delete this configuration?')) return
    
    try {
      await apiClient.delete(`/models/configurations/${configId}`)
      setConfigurations(configurations.filter(c => c.id !== configId))
      toast.success('✅ Configuration deleted')
    } catch (error: any) {
      console.error('Delete error:', error)
      toast.error(error.response?.data?.detail || 'Failed to delete configuration')
    }
  }

  return (
    <div className="models-page">
      {/* Header */}
      <div className="models-header">
        <div>
          <h1 className="page-title">Models & LLMs</h1>
          <p className="page-subtitle">
            Manage AI model providers, configurations, and monitor usage
          </p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowConfigModal(true)}>
          <span className="btn-icon">➕</span>
          New Configuration
        </button>
      </div>

      {/* Tabs */}
      <div className="models-tabs">
        <button
          className={`tab ${activeTab === 'providers' ? 'active' : ''}`}
          onClick={() => setActiveTab('providers')}
        >
          <span className="tab-icon">🔌</span>
          Providers ({LLM_PROVIDERS.filter((p) => p.status === 'connected').length})
        </button>
        <button
          className={`tab ${activeTab === 'configurations' ? 'active' : ''}`}
          onClick={() => setActiveTab('configurations')}
        >
          <span className="tab-icon">⚙️</span>
          Configurations ({MODEL_CONFIGURATIONS.length})
        </button>
        <button
          className={`tab ${activeTab === 'usage' ? 'active' : ''}`}
          onClick={() => setActiveTab('usage')}
        >
          <span className="tab-icon">📊</span>
          Usage & Costs
        </button>
      </div>

      {/* Tab Content */}
      <div className="tab-content">
        {/* Providers Tab */}
        {activeTab === 'providers' && (
          <div className="providers-content">
            <div className="providers-grid">
              {LLM_PROVIDERS.map((provider) => (
                <div key={provider.id} className="provider-card card hover-lift">
                  <div className="provider-header">
                    <div className="provider-icon-name">
                      <span className="provider-icon-large">{provider.icon}</span>
                      <div>
                        <h3 className="provider-name">{provider.name}</h3>
                        <span
                          className={`status-badge ${
                            provider.status === 'connected' ? 'success' : 'secondary'
                          }`}
                        >
                          {provider.status === 'connected' ? '● Connected' : '○ Not Connected'}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="provider-models">
                    <label>Available Models:</label>
                    <div className="models-list">
                      {provider.models.map((model, idx) => (
                        <span key={idx} className="model-badge">
                          {model}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="provider-pricing">
                    <label>Pricing (per 1K tokens):</label>
                    <div className="pricing-info">
                      <span>Input: ${provider.pricing.input}</span>
                      <span>•</span>
                      <span>Output: ${provider.pricing.output}</span>
                    </div>
                  </div>

                  <div className="provider-actions">
                    {provider.status === 'connected' ? (
                      <>
                        <button
                          className="btn btn-secondary btn-sm"
                          onClick={() => handleTestConnection(provider.id)}
                        >
                          <span className="btn-icon">🧪</span>
                          Test
                        </button>
                        <button
                          className="btn btn-secondary btn-sm"
                          onClick={() => setSelectedProvider(provider.id)}
                        >
                          <span className="btn-icon">⚙️</span>
                          Configure
                        </button>
                        <button
                          className="btn btn-danger btn-sm"
                          onClick={() => handleDisconnect(provider.id)}
                        >
                          Disconnect
                        </button>
                      </>
                    ) : (
                      <button
                        className="btn btn-primary btn-full"
                        onClick={() => handleConnect(provider.id)}
                      >
                        <span className="btn-icon">🔌</span>
                        Connect Provider
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>

            {/* Add Custom Provider */}
            <div className="card add-provider-card">
              <span className="add-icon">➕</span>
              <h3>Add Custom Provider</h3>
              <p>Connect to your own model endpoint or self-hosted LLM</p>
              <button className="btn btn-secondary">Configure Custom Endpoint</button>
            </div>
          </div>
        )}

        {/* Configurations Tab */}
        {activeTab === 'configurations' && (
          <div className="configurations-content">
            <div className="configurations-list">
              {MODEL_CONFIGURATIONS.map((config) => {
                const provider = LLM_PROVIDERS.find((p) => p.id === config.provider)
                return (
                  <div key={config.id} className="config-card card hover-lift">
                    <div className="config-header">
                      <div className="config-main-info">
                        <span className="provider-icon">{provider?.icon}</span>
                        <div>
                          <h3 className="config-name">{config.name}</h3>
                          <p className="config-model">
                            {provider?.name} • {config.model}
                          </p>
                        </div>
                      </div>
                      <div className="config-actions">
                        <button className="btn-icon-only" title="Edit">
                          ✏️
                        </button>
                        <button className="btn-icon-only" title="Duplicate">
                          📋
                        </button>
                        <button className="btn-icon-only" title="Delete">
                          🗑️
                        </button>
                      </div>
                    </div>

                    <div className="config-params">
                      <div className="param-item">
                        <label>Temperature</label>
                        <span className="param-value">{config.temperature}</span>
                      </div>
                      <div className="param-item">
                        <label>Max Tokens</label>
                        <span className="param-value">{config.maxTokens}</span>
                      </div>
                      <div className="param-item">
                        <label>Top P</label>
                        <span className="param-value">{config.topP}</span>
                      </div>
                      <div className="param-item">
                        <label>Frequency Penalty</label>
                        <span className="param-value">{config.frequencyPenalty}</span>
                      </div>
                    </div>

                    <div className="config-stats">
                      <div className="stat">
                        <span className="stat-label">Agents Using</span>
                        <span className="stat-value">{config.agents}</span>
                      </div>
                      <div className="stat">
                        <span className="stat-label">Requests (30d)</span>
                        <span className="stat-value">
                          {config.requestsLast30Days.toLocaleString()}
                        </span>
                      </div>
                      <div className="stat">
                        <span className="stat-label">Avg Latency</span>
                        <span className="stat-value">{config.avgLatency}s</span>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {/* Usage Tab */}
        {activeTab === 'usage' && (
          <div className="usage-content">
            <div className="usage-grid">
              {/* Cost Summary */}
              <div className="card usage-summary">
                <h3 className="card-title">Cost Summary (Last 30 Days)</h3>
                <div className="cost-breakdown">
                  <div className="cost-item total">
                    <span className="cost-label">Total Spend</span>
                    <span className="cost-value">$1,245.67</span>
                  </div>
                  <div className="cost-item">
                    <span className="cost-icon">🤖</span>
                    <div>
                      <span className="cost-label">OpenAI</span>
                      <span className="cost-value">$876.23</span>
                    </div>
                  </div>
                  <div className="cost-item">
                    <span className="cost-icon">🧠</span>
                    <div>
                      <span className="cost-label">Anthropic</span>
                      <span className="cost-value">$345.12</span>
                    </div>
                  </div>
                  <div className="cost-item">
                    <span className="cost-icon">☁️</span>
                    <div>
                      <span className="cost-label">Azure OpenAI</span>
                      <span className="cost-value">$24.32</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Token Usage */}
              <div className="card">
                <h3 className="card-title">Token Usage</h3>
                <div className="token-stats">
                  <div className="token-stat">
                    <span className="token-icon">📤</span>
                    <div>
                      <div className="token-value">12.5M</div>
                      <div className="token-label">Input Tokens</div>
                    </div>
                  </div>
                  <div className="token-stat">
                    <span className="token-icon">📥</span>
                    <div>
                      <div className="token-value">8.3M</div>
                      <div className="token-label">Output Tokens</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Model Usage Chart */}
              <div className="card chart-card">
                <h3 className="card-title">Usage by Model</h3>
                <div className="chart-placeholder">
                  <div className="usage-bars">
                    <div className="usage-bar-item">
                      <span className="bar-label">GPT-4 Turbo (Azure)</span>
                      <div className="bar-wrapper">
                        <div className="bar" style={{ width: '72%' }}></div>
                        <span className="bar-value">72%</span>
                      </div>
                    </div>
                    <div className="usage-bar-item">
                      <span className="bar-label">Llama 3.1 8B</span>
                      <div className="bar-wrapper">
                        <div className="bar" style={{ width: '58%' }}></div>
                        <span className="bar-value">58%</span>
                      </div>
                    </div>
                    <div className="usage-bar-item">
                      <span className="bar-label">Mixtral 8x7B</span>
                      <div className="bar-wrapper">
                        <div className="bar" style={{ width: '45%' }}></div>
                        <span className="bar-value">45%</span>
                      </div>
                    </div>
                    <div className="usage-bar-item">
                      <span className="bar-label">Llama 3.1 70B</span>
                      <div className="bar-wrapper">
                        <div className="bar" style={{ width: '38%' }}></div>
                        <span className="bar-value">38%</span>
                      </div>
                    </div>
                    <div className="usage-bar-item">
                      <span className="bar-label">Llama 3.1 405B</span>
                      <div className="bar-wrapper">
                        <div className="bar" style={{ width: '22%' }}></div>
                        <span className="bar-value">22%</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Request Volume */}
              <div className="card chart-card">
                <h3 className="card-title">Request Volume (Last 7 Days)</h3>
                <div className="chart-placeholder">
                  <div className="volume-chart">
                    <div className="volume-bar" style={{ height: '60%' }}></div>
                    <div className="volume-bar" style={{ height: '75%' }}></div>
                    <div className="volume-bar" style={{ height: '55%' }}></div>
                    <div className="volume-bar" style={{ height: '90%' }}></div>
                    <div className="volume-bar" style={{ height: '70%' }}></div>
                    <div className="volume-bar" style={{ height: '65%' }}></div>
                    <div className="volume-bar" style={{ height: '80%' }}></div>
                  </div>
                  <div className="chart-labels">
                    <span>Mon</span>
                    <span>Tue</span>
                    <span>Wed</span>
                    <span>Thu</span>
                    <span>Fri</span>
                    <span>Sat</span>
                    <span>Sun</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Config Modal */}
      {showConfigModal && (
        <div className="modal-overlay" onClick={() => setShowConfigModal(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Create Model Configuration</h2>
              <button className="modal-close" onClick={() => setShowConfigModal(false)}>
                ✕
              </button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label htmlFor="config-name">Configuration Name</label>
                <input type="text" id="config-name" className="form-input" placeholder="e.g., Production Llama 3.1 70B" />
              </div>
              <div className="form-group">
                <label htmlFor="provider">Provider</label>
                <select id="provider" className="form-select">
                  <option value="">Select a provider...</option>
                  {LLM_PROVIDERS.filter((p) => p.status === 'connected').map((provider) => (
                    <option key={provider.id} value={provider.id}>
                      {provider.icon} {provider.name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="form-group">
                <label htmlFor="model">Model</label>
                <select id="model" className="form-select">
                  <option value="">Select a model...</option>
                  <optgroup label="Azure OpenAI">
                    <option value="gpt-4o">GPT-4o</option>
                    <option value="gpt-4-turbo">GPT-4 Turbo</option>
                    <option value="gpt-4">GPT-4</option>
                    <option value="gpt-3.5-turbo">GPT-3.5 Turbo</option>
                  </optgroup>
                  <optgroup label="Meta Llama">
                    <option value="llama-3.1-405b">Llama 3.1 405B</option>
                    <option value="llama-3.1-70b">Llama 3.1 70B</option>
                    <option value="llama-3.1-8b">Llama 3.1 8B</option>
                    <option value="llama-3-70b">Llama 3 70B</option>
                    <option value="llama-3-8b">Llama 3 8B</option>
                    <option value="llama-2-70b">Llama 2 70B</option>
                    <option value="llama-2-13b">Llama 2 13B</option>
                    <option value="llama-2-7b">Llama 2 7B</option>
                  </optgroup>
                  <optgroup label="Mistral AI">
                    <option value="mistral-large-2">Mistral Large 2</option>
                    <option value="mistral-large">Mistral Large</option>
                    <option value="mixtral-8x22b">Mixtral 8x22B</option>
                    <option value="mixtral-8x7b">Mixtral 8x7B</option>
                    <option value="mistral-7b">Mistral 7B</option>
                  </optgroup>
                </select>
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={() => setShowConfigModal(false)}>
                Cancel
              </button>
              <button className="btn btn-primary" onClick={() => {
                toast.success('Configuration created!')
                setShowConfigModal(false)
              }}>
                Create Configuration
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

