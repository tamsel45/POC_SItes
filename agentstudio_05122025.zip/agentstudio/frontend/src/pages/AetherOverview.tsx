import { useNavigate } from 'react-router-dom'
import './AetherOverview.css'

export default function AetherOverview() {
  const navigate = useNavigate()

  const systemStatus = {
    overallHealth: 'operational',
    securityScore: 98,
    uptime: 99.97,
    layers: [
      {
        id: 1,
        name: 'Guardrails Filter',
        color: 'navy',
        icon: '🛡️',
        status: 'active',
        description: 'Content protection and safety filters',
        todayBlocked: 45,
        metric: 'Blocked harmful content',
        path: '/aether/guardrails'
      },
      {
        id: 2,
        name: 'Hallucination Shield',
        color: 'orange',
        icon: '⚠️',
        status: 'active',
        description: 'Response accuracy validation',
        todayBlocked: 12456,
        metric: 'Validated responses (99.73% accurate)',
        path: '/hallucination'
      },
      {
        id: 3,
        name: 'Security Firewall',
        color: 'black',
        icon: '🔒',
        status: 'active',
        description: 'OWASP/MITRE attack prevention',
        todayBlocked: 12,
        metric: 'Attacks blocked',
        path: '/governance'
      },
      {
        id: 4,
        name: 'Audit & Compliance',
        color: 'blue',
        icon: '📋',
        status: 'active',
        description: 'Complete interaction logging',
        todayBlocked: 1234567,
        metric: 'Interactions logged',
        path: '/audit'
      },
      {
        id: 5,
        name: 'Cost & Observability',
        color: 'gray',
        icon: '💰',
        status: 'active',
        description: 'Real-time monitoring and optimization',
        todayBlocked: 234.56,
        metric: "Today's cost (47% of budget)",
        path: '/cost-management'
      }
    ]
  }

  const inputProblems = [
    { label: 'Hallucinations risk', severity: 'high' },
    { label: 'Security vulnerabilities', severity: 'high' },
    { label: 'Cost overruns', severity: 'high' },
    { label: 'Compliance gaps', severity: 'high' },
    { label: 'Content safety', severity: 'high' }
  ]

  const outputBenefits = [
    { label: 'Safe & Compliant', status: 'achieved' },
    { label: 'Accurate & Reliable', status: 'achieved' },
    { label: 'Fully Auditable', status: 'achieved' },
    { label: 'Optimized Performance', status: 'achieved' },
    { label: 'Cost Controlled', status: 'achieved' }
  ]

  return (
    <div className="aether-overview-page">
      {/* Header */}
      <div className="aether-header">
        <div className="aether-logo">
          <span className="aether-icon">⚡</span>
          <h1 className="aether-title">THE AETHER FILTER</h1>
        </div>
        <p className="aether-subtitle">
          Five-Layer Governance Framework for Enterprise GenAI
        </p>
        <div className="aether-status">
          <span className={`status-indicator ${systemStatus.overallHealth}`}>
            ● ALL LAYERS OPERATIONAL
          </span>
          <span className="status-metric">Security Score: {systemStatus.securityScore}/100</span>
          <span className="status-metric">Uptime: {systemStatus.uptime}%</span>
        </div>
      </div>

      {/* Transformation Flow */}
      <div className="transformation-flow">
        <div className="flow-section input-section">
          <div className="flow-header">
            <h3 className="flow-title">Input: UNGOVERNED GEN AI</h3>
            <span className="risk-badge high">HIGH RISK</span>
          </div>
          <div className="problem-list">
            {inputProblems.map((problem, idx) => (
              <div key={idx} className={`problem-item ${problem.severity}`}>
                <span className="problem-icon">⚠️</span>
                <span className="problem-label">{problem.label}</span>
                <span className={`severity-badge ${problem.severity}`}>
                  {problem.severity.toUpperCase()}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="flow-arrow">
          <div className="arrow-line"></div>
          <div className="arrow-label">
            <span className="filter-icon">⚡</span>
            AETHER FILTER
            <br />
            <small>5 Layers of Protection</small>
          </div>
          <div className="arrow-head">▼</div>
        </div>

        <div className="flow-section output-section">
          <div className="flow-header">
            <h3 className="flow-title">Output: SECURE, AUDITABLE, OPTIMIZED GEN AI</h3>
            <span className="risk-badge low">PROTECTED</span>
          </div>
          <div className="benefit-list">
            {outputBenefits.map((benefit, idx) => (
              <div key={idx} className={`benefit-item ${benefit.status}`}>
                <span className="benefit-icon">✓</span>
                <span className="benefit-label">{benefit.label}</span>
                <span className={`status-badge ${benefit.status}`}>ACHIEVED</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Five Layer Protection */}
      <div className="layers-section">
        <h2 className="section-title">Five-Layer Protection System</h2>
        <div className="layers-grid">
          {systemStatus.layers.map((layer) => (
            <div
              key={layer.id}
              className={`layer-card layer-${layer.color} hover-lift`}
              onClick={() => navigate(layer.path)}
            >
              <div className="layer-header">
                <div className="layer-number">Layer {layer.id}</div>
                <div className={`layer-status ${layer.status}`}>
                  <span className="status-dot">●</span>
                  {layer.status.toUpperCase()}
                </div>
              </div>
              <div className="layer-icon">{layer.icon}</div>
              <h3 className="layer-name">{layer.name}</h3>
              <p className="layer-description">{layer.description}</p>
              <div className="layer-metric">
                <div className="metric-label">{layer.metric}</div>
                <div className="metric-value">
                  {typeof layer.todayBlocked === 'number' && layer.todayBlocked > 1000
                    ? layer.todayBlocked.toLocaleString()
                    : layer.todayBlocked}
                  {layer.id === 5 && ' today'}
                  {layer.id !== 5 && layer.id !== 2 && ' today'}
                </div>
              </div>
              <button className="layer-button">
                Configure Layer →
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Data Flow Visualization */}
      <div className="data-flow-section">
        <h2 className="section-title">Request Processing Flow</h2>
        <div className="flow-diagram">
          <div className="flow-step">
            <div className="step-icon">👤</div>
            <div className="step-label">User Query</div>
          </div>
          <div className="flow-connector">↓</div>
          
          <div className="flow-step layer-step navy">
            <div className="step-icon">🛡️</div>
            <div className="step-label">Layer 1: Guardrails</div>
            <div className="step-detail">Blocks harmful content</div>
            <div className="step-latency">~50ms</div>
          </div>
          <div className="flow-connector">↓</div>
          
          <div className="flow-step layer-step black">
            <div className="step-icon">🔒</div>
            <div className="step-label">Layer 3: Security</div>
            <div className="step-detail">Blocks attacks</div>
            <div className="step-latency">~30ms</div>
          </div>
          <div className="flow-connector">↓</div>
          
          <div className="flow-step llm-step">
            <div className="step-icon">🤖</div>
            <div className="step-label">LLM Processing</div>
            <div className="step-detail">Generate response</div>
            <div className="step-latency">~1500ms</div>
          </div>
          <div className="flow-connector">↓</div>
          
          <div className="flow-step layer-step orange">
            <div className="step-icon">⚠️</div>
            <div className="step-label">Layer 2: Hallucination</div>
            <div className="step-detail">Validates response</div>
            <div className="step-latency">~150ms</div>
          </div>
          <div className="flow-connector">↓</div>
          
          <div className="flow-step layer-step blue">
            <div className="step-icon">📋</div>
            <div className="step-label">Layer 4: Audit</div>
            <div className="step-detail">Logs interaction</div>
            <div className="step-latency">~20ms</div>
          </div>
          <div className="flow-connector">↓</div>
          
          <div className="flow-step layer-step gray">
            <div className="step-icon">💰</div>
            <div className="step-label">Layer 5: Observability</div>
            <div className="step-detail">Tracks metrics</div>
            <div className="step-latency">~10ms</div>
          </div>
          <div className="flow-connector">↓</div>
          
          <div className="flow-step">
            <div className="step-icon">✓</div>
            <div className="step-label">User Response</div>
            <div className="step-total">Total: ~1.76s</div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="quick-actions-section">
        <h2 className="section-title">Quick Actions</h2>
        <div className="actions-grid">
          <button className="action-btn" onClick={() => navigate('/aether/guardrails')}>
            <span className="action-icon">🛡️</span>
            <span className="action-label">Configure Filters</span>
          </button>
          <button className="action-btn" onClick={() => navigate('/audit')}>
            <span className="action-icon">📋</span>
            <span className="action-label">View Audit Trail</span>
          </button>
          <button className="action-btn" onClick={() => navigate('/cost-management')}>
            <span className="action-icon">💰</span>
            <span className="action-label">Cost Report</span>
          </button>
          <button className="action-btn" onClick={() => navigate('/governance')}>
            <span className="action-icon">🔒</span>
            <span className="action-label">Security Dashboard</span>
          </button>
          <button className="action-btn" onClick={() => navigate('/analytics')}>
            <span className="action-icon">📊</span>
            <span className="action-label">Performance Metrics</span>
          </button>
          <button className="action-btn" onClick={() => navigate('/hallucination')}>
            <span className="action-icon">⚠️</span>
            <span className="action-label">Hallucination Shield</span>
          </button>
        </div>
      </div>
    </div>
  )
}

