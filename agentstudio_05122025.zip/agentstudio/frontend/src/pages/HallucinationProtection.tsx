import { useState } from 'react'
import { toast } from 'react-toastify'
import './HallucinationProtection.css'

export default function HallucinationProtection() {
  const [confidenceThreshold, setConfidenceThreshold] = useState(0.75)
  const [autoReject, setAutoReject] = useState(true)
  const [chainOfThought, setChainOfThought] = useState(true)
  const [factChecking, setFactChecking] = useState(true)

  const stats = {
    detectionsToday: 23,
    avgConfidence: 0.87,
    autoRejections: 5,
    humanReviews: 18,
  }

  const recentDetections = [
    {
      id: 'det-001',
      timestamp: '2024-12-05T14:23:12Z',
      application: 'Market Research Assistant',
      query: 'What was the exact stock price of ACME Corp on March 15?',
      response: 'The stock price was $127.35 on March 15, 2024...',
      confidence: 0.42,
      status: 'rejected',
      reason: 'Low confidence - specific financial data not in knowledge base',
    },
    {
      id: 'det-002',
      timestamp: '2024-12-05T13:45:33Z',
      application: 'Product Information Q&A',
      query: 'Does the X200 series support 5G connectivity?',
      response: 'Yes, the X200 series supports 5G connectivity with...',
      confidence: 0.68,
      status: 'flagged',
      reason: 'Medium confidence - partial information in docs',
    },
    {
      id: 'det-003',
      timestamp: '2024-12-05T12:12:45Z',
      application: 'Contract Review Assistant',
      query: 'What are the termination clauses?',
      response: 'The contract can be terminated with 30 days notice...',
      confidence: 0.95,
      status: 'approved',
      reason: 'High confidence - exact match from contract text',
    },
    {
      id: 'det-004',
      timestamp: '2024-12-05T11:33:21Z',
      application: 'HR Policy Assistant',
      query: 'How many vacation days do I get?',
      response: 'Employees receive 25 vacation days per year...',
      confidence: 0.58,
      status: 'review',
      reason: 'Below threshold - requires human verification',
    },
  ]

  const confidenceDistribution = [
    { range: '0.9-1.0', count: 1247, percentage: 62, color: '#107c10' },
    { range: '0.75-0.9', count: 456, percentage: 23, color: '#0078d4' },
    { range: '0.5-0.75', count: 234, percentage: 12, color: '#faa500' },
    { range: '0.0-0.5', count: 67, percentage: 3, color: '#d13438' },
  ]

  return (
    <div className="hallucination-page">
      {/* Header */}
      <div className="page-header">
        <div>
          <h1 className="page-title">Hallucination Protection</h1>
          <p className="page-subtitle">Monitor and prevent AI hallucinations with confidence scoring</p>
        </div>
        <div className="header-actions">
          <button className="btn btn-secondary">
            <span className="btn-icon">📊</span>
            View Reports
          </button>
          <button className="btn btn-primary">
            <span className="btn-icon">⚙️</span>
            Configure Settings
          </button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="metrics-grid">
        <div className="metric-card">
          <div className="metric-icon-wrapper warning">
            <span className="metric-icon">⚠️</span>
          </div>
          <div className="metric-content">
            <div className="metric-label">Detections Today</div>
            <div className="metric-value">{stats.detectionsToday}</div>
            <div className="metric-subtext">{stats.autoRejections} auto-rejected</div>
          </div>
        </div>

        <div className="metric-card">
          <div className="metric-icon-wrapper success">
            <span className="metric-icon">✓</span>
          </div>
          <div className="metric-content">
            <div className="metric-label">Avg Confidence</div>
            <div className="metric-value">{(stats.avgConfidence * 100).toFixed(1)}%</div>
            <div className="metric-trend positive">+3.2% from yesterday</div>
          </div>
        </div>

        <div className="metric-card">
          <div className="metric-icon-wrapper">
            <span className="metric-icon">🚫</span>
          </div>
          <div className="metric-content">
            <div className="metric-label">Auto-Rejections</div>
            <div className="metric-value">{stats.autoRejections}</div>
            <div className="metric-subtext">Below {(confidenceThreshold * 100).toFixed(0)}% threshold</div>
          </div>
        </div>

        <div className="metric-card">
          <div className="metric-icon-wrapper info">
            <span className="metric-icon">👁️</span>
          </div>
          <div className="metric-content">
            <div className="metric-label">Human Reviews</div>
            <div className="metric-value">{stats.humanReviews}</div>
            <div className="metric-subtext">Pending verification</div>
          </div>
        </div>
      </div>

      {/* Configuration Card */}
      <div className="card">
        <h2 className="card-title">Detection Settings</h2>
        <div className="hallucination-settings">
          {/* Confidence Threshold */}
          <div className="setting-section">
            <div className="setting-header">
              <h3>Confidence Threshold</h3>
              <span className="threshold-value">{(confidenceThreshold * 100).toFixed(0)}%</span>
            </div>
            <p className="setting-description">
              Responses below this confidence level will be flagged or rejected. Higher values are more strict.
            </p>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={confidenceThreshold}
              onChange={(e) => setConfidenceThreshold(parseFloat(e.target.value))}
              className="threshold-slider"
            />
            <div className="slider-labels">
              <span>0% (Permissive)</span>
              <span>50% (Balanced)</span>
              <span>100% (Strict)</span>
            </div>
          </div>

          {/* Detection Methods */}
          <div className="setting-section">
            <h3>Detection Methods</h3>
            <div className="toggle-options">
              <label className="toggle-option">
                <input
                  type="checkbox"
                  checked={factChecking}
                  onChange={(e) => setFactChecking(e.target.checked)}
                />
                <div className="toggle-info">
                  <div className="toggle-name">Fact-Checking Layer</div>
                  <div className="toggle-desc">Verify facts against knowledge base sources</div>
                </div>
              </label>

              <label className="toggle-option">
                <input
                  type="checkbox"
                  checked={chainOfThought}
                  onChange={(e) => setChainOfThought(e.target.checked)}
                />
                <div className="toggle-info">
                  <div className="toggle-name">Chain-of-Thought Prompting</div>
                  <div className="toggle-desc">Require LLM to show reasoning steps</div>
                </div>
              </label>

              <label className="toggle-option">
                <input type="checkbox" defaultChecked />
                <div className="toggle-info">
                  <div className="toggle-name">Source Attribution Requirements</div>
                  <div className="toggle-desc">Responses must cite knowledge base sources</div>
                </div>
              </label>

              <label className="toggle-option">
                <input type="checkbox" defaultChecked />
                <div className="toggle-info">
                  <div className="toggle-name">Multi-Step Verification</div>
                  <div className="toggle-desc">Cross-check responses with multiple sources</div>
                </div>
              </label>
            </div>
          </div>

          {/* Response Handling */}
          <div className="setting-section">
            <h3>Response Handling</h3>
            <div className="radio-group">
              <label className="radio-option">
                <input
                  type="radio"
                  name="handling"
                  checked={autoReject}
                  onChange={() => setAutoReject(true)}
                />
                <div className="radio-info">
                  <div className="radio-name">Auto-Reject Below Threshold</div>
                  <div className="radio-desc">Automatically reject low-confidence responses</div>
                </div>
              </label>

              <label className="radio-option">
                <input
                  type="radio"
                  name="handling"
                  checked={!autoReject}
                  onChange={() => setAutoReject(false)}
                />
                <div className="radio-info">
                  <div className="radio-name">Human Review Queue</div>
                  <div className="radio-desc">Send borderline responses for human verification</div>
                </div>
              </label>
            </div>
          </div>
        </div>
      </div>

      {/* Confidence Distribution */}
      <div className="card">
        <h2 className="card-title">Confidence Score Distribution (Last 7 Days)</h2>
        <div className="confidence-chart">
          {confidenceDistribution.map((item) => (
            <div key={item.range} className="confidence-bar-item">
              <div className="confidence-bar-label">
                <span className="confidence-range">{item.range}</span>
                <span className="confidence-count">{item.count} responses</span>
              </div>
              <div className="confidence-bar-wrapper">
                <div
                  className="confidence-bar-fill"
                  style={{ width: `${item.percentage}%`, backgroundColor: item.color }}
                />
                <span className="confidence-percentage">{item.percentage}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Detections */}
      <div className="card">
        <div className="card-header">
          <h2 className="card-title">Recent Detections</h2>
          <div className="card-filters">
            <select className="filter-select">
              <option value="all">All Status</option>
              <option value="rejected">Auto-Rejected</option>
              <option value="flagged">Flagged</option>
              <option value="review">Needs Review</option>
              <option value="approved">Approved</option>
            </select>
            <select className="filter-select">
              <option value="all">All Applications</option>
              <option value="maestro-001">Product Information</option>
              <option value="maestro-003">Market Research</option>
            </select>
          </div>
        </div>

        <div className="detections-list">
          {recentDetections.map((detection) => (
            <div key={detection.id} className={`detection-card status-${detection.status}`}>
              <div className="detection-header">
                <div className="detection-meta">
                  <span className="detection-app">{detection.application}</span>
                  <span className="detection-time">
                    {new Date(detection.timestamp).toLocaleTimeString()}
                  </span>
                </div>
                <span className={`status-badge ${detection.status}`}>
                  {detection.status === 'rejected' && '🚫 Rejected'}
                  {detection.status === 'flagged' && '⚠️ Flagged'}
                  {detection.status === 'approved' && '✓ Approved'}
                  {detection.status === 'review' && '👁️ Review'}
                </span>
              </div>

              <div className="detection-content">
                <div className="detection-query">
                  <strong>Query:</strong> {detection.query}
                </div>
                <div className="detection-response">
                  <strong>Response:</strong> {detection.response}
                </div>
              </div>

              <div className="detection-footer">
                <div className="confidence-indicator">
                  <span className="confidence-label">Confidence:</span>
                  <div className="confidence-bar-mini">
                    <div
                      className={`confidence-fill ${
                        detection.confidence >= 0.75
                          ? 'high'
                          : detection.confidence >= 0.5
                          ? 'medium'
                          : 'low'
                      }`}
                      style={{ width: `${detection.confidence * 100}%` }}
                    />
                  </div>
                  <span className="confidence-value">{(detection.confidence * 100).toFixed(0)}%</span>
                </div>
                <div className="detection-reason">
                  <strong>Reason:</strong> {detection.reason}
                </div>
              </div>

              <div className="detection-actions">
                {detection.status === 'review' && (
                  <>
                    <button className="btn btn-secondary btn-sm">Reject</button>
                    <button className="btn btn-primary btn-sm">Approve</button>
                  </>
                )}
                {detection.status !== 'review' && (
                  <>
                    <button className="btn btn-secondary btn-sm">View Details</button>
                    <button className="btn btn-secondary btn-sm">Report False Positive</button>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

