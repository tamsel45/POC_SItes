import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { useAuthStore } from './store/authStore'
import Layout from './components/Layout'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import AgentList from './pages/AgentList'
import AgentCreate from './pages/AgentCreate'
import AgentDetail from './pages/AgentDetail'
import Governance from './pages/Governance'
import CostManagement from './pages/CostManagement'
import HallucinationProtection from './pages/HallucinationProtection'
import AuditTrail from './pages/AuditTrail'
import AetherOverview from './pages/AetherOverview'
import GuardrailsFilter from './pages/GuardrailsFilter'
import PromptStudio from './pages/PromptStudio'
import PromptLibrary from './pages/PromptLibrary'
import KnowledgeBase from './pages/KnowledgeBase'
import Models from './pages/Models'
import Workflows from './pages/Workflows'
import TestingConsole from './pages/TestingConsole'
import Analytics from './pages/Analytics'
import Logs from './pages/Logs'
import Integrations from './pages/Integrations'
import APIKeys from './pages/APIKeys'
import Deployments from './pages/Deployments'
import Team from './pages/Team'
import Settings from './pages/Settings'
import Profile from './pages/Profile'

function App() {
  const { isAuthenticated } = useAuthStore()

  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        
        {isAuthenticated ? (
          <Route path="/" element={<Layout />}>
            <Route index element={<Navigate to="/dashboard" replace />} />
            
                  {/* Aether Filter */}
                  <Route path="aether">
                    <Route index element={<AetherOverview />} />
                    <Route path="guardrails" element={<GuardrailsFilter />} />
                  </Route>

                  {/* Overview */}
                  <Route path="dashboard" element={<Dashboard />} />
                  <Route path="agents" element={<AgentList />} />
                  <Route path="agents/create" element={<AgentCreate />} />
                  <Route path="agents/:id" element={<AgentDetail />} />
            
            {/* Governance & Security */}
            <Route path="governance" element={<Governance />} />
            <Route path="cost-management" element={<CostManagement />} />
            <Route path="hallucination" element={<HallucinationProtection />} />
            <Route path="audit" element={<AuditTrail />} />
            
            {/* Development */}
            <Route path="prompts" element={<PromptStudio />} />
            <Route path="prompt-library" element={<PromptLibrary />} />
            <Route path="knowledge-base" element={<KnowledgeBase />} />
            <Route path="knowledge-base/:id" element={<KnowledgeBase />} />
            <Route path="models" element={<Models />} />
            <Route path="workflows" element={<Workflows />} />
            
            {/* Testing & Monitoring */}
            <Route path="testing" element={<TestingConsole />} />
            <Route path="analytics" element={<Analytics />} />
            <Route path="logs" element={<Logs />} />
            
            {/* Integration */}
            <Route path="integrations" element={<Integrations />} />
            <Route path="api-keys" element={<APIKeys />} />
            <Route path="deployments" element={<Deployments />} />
            
            {/* Management */}
            <Route path="team" element={<Team />} />
            <Route path="settings" element={<Settings />} />
            
            {/* Profile */}
            <Route path="profile" element={<Profile />} />
            
            {/* Legacy routes for backwards compatibility */}
            <Route path="agents/:id/prompts" element={<PromptStudio />} />
            <Route path="agents/:id/knowledge" element={<KnowledgeBase />} />
            <Route path="agents/:id/testing" element={<TestingConsole />} />
            <Route path="agents/:id/analytics" element={<Analytics />} />
          </Route>
        ) : (
          <Route path="*" element={<Navigate to="/login" replace />} />
        )}
      </Routes>
    </Router>
  )
}

export default App

