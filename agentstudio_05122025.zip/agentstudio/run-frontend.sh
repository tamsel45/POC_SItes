#!/bin/bash
# Start Frontend Development Server

echo "Starting Agent Studio Frontend..."
echo ""

cd frontend

echo "Frontend running at: http://localhost:3000"
echo ""
echo "Press Ctrl+C to stop the server"
echo ""

npm run dev

