# Agent Studio - Windows Setup and Run Script

Write-Host "================================" -ForegroundColor Cyan
Write-Host "Agent Studio Platform Setup" -ForegroundColor Cyan
Write-Host "================================" -ForegroundColor Cyan
Write-Host ""

# Create .env file if it doesn't exist
if (-Not (Test-Path ".env")) {
    Write-Host "Creating .env file..." -ForegroundColor Yellow
    Copy-Item "env.example" ".env"
    Write-Host "✓ Created .env file (please configure with your Azure credentials if needed)" -ForegroundColor Green
}

# Setup Backend
Write-Host ""
Write-Host "Setting up Backend..." -ForegroundColor Cyan
Set-Location backend

# Create virtual environment
if (-Not (Test-Path "venv")) {
    Write-Host "Creating Python virtual environment..." -ForegroundColor Yellow
    python -m venv venv
    Write-Host "✓ Virtual environment created" -ForegroundColor Green
}

# Activate virtual environment and install dependencies
Write-Host "Installing Python dependencies..." -ForegroundColor Yellow
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
Write-Host "✓ Backend dependencies installed" -ForegroundColor Green

# Go back to root
Set-Location ..

# Setup Frontend
Write-Host ""
Write-Host "Setting up Frontend..." -ForegroundColor Cyan
Set-Location frontend

if (-Not (Test-Path "node_modules")) {
    Write-Host "Installing Node.js dependencies..." -ForegroundColor Yellow
    npm install
    Write-Host "✓ Frontend dependencies installed" -ForegroundColor Green
} else {
    Write-Host "✓ Node modules already installed" -ForegroundColor Green
}

# Go back to root
Set-Location ..

Write-Host ""
Write-Host "================================" -ForegroundColor Green
Write-Host "Setup Complete!" -ForegroundColor Green
Write-Host "================================" -ForegroundColor Green
Write-Host ""
Write-Host "To start the application:" -ForegroundColor Cyan
Write-Host "1. Start Backend:  .\run-backend.ps1" -ForegroundColor White
Write-Host "2. Start Frontend: .\run-frontend.ps1" -ForegroundColor White
Write-Host ""
Write-Host "Or use Docker: docker-compose up -d" -ForegroundColor White
Write-Host ""

