# Start Agent Studio Backend - Fixed Version
# This script includes the configuration fix

Write-Host "`n🚀 Starting Agent Studio Backend (Fixed)`n" -ForegroundColor Cyan

cd backend

Write-Host "Backend will start on: http://127.0.0.1:8001" -ForegroundColor Green
Write-Host "API Docs: http://127.0.0.1:8001/api/v1/docs`n" -ForegroundColor Green

# Start server (SECRET_KEY and ALLOWED_ORIGINS now have default values in config)
python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8001

