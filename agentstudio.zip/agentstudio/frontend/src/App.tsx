import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { useAuthStore } from './store/authStore'
import Layout from './components/Layout'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import AgentList from './pages/AgentList'
import AgentDetail from './pages/AgentDetail'
import PromptStudio from './pages/PromptStudio'
import KnowledgeBase from './pages/KnowledgeBase'
import TestingConsole from './pages/TestingConsole'
import Analytics from './pages/Analytics'

function App() {
  const { isAuthenticated } = useAuthStore()

  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        
        {isAuthenticated ? (
          <Route path="/" element={<Layout />}>
            <Route index element={<Navigate to="/dashboard" replace />} />
            <Route path="dashboard" element={<Dashboard />} />
            <Route path="agents" element={<AgentList />} />
            <Route path="agents/:id" element={<AgentDetail />} />
            <Route path="agents/:id/prompts" element={<PromptStudio />} />
            <Route path="agents/:id/knowledge" element={<KnowledgeBase />} />
            <Route path="agents/:id/testing" element={<TestingConsole />} />
            <Route path="agents/:id/analytics" element={<Analytics />} />
          </Route>
        ) : (
          <Route path="*" element={<Navigate to="/login" replace />} />
        )}
      </Routes>
    </Router>
  )
}

export default App

