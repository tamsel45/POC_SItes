import axios from 'axios'
import { useAuthStore } from '../store/authStore'

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8001/api/v1'

export const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
})

// Request interceptor to add auth token
apiClient.interceptors.request.use(
  (config) => {
    const token = useAuthStore.getState().token
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// Response interceptor for error handling
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      useAuthStore.getState().logout()
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

// Agent API
export const agentApi = {
  list: (params?: any) => apiClient.get('/agents', { params }),
  get: (id: string) => apiClient.get(`/agents/${id}`),
  create: (data: any) => apiClient.post('/agents', data),
  update: (id: string, data: any) => apiClient.put(`/agents/${id}`, data),
  delete: (id: string) => apiClient.delete(`/agents/${id}`),
  invoke: (id: string, input: string, debug?: boolean) =>
    apiClient.post(`/agents/${id}/invoke`, { input, debug }),
}

// Prompt API
export const promptApi = {
  list: (agentId: string) => apiClient.get(`/prompts/${agentId}`),
  create: (data: any) => apiClient.post('/prompts', data),
  test: (data: any) => apiClient.post('/prompts/test', data),
}

// Knowledge Base API
export const knowledgeBaseApi = {
  listDocuments: (agentId: string) => apiClient.get(`/knowledge-base/${agentId}/documents`),
  getStats: (agentId: string) => apiClient.get(`/knowledge-base/${agentId}/stats`),
  upload: (agentId: string, files: File[], options: any) => {
    const formData = new FormData()
    files.forEach((file) => formData.append('files', file))
    formData.append('agent_id', agentId)
    Object.entries(options).forEach(([key, value]) => {
      formData.append(key, String(value))
    })
    return apiClient.post('/knowledge-base/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    })
  },
  delete: (documentId: string) => apiClient.delete(`/knowledge-base/${documentId}`),
  reindex: (documentId: string) => apiClient.post(`/knowledge-base/${documentId}/reindex`),
}

// Testing API
export const testingApi = {
  runSingle: (agentId: string, input: string, debug?: boolean) =>
    apiClient.post('/testing/single', null, { params: { agent_id: agentId, input_text: input, debug } }),
  runBatch: (data: any) => apiClient.post('/testing/batch', data),
}

// Analytics API
export const analyticsApi = {
  get: (agentId: string, period?: string) =>
    apiClient.get(`/analytics/${agentId}`, { params: { period } }),
  export: (agentId: string, period: string, format: string) =>
    apiClient.get(`/analytics/${agentId}/export`, { params: { period, format } }),
}

