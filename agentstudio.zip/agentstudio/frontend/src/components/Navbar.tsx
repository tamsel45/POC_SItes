import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Button,
  Menu,
  MenuItem,
  MenuList,
  MenuPopover,
  MenuTrigger,
  Input,
  Avatar,
} from '@fluentui/react-components'
import {
  PersonRegular,
  SignOutRegular,
  SettingsRegular,
  SearchRegular,
  AlertRegular,
  QuestionCircleRegular,
  DarkThemeRegular,
} from '@fluentui/react-icons'
import { useAuthStore } from '../store/authStore'
import './Navbar.css'

export default function Navbar() {
  const navigate = useNavigate()
  const { user, logout } = useAuthStore()
  const [searchOpen, setSearchOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    // Implement search functionality
    console.log('Searching for:', searchQuery)
  }

  return (
    <nav className="navbar">
      <div className="navbar-content">
        {/* Brand */}
        <div className="navbar-brand">
          <div className="brand-logo">
            <span className="brand-icon">🤖</span>
            <span className="brand-name">Agent Studio</span>
          </div>
          <span className="brand-badge">Enterprise</span>
        </div>

        {/* Search */}
        <div className="navbar-search">
          <form onSubmit={handleSearch} className="search-form">
            <SearchRegular className="search-icon" />
            <input
              type="text"
              placeholder="Search agents, prompts, docs... (Ctrl+K)"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="search-input"
            />
            <kbd className="search-kbd">⌘K</kbd>
          </form>
        </div>

        {/* Actions */}
        <div className="navbar-actions">
          {/* Help */}
          <Button
            appearance="subtle"
            icon={<QuestionCircleRegular />}
            className="navbar-action-btn"
            title="Help & Documentation"
          />

          {/* Notifications */}
          <Menu>
            <MenuTrigger disableButtonEnhancement>
              <Button
                appearance="subtle"
                icon={<AlertRegular />}
                className="navbar-action-btn navbar-notifications"
                title="Notifications"
              >
                <span className="notification-badge">3</span>
              </Button>
            </MenuTrigger>
            <MenuPopover>
              <div className="notifications-panel">
                <div className="notifications-header">
                  <h3>Notifications</h3>
                  <Button size="small" appearance="transparent">
                    Mark all read
                  </Button>
                </div>
                <div className="notifications-list">
                  <div className="notification-item unread">
                    <div className="notification-icon success">✓</div>
                    <div className="notification-content">
                      <div className="notification-title">Agent deployed successfully</div>
                      <div className="notification-time">2 minutes ago</div>
                    </div>
                  </div>
                  <div className="notification-item unread">
                    <div className="notification-icon warning">⚠</div>
                    <div className="notification-content">
                      <div className="notification-title">High error rate detected</div>
                      <div className="notification-time">15 minutes ago</div>
                    </div>
                  </div>
                  <div className="notification-item">
                    <div className="notification-icon info">ℹ</div>
                    <div className="notification-content">
                      <div className="notification-title">New model available</div>
                      <div className="notification-time">1 hour ago</div>
                    </div>
                  </div>
                </div>
              </div>
            </MenuPopover>
          </Menu>

          {/* Theme Toggle */}
          <Button
            appearance="subtle"
            icon={<DarkThemeRegular />}
            className="navbar-action-btn"
            title="Toggle Theme"
          />

          {/* User Menu */}
          <Menu>
            <MenuTrigger disableButtonEnhancement>
              <button className="user-menu-trigger">
                <Avatar
                  name={user?.fullName || user?.email}
                  size={32}
                  color="brand"
                />
                <div className="user-info">
                  <div className="user-name">{user?.fullName || user?.email}</div>
                  <div className="user-role">Admin</div>
                </div>
              </button>
            </MenuTrigger>

            <MenuPopover>
              <MenuList>
                <MenuItem icon={<PersonRegular />}>Profile</MenuItem>
                <MenuItem icon={<SettingsRegular />}>Settings</MenuItem>
                <MenuItem icon={<SignOutRegular />} onClick={handleLogout}>
                  Logout
                </MenuItem>
              </MenuList>
            </MenuPopover>
          </Menu>
        </div>
      </div>
    </nav>
  )
}
