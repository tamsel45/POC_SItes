import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import {
  Card,
  Button,
  Input,
  Select,
  Menu,
  MenuItem,
  MenuList,
  MenuPopover,
  MenuTrigger,
  Badge,
  Avatar,
} from '@fluentui/react-components'
import {
  AddRegular,
  EditRegular,
  BeakerRegular,
  ChartMultipleRegular,
  DeleteRegular,
  MoreVerticalRegular,
  FilterRegular,
  ArrowSortRegular,
  GridRegular,
  ListRegular,
} from '@fluentui/react-icons'
import { agentApi } from '../services/api'
import './AgentList.css'

export default function AgentList() {
  const navigate = useNavigate()
  const [searchQuery, setSearchQuery] = useState('')
  const [filterStatus, setFilterStatus] = useState('all')
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')

  const { data, isLoading } = useQuery({
    queryKey: ['agents', searchQuery, filterStatus],
    queryFn: () =>
      agentApi.list({
        search: searchQuery,
        status: filterStatus !== 'all' ? filterStatus : undefined,
      }),
  })

  const agents = data?.data?.agents || []

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      active: { color: 'success' as const, icon: '●' },
      paused: { color: 'warning' as const, icon: '●' },
      inactive: { color: 'danger' as const, icon: '●' },
    }
    const config = statusConfig[status as keyof typeof statusConfig]
    return (
      <Badge color={config?.color} appearance="filled" size="small">
        {config?.icon} {status}
      </Badge>
    )
  }

  const getFrameworkIcon = (framework: string) => {
    const icons: Record<string, string> = {
      'Microsoft Copilot Studio': '🤖',
      'LangChain': '🦜',
      'Semantic Kernel': '🧠',
    }
    return icons[framework] || '🔧'
  }

  return (
    <div className="agent-list-container">
      {/* Header */}
      <div className="agent-list-header">
        <div className="header-left">
          <h1 className="page-title">Agents</h1>
          <p className="page-subtitle">Manage your AI agents and their configurations</p>
        </div>
        <Button appearance="primary" icon={<AddRegular />} onClick={() => navigate('/agents/create')} size="large">
          Create Agent
        </Button>
      </div>

      {/* Filters & Controls */}
      <div className="controls-bar">
        <div className="controls-left">
          <div className="search-box">
            <Input
              placeholder="Search agents..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="search-input"
              size="large"
            />
          </div>

          <Select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="filter-select"
            size="large"
          >
            <option value="all">All Status</option>
            <option value="active">Active</option>
            <option value="paused">Paused</option>
            <option value="inactive">Inactive</option>
          </Select>

          <Button icon={<FilterRegular />} appearance="subtle">
            More Filters
          </Button>
        </div>

        <div className="controls-right">
          <Button icon={<ArrowSortRegular />} appearance="subtle">
            Sort
          </Button>
          <div className="view-toggle">
            <Button
              icon={<GridRegular />}
              appearance={viewMode === 'grid' ? 'primary' : 'subtle'}
              onClick={() => setViewMode('grid')}
            />
            <Button
              icon={<ListRegular />}
              appearance={viewMode === 'list' ? 'primary' : 'subtle'}
              onClick={() => setViewMode('list')}
            />
          </div>
        </div>
      </div>

      {/* Stats Bar */}
      <div className="stats-bar">
        <div className="stat-item">
          <span className="stat-icon">🤖</span>
          <span className="stat-label">All Agents</span>
          <span className="stat-value">{agents.length}</span>
        </div>
        <div className="stat-item">
          <span className="stat-icon">🟢</span>
          <span className="stat-label">Active</span>
          <span className="stat-value">{agents.filter((a: any) => a.status === 'active').length}</span>
        </div>
        <div className="stat-item">
          <span className="stat-icon">⏸️</span>
          <span className="stat-label">Paused</span>
          <span className="stat-value">{agents.filter((a: any) => a.status === 'paused').length}</span>
        </div>
        <div className="stat-item">
          <span className="stat-icon">⭐</span>
          <span className="stat-label">Favorites</span>
          <span className="stat-value">2</span>
        </div>
      </div>

      {/* Agents Grid/List */}
      {isLoading ? (
        <div className="loading-state">
          <div className="spinner" />
          <p>Loading agents...</p>
        </div>
      ) : (
        <div className={viewMode === 'grid' ? 'agents-grid' : 'agents-list'}>
          {agents.map((agent: any) => (
            <Card key={agent.id} className="agent-card hover-lift">
              {/* Card Header */}
              <div className="agent-card-header">
                <div className="agent-header-left">
                  <div className="agent-avatar">
                    {getFrameworkIcon(agent.framework)}
                  </div>
                  <div className="agent-header-info">
                    <h3 className="agent-name">{agent.name}</h3>
                    {getStatusBadge(agent.status)}
                  </div>
                </div>
                <Menu>
                  <MenuTrigger disableButtonEnhancement>
                    <Button icon={<MoreVerticalRegular />} appearance="subtle" size="small" />
                  </MenuTrigger>
                  <MenuPopover>
                    <MenuList>
                      <MenuItem icon={<EditRegular />} onClick={() => navigate(`/agents/${agent.id}`)}>
                        Edit
                      </MenuItem>
                      <MenuItem icon={<BeakerRegular />} onClick={() => navigate(`/agents/${agent.id}/testing`)}>
                        Test
                      </MenuItem>
                      <MenuItem icon={<ChartMultipleRegular />} onClick={() => navigate(`/agents/${agent.id}/analytics`)}>
                        Analytics
                      </MenuItem>
                      <MenuItem icon={<DeleteRegular />}>Delete</MenuItem>
                    </MenuList>
                  </MenuPopover>
                </Menu>
              </div>

              {/* Description */}
              <p className="agent-description">{agent.description}</p>

              {/* Tags */}
              {agent.tags && agent.tags.length > 0 && (
                <div className="agent-tags">
                  {agent.tags.slice(0, 3).map((tag: string, idx: number) => (
                    <span key={idx} className="agent-tag">
                      {tag}
                    </span>
                  ))}
                  {agent.tags.length > 3 && <span className="agent-tag">+{agent.tags.length - 3}</span>}
                </div>
              )}

              {/* Metrics */}
              <div className="agent-metrics">
                <div className="metric-item">
                  <div className="metric-label">Conversations</div>
                  <div className="metric-value">{agent.conversation_count?.toLocaleString() || 0}</div>
                </div>
                <div className="metric-item">
                  <div className="metric-label">Success Rate</div>
                  <div className="metric-value">{agent.success_rate}%</div>
                </div>
                <div className="metric-item">
                  <div className="metric-label">Avg Response</div>
                  <div className="metric-value">{agent.avg_response_time}s</div>
                </div>
              </div>

              {/* Footer */}
              <div className="agent-card-footer">
                <div className="agent-meta">
                  <Avatar name={agent.created_by} size={20} />
                  <span className="agent-created-by">{agent.created_by}</span>
                  <span className="agent-date">
                    · Updated {new Date(agent.updated_at).toLocaleDateString()}
                  </span>
                </div>
                <div className="agent-actions">
                  <Button
                    size="small"
                    appearance="subtle"
                    icon={<BeakerRegular />}
                    onClick={() => navigate(`/agents/${agent.id}/testing`)}
                  >
                    Test
                  </Button>
                  <Button
                    size="small"
                    appearance="primary"
                    onClick={() => navigate(`/agents/${agent.id}`)}
                  >
                    Open
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Empty State */}
      {!isLoading && agents.length === 0 && (
        <div className="empty-state">
          <div className="empty-icon">🤖</div>
          <h2>No agents found</h2>
          <p>Create your first agent to get started</p>
          <Button appearance="primary" icon={<AddRegular />} onClick={() => navigate('/agents/create')}>
            Create Agent
          </Button>
        </div>
      )}
    </div>
  )
}
