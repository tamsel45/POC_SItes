import { useCallback, useState } from 'react'
import { useParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import {
  Card,
  Button,
  Input,
  Select,
  Tab,
  TabList,
  Progress,
  Badge,
  Menu,
  MenuItem,
  MenuList,
  MenuPopover,
  MenuTrigger,
} from '@fluentui/react-components'
import {
  ArrowUploadRegular,
  LinkRegular,
  GlobeRegular,
  DocumentRegular,
  DeleteRegular,
  MoreVerticalRegular,
  EyeRegular,
  ArrowSyncRegular,
  FilterRegular,
  SearchRegular,
} from '@fluentui/react-icons'
import { useDropzone } from 'react-dropzone'
import { toast } from 'react-toastify'
import { knowledgeBaseApi } from '../services/api'
import './KnowledgeBase.css'

const FILE_ICONS: Record<string, string> = {
  pdf: '📄',
  docx: '📝',
  txt: '📃',
  md: '📋',
  html: '🌐',
  csv: '📊',
}

export default function KnowledgeBase() {
  const { id } = useParams()
  const [activeTab, setActiveTab] = useState('documents')
  const [selectedDocs, setSelectedDocs] = useState<string[]>([])
  const [searchQuery, setSearchQuery] = useState('')
  const [filterType, setFilterType] = useState('all')

  const { data: documents } = useQuery({
    queryKey: ['documents', id],
    queryFn: () => knowledgeBaseApi.listDocuments(id!),
  })

  const { data: stats } = useQuery({
    queryKey: ['kb-stats', id],
    queryFn: () => knowledgeBaseApi.getStats(id!),
  })

  const onDrop = useCallback(
    async (acceptedFiles: File[]) => {
      try {
        await knowledgeBaseApi.upload(id!, acceptedFiles, {
          chunk_size: 512,
          chunk_overlap: 50,
          auto_embed: true,
        })
        toast.success(`${acceptedFiles.length} file(s) uploaded successfully!`)
      } catch (error) {
        toast.error('Failed to upload files')
      }
    },
    [id]
  )

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': [
        '.docx',
      ],
      'text/plain': ['.txt'],
      'text/markdown': ['.md'],
      'text/html': ['.html'],
      'text/csv': ['.csv'],
    },
    maxSize: 25 * 1024 * 1024,
  })

  const docs = documents?.data?.documents || []
  const kbStats = stats?.data

  const getStatusBadge = (status: string) => {
    const config: Record<string, any> = {
      complete: { color: 'success', label: 'Complete' },
      processing: { color: 'warning', label: 'Processing' },
      error: { color: 'danger', label: 'Error' },
    }
    return (
      <Badge color={config[status]?.color} appearance="filled" size="small">
        {config[status]?.label}
      </Badge>
    )
  }

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B'
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB'
  }

  return (
    <div className="knowledge-base">
      {/* Header */}
      <div className="kb-header">
        <div>
          <h1 className="page-title">Knowledge Base</h1>
          <p className="page-subtitle">
            Manage documents and data sources for your AI agents
          </p>
        </div>
        <div className="header-actions">
          <Button icon={<LinkRegular />}>Connect SharePoint</Button>
          <Button icon={<GlobeRegular />}>Crawl Website</Button>
          <Button icon={<ArrowUploadRegular />} appearance="primary">
            Upload Files
          </Button>
        </div>
      </div>

      {/* Stats Dashboard */}
      {kbStats && (
        <div className="stats-dashboard">
          <Card className="stat-card hover-lift">
            <div className="stat-icon-wrapper blue">
              <DocumentRegular className="stat-icon-svg" />
            </div>
            <div className="stat-content">
              <div className="stat-label">Total Documents</div>
              <div className="stat-value">{kbStats.total_documents}</div>
            </div>
          </Card>

          <Card className="stat-card hover-lift">
            <div className="stat-icon-wrapper green">
              <span className="stat-icon">🧩</span>
            </div>
            <div className="stat-content">
              <div className="stat-label">Total Chunks</div>
              <div className="stat-value">{kbStats.total_chunks}</div>
            </div>
          </Card>

          <Card className="stat-card hover-lift">
            <div className="stat-icon-wrapper purple">
              <span className="stat-icon">🔗</span>
            </div>
            <div className="stat-content">
              <div className="stat-label">Embedding Model</div>
              <div className="stat-value-small">{kbStats.embedding_model}</div>
            </div>
          </Card>

          <Card className="stat-card hover-lift">
            <div className="stat-icon-wrapper orange">
              <span className="stat-icon">⚡</span>
            </div>
            <div className="stat-content">
              <div className="stat-label">Avg Retrieval Time</div>
              <div className="stat-value">{kbStats.avg_retrieval_time}s</div>
            </div>
          </Card>
        </div>
      )}

      {/* Upload Area */}
      <Card className="upload-card">
        <div {...getRootProps()} className={`dropzone ${isDragActive ? 'active' : ''}`}>
          <input {...getInputProps()} />
          <div className="dropzone-content">
            <span className="dropzone-icon">
              <ArrowUploadRegular />
            </span>
            <h3 className="dropzone-title">
              {isDragActive ? 'Drop files here...' : 'Upload Documents'}
            </h3>
            <p className="dropzone-text">
              Drag and drop files here, or click to browse
            </p>
            <div className="dropzone-formats">
              <span className="format-badge">📄 PDF</span>
              <span className="format-badge">📝 DOCX</span>
              <span className="format-badge">📃 TXT</span>
              <span className="format-badge">📋 MD</span>
              <span className="format-badge">🌐 HTML</span>
              <span className="format-badge">📊 CSV</span>
            </div>
            <span className="dropzone-limit">Max file size: 25 MB per file</span>
          </div>
        </div>
      </Card>

      {/* Main Content */}
      <div className="kb-main">
        <Card className="kb-content-card">
          {/* Tabs & Controls */}
          <div className="content-header">
            <TabList
              selectedValue={activeTab}
              onTabSelect={(_, data) => setActiveTab(data.value as string)}
              size="large"
            >
              <Tab value="documents" icon={<DocumentRegular />}>
                Documents ({docs.length})
              </Tab>
              <Tab value="connections">Data Connections</Tab>
              <Tab value="settings">Settings</Tab>
            </TabList>

            <div className="content-controls">
              <div className="search-box">
                <SearchRegular className="search-icon" />
                <Input
                  placeholder="Search documents..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="search-input"
                />
              </div>
              <Select value={filterType} onChange={(e) => setFilterType(e.target.value)}>
                <option value="all">All Types</option>
                <option value="pdf">PDF</option>
                <option value="docx">DOCX</option>
                <option value="txt">TXT</option>
              </Select>
              <Button icon={<FilterRegular />} appearance="subtle">
                Filters
              </Button>
            </div>
          </div>

          {/* Documents List */}
          {activeTab === 'documents' && (
            <div className="documents-list">
              {docs.map((doc: any) => (
                <Card key={doc.id} className="document-card hover-lift">
                  <div className="doc-main">
                    <div className="doc-icon">{FILE_ICONS[doc.type] || '📄'}</div>
                    <div className="doc-info">
                      <div className="doc-header">
                        <h3 className="doc-name">{doc.name}</h3>
                        {getStatusBadge(doc.status)}
                      </div>
                      <div className="doc-meta">
                        <span className="meta-item">
                          {formatFileSize(doc.size)}
                        </span>
                        <span className="meta-separator">•</span>
                        <span className="meta-item">{doc.chunks} chunks</span>
                        <span className="meta-separator">•</span>
                        <span className="meta-item">
                          Uploaded {new Date(doc.uploaded_at).toLocaleDateString()}
                        </span>
                      </div>
                      {doc.status === 'processing' && (
                        <div className="doc-progress">
                          <Progress value={65} max={100} />
                          <span className="progress-text">Processing... 65%</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="doc-actions">
                    <Button
                      icon={<EyeRegular />}
                      appearance="subtle"
                      size="small"
                      title="Preview"
                    />
                    <Button
                      icon={<ArrowSyncRegular />}
                      appearance="subtle"
                      size="small"
                      title="Reindex"
                    />
                    <Menu>
                      <MenuTrigger disableButtonEnhancement>
                        <Button
                          icon={<MoreVerticalRegular />}
                          appearance="subtle"
                          size="small"
                        />
                      </MenuTrigger>
                      <MenuPopover>
                        <MenuList>
                          <MenuItem icon={<EyeRegular />}>View Details</MenuItem>
                          <MenuItem icon={<ArrowSyncRegular />}>Reindex</MenuItem>
                          <MenuItem icon={<DeleteRegular />}>Delete</MenuItem>
                        </MenuList>
                      </MenuPopover>
                    </Menu>
                  </div>
                </Card>
              ))}

              {docs.length === 0 && (
                <div className="empty-state">
                  <div className="empty-icon">📚</div>
                  <h2>No documents yet</h2>
                  <p>Upload your first document to get started</p>
                </div>
              )}
            </div>
          )}

          {/* Data Connections */}
          {activeTab === 'connections' && (
            <div className="connections-section">
              <div className="connections-grid">
                <Card className="connection-card">
                  <div className="connection-icon">🔗</div>
                  <h3>SharePoint</h3>
                  <p>Connect to your SharePoint libraries</p>
                  <Button appearance="primary">Connect</Button>
                </Card>

                <Card className="connection-card">
                  <div className="connection-icon">🌐</div>
                  <h3>Website Crawler</h3>
                  <p>Crawl and index website content</p>
                  <Button appearance="primary">Configure</Button>
                </Card>

                <Card className="connection-card">
                  <div className="connection-icon">🗄️</div>
                  <h3>Database</h3>
                  <p>Connect to SQL or NoSQL databases</p>
                  <Button appearance="primary">Setup</Button>
                </Card>

                <Card className="connection-card">
                  <div className="connection-icon">☁️</div>
                  <h3>Cloud Storage</h3>
                  <p>Azure Blob, AWS S3, Google Cloud</p>
                  <Button appearance="primary">Connect</Button>
                </Card>
              </div>
            </div>
          )}

          {/* Settings */}
          {activeTab === 'settings' && (
            <div className="settings-section">
              <div className="settings-group">
                <h3>Chunking Strategy</h3>
                <div className="form-field">
                  <label>Chunk Size</label>
                  <Input type="number" defaultValue="512" />
                </div>
                <div className="form-field">
                  <label>Chunk Overlap</label>
                  <Input type="number" defaultValue="50" />
                </div>
              </div>

              <div className="settings-group">
                <h3>Embedding Configuration</h3>
                <div className="form-field">
                  <label>Embedding Model</label>
                  <Select defaultValue="text-embedding-ada-002">
                    <option value="text-embedding-ada-002">
                      text-embedding-ada-002
                    </option>
                    <option value="text-embedding-3-small">
                      text-embedding-3-small
                    </option>
                    <option value="text-embedding-3-large">
                      text-embedding-3-large
                    </option>
                  </Select>
                </div>
              </div>

              <Button appearance="primary">Save Settings</Button>
            </div>
          )}
        </Card>
      </div>
    </div>
  )
}
