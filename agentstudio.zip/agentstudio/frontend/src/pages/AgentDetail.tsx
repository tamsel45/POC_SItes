import { useParams } from 'react-router-dom'
import { Card } from '@fluentui/react-components'

export default function AgentDetail() {
  const { id } = useParams()

  return (
    <div>
      <h1>Agent Details: {id}</h1>
      <Card>
        <p>Agent detail view - Full implementation coming soon</p>
      </Card>
    </div>
  )
}

