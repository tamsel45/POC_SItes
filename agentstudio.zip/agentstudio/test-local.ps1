# Agent Studio - Local Testing Script

Write-Host "================================" -ForegroundColor Cyan
Write-Host "Agent Studio Local Test" -ForegroundColor Cyan
Write-Host "================================" -ForegroundColor Cyan
Write-Host ""

# Test 1: Backend Health Check
Write-Host "Test 1: Backend Health Check..." -ForegroundColor Yellow
cd backend

$env:SECRET_KEY = "super-secret-key-change-in-production-min-32-chars-long"
$env:DEBUG = "true"
$env:ALLOWED_ORIGINS = "http://localhost:3000,http://localhost:5173"
$env:REDIS_URL = "redis://localhost:6379"

# Start backend in background
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$PWD'; python -m uvicorn app.main:app --reload --host 127.0.0.1 --port 8000" -WindowStyle Minimized

Write-Host "Waiting for backend to start..." -ForegroundColor Yellow
Start-Sleep -Seconds 5

try {
    $response = Invoke-RestMethod -Uri "http://127.0.0.1:8000/health" -Method Get
    if ($response.status -eq "healthy") {
        Write-Host "✓ Backend is running!" -ForegroundColor Green
        Write-Host "  Status: $($response.status)" -ForegroundColor White
        Write-Host "  Version: $($response.version)" -ForegroundColor White
    }
} catch {
    Write-Host "✗ Backend health check failed" -ForegroundColor Red
    Write-Host "  Error: $_" -ForegroundColor Red
}

# Test 2: API Endpoints
Write-Host "" 
Write-Host "Test 2: Testing API Endpoints..." -ForegroundColor Yellow

try {
    $root = Invoke-RestMethod -Uri "http://127.0.0.1:8000/" -Method Get
    Write-Host "✓ Root endpoint working" -ForegroundColor Green
    Write-Host "  Name: $($root.name)" -ForegroundColor White
} catch {
    Write-Host "✗ Root endpoint failed" -ForegroundColor Red
}

# Test 3: Login
Write-Host ""
Write-Host "Test 3: Testing Authentication..." -ForegroundColor Yellow

try {
    $body = @{
        email = "admin@agentstudio.com"
        password = "admin123"
    } | ConvertTo-Json

    $response = Invoke-RestMethod -Uri "http://127.0.0.1:8000/api/v1/auth/login" -Method Post -Body $body -ContentType "application/json"
    Write-Host "✓ Login successful!" -ForegroundColor Green
    Write-Host "  Token: $($response.access_token.Substring(0, 20))..." -ForegroundColor White
    
    # Store token for further tests
    $token = $response.access_token
} catch {
    Write-Host "✗ Login failed" -ForegroundColor Red
}

# Test 4: List Agents
Write-Host ""
Write-Host "Test 4: Testing Agent Listing..." -ForegroundColor Yellow

try {
    $headers = @{
        Authorization = "Bearer $token"
    }
    $agents = Invoke-RestMethod -Uri "http://127.0.0.1:8000/api/v1/agents" -Method Get -Headers $headers
    Write-Host "✓ Agent listing working!" -ForegroundColor Green
    Write-Host "  Total agents: $($agents.total)" -ForegroundColor White
    if ($agents.agents.Count -gt 0) {
        Write-Host "  First agent: $($agents.agents[0].name)" -ForegroundColor White
    }
} catch {
    Write-Host "✗ Agent listing failed" -ForegroundColor Red
}

cd ..

Write-Host ""
Write-Host "================================" -ForegroundColor Cyan
Write-Host "Test Summary" -ForegroundColor Cyan
Write-Host "================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Backend API: http://127.0.0.1:8000" -ForegroundColor White
Write-Host "API Docs: http://127.0.0.1:8000/api/v1/docs" -ForegroundColor White
Write-Host ""
Write-Host "Next: Install frontend dependencies and run:" -ForegroundColor Yellow
Write-Host "  cd frontend" -ForegroundColor White
Write-Host "  npm install" -ForegroundColor White
Write-Host "  npm run dev" -ForegroundColor White
Write-Host ""
Write-Host "Then visit: http://localhost:3000" -ForegroundColor Green
Write-Host ""

