#!/bin/bash
# Start Backend Server

echo "Starting Agent Studio Backend..."
echo ""

cd backend
source venv/bin/activate

# Set environment variables for local testing
export SECRET_KEY="super-secret-key-change-in-production-min-32-chars-long"
export DEBUG="true"
export ALLOWED_ORIGINS="http://localhost:3000,http://localhost:5173"
export REDIS_URL="redis://localhost:6379"

echo "Backend running at: http://localhost:8000"
echo "API Docs at: http://localhost:8000/api/v1/docs"
echo ""
echo "Press Ctrl+C to stop the server"
echo ""

uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

