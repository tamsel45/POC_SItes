#!/bin/bash
# Agent Studio - Linux/Mac Setup Script

echo "================================"
echo "Agent Studio Platform Setup"
echo "================================"
echo ""

# Create .env file if it doesn't exist
if [ ! -f ".env" ]; then
    echo "Creating .env file..."
    cp env.example .env
    echo "✓ Created .env file"
fi

# Setup Backend
echo ""
echo "Setting up Backend..."
cd backend

# Create virtual environment
if [ ! -d "venv" ]; then
    echo "Creating Python virtual environment..."
    python3 -m venv venv
    echo "✓ Virtual environment created"
fi

# Activate and install dependencies
source venv/bin/activate
echo "Installing Python dependencies..."
pip install -r requirements.txt
echo "✓ Backend dependencies installed"

cd ..

# Setup Frontend
echo ""
echo "Setting up Frontend..."
cd frontend

if [ ! -d "node_modules" ]; then
    echo "Installing Node.js dependencies..."
    npm install
    echo "✓ Frontend dependencies installed"
else
    echo "✓ Node modules already installed"
fi

cd ..

echo ""
echo "================================"
echo "Setup Complete!"
echo "================================"
echo ""
echo "To start the application:"
echo "1. Start Backend:  ./run-backend.sh"
echo "2. Start Frontend: ./run-frontend.sh"
echo ""
echo "Or use Docker: docker-compose up -d"
echo ""

