"""
Placeholder for API v1 init.
"""

