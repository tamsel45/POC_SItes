"""
Authentication endpoints.
"""
from datetime import timedelta
from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel, EmailStr

from app.core.security import (
    verify_password,
    get_password_hash,
    create_access_token,
)
from app.core.config import settings

router = APIRouter()


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class RegisterRequest(BaseModel):
    email: EmailStr
    password: str
    full_name: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str
    expires_in: int


class UserResponse(BaseModel):
    id: str
    email: str
    full_name: str
    is_active: bool


@router.post("/login", response_model=TokenResponse)
async def login(request: LoginRequest):
    """
    Authenticate user and return access token.
    """
    # TODO: Implement actual user lookup from database
    # This is a placeholder implementation
    if request.email == "admin@agentstudio.com" and request.password == "admin123":
        access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
        access_token = create_access_token(
            data={"sub": "user-001", "email": request.email, "role": "admin"},
            expires_delta=access_token_expires,
        )

        return TokenResponse(
            access_token=access_token,
            token_type="bearer",
            expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        )

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Incorrect email or password",
    )


@router.post("/register", response_model=UserResponse)
async def register(request: RegisterRequest):
    """
    Register a new user.
    """
    # TODO: Implement actual user creation in database
    # This is a placeholder implementation
    hashed_password = get_password_hash(request.password)

    return UserResponse(
        id="user-new",
        email=request.email,
        full_name=request.full_name,
        is_active=True,
    )


@router.post("/refresh")
async def refresh_token():
    """
    Refresh access token.
    """
    # TODO: Implement token refresh logic
    return {"detail": "Token refresh not implemented yet"}


@router.post("/logout")
async def logout():
    """
    Logout user (invalidate token).
    """
    # TODO: Implement token blacklisting
    return {"detail": "Logout successful"}

