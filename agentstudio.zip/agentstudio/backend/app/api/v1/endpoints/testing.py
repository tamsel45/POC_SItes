"""
Testing and debugging endpoints.
"""
from typing import List, Optional
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from datetime import datetime
from enum import Enum

from app.core.security import get_current_user

router = APIRouter()


class TestStatus(str, Enum):
    pass_ = "pass"
    fail = "fail"
    pending = "pending"


class TestCaseBase(BaseModel):
    input: str
    expected_output: Optional[str] = None
    expected_keywords: List[str] = []


class TestCaseCreate(TestCaseBase):
    agent_id: str


class TestCaseResponse(TestCaseBase):
    id: str
    agent_id: str
    result: Optional[TestStatus] = None
    actual_output: Optional[str] = None
    score: Optional[float] = None
    latency: Optional[float] = None
    created_at: datetime


class BatchTestRequest(BaseModel):
    agent_id: str
    test_cases: List[TestCaseBase]


class BatchTestResponse(BaseModel):
    test_id: str
    total_tests: int
    completed: int
    passed: int
    failed: int
    avg_latency: float
    results: List[TestCaseResponse]


@router.post("/batch", response_model=BatchTestResponse)
async def run_batch_tests(
    request: BatchTestRequest,
    current_user: dict = Depends(get_current_user),
):
    """
    Run batch tests on an agent.
    """
    import random
    import time

    results = []
    passed = 0
    total_latency = 0

    for idx, test_case in enumerate(request.test_cases):
        # Simulate test execution
        time.sleep(0.1)
        latency = random.uniform(1.5, 3.0)
        total_latency += latency

        # Mock evaluation
        result_status = random.choice([TestStatus.pass_, TestStatus.pass_, TestStatus.fail])
        if result_status == TestStatus.pass_:
            passed += 1

        test_result = TestCaseResponse(
            id=f"test-{idx + 1}",
            agent_id=request.agent_id,
            input=test_case.input,
            expected_output=test_case.expected_output,
            expected_keywords=test_case.expected_keywords,
            result=result_status,
            actual_output=f"Mock response to: {test_case.input}",
            score=random.uniform(0.7, 0.98) if result_status == TestStatus.pass_ else random.uniform(0.3, 0.6),
            latency=latency,
            created_at=datetime.utcnow(),
        )
        results.append(test_result)

    return BatchTestResponse(
        test_id=f"batch-{datetime.utcnow().timestamp()}",
        total_tests=len(request.test_cases),
        completed=len(results),
        passed=passed,
        failed=len(results) - passed,
        avg_latency=total_latency / len(results) if results else 0,
        results=results,
    )


@router.post("/single")
async def run_single_test(
    agent_id: str,
    input_text: str,
    debug: bool = True,
    current_user: dict = Depends(get_current_user),
):
    """
    Run a single test case.
    """
    import random
    import time

    start_time = time.time()
    time.sleep(0.5)  # Simulate processing

    return {
        "agent_id": agent_id,
        "input": input_text,
        "output": f"Mock response to: {input_text}",
        "latency": time.time() - start_time,
        "tokens_in": len(input_text.split()),
        "tokens_out": random.randint(20, 100),
        "debug": {
            "timestamp": datetime.utcnow().isoformat(),
            "model": "GPT-4 Turbo",
            "temperature": 0.7,
            "kb_queries": [
                {
                    "query": "customer support",
                    "results": 5,
                    "top_score": 0.94,
                }
            ],
        } if debug else None,
    }

