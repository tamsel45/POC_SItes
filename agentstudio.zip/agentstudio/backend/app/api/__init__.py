"""
Placeholder for API endpoints init.
"""

