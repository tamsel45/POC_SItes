const questions = [
    {
        question: "What is Docker primarily used for?",
        options: ["Database management", "Containerization", "Web development", "Network security"],
        answer: "Containerization"
    },
    {
        question: "Which command is used to build a Docker image?",
        options: ["docker run", "docker build", "docker pull", "docker push"],
        answer: "docker build"
    },
    {
        question: "What is a Docker container?",
        options: ["A virtual machine", "A running instance of a Docker image", "A configuration file", "A network protocol"],
        answer: "A running instance of a Docker image"
    },
    {
        question: "Which file defines how to build a Docker image?",
        options: ["docker-compose.yml", "Dockerfile", "docker.json", "container.xml"],
        answer: "Dockerfile"
    },
    {
        question: "What does Kubernetes primarily manage?",
        options: ["Databases", "Containerized applications", "Web servers", "File systems"],
        answer: "Containerized applications"
    },
    {
        question: "Which Kubernetes object is used to run multiple identical pods?",
        options: ["Service", "Deployment", "ConfigMap", "Secret"],
        answer: "Deployment"
    },
    {
        question: "What is the purpose of Docker Compose?",
        options: ["To build single containers", "To orchestrate multi-container applications", "To monitor container performance", "To secure container networks"],
        answer: "To orchestrate multi-container applications"
    },
    {
        question: "Which command lists all running Docker containers?",
        options: ["docker ps", "docker list", "docker show", "docker status"],
        answer: "docker ps"
    },
    {
        question: "What is a Kubernetes pod?",
        options: ["A storage unit", "The smallest deployable unit", "A networking component", "A security policy"],
        answer: "The smallest deployable unit"
    },
    {
        question: "Which Docker command is used to remove a container?",
        options: ["docker delete", "docker rm", "docker remove", "docker erase"],
        answer: "docker rm"
    }
];

let currentQuestionIndex = 0;
let userAnswers = new Array(questions.length).fill(null);
let quizStartTime = null;

function showQuestion(index) {
    const question = questions[index];
    const questionContainer = document.getElementById('questionContainer');
    const questionCounter = document.getElementById('questionCounter');
    const progressBar = document.getElementById('progressBar');
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    const submitBtn = document.getElementById('submitBtn');

    questionCounter.textContent = `Question ${index + 1} of ${questions.length}`;
    progressBar.style.width = `${((index + 1) / questions.length) * 100}%`;

    let html = `<h4 class="mb-4 text-start fw-bold">${question.question}</h4>`;
    question.options.forEach((option, i) => {
        const isSelected = userAnswers[index] === option;
        const selectedClass = isSelected ? 'option-card selected' : 'option-card';
        html += `
            <div class="${selectedClass} mb-3 p-3 rounded-3 shadow-sm" onclick="selectAnswer('${option.replace(/'/g, "\\'")}')">
                <div class="d-flex align-items-center">
                    <div class="option-radio me-3 ${isSelected ? 'selected' : ''}"></div>
                    <span class="option-text">${option}</span>
                </div>
            </div>
        `;
    });
    questionContainer.innerHTML = html;

    prevBtn.disabled = index === 0;
    if (index === questions.length - 1) {
        nextBtn.style.display = 'none';
        submitBtn.style.display = 'inline-block';
    } else {
        nextBtn.style.display = 'inline-block';
        submitBtn.style.display = 'none';
    }

    // Update button states based on selection
    updateNextButtonState();
}

function selectAnswer(answer) {
    userAnswers[currentQuestionIndex] = answer;
    // Re-render the current question to show selection immediately
    showQuestion(currentQuestionIndex);
}

function updateNextButtonState() {
    const nextBtn = document.getElementById('nextBtn');
    const submitBtn = document.getElementById('submitBtn');
    const prevBtn = document.getElementById('prevBtn');
    
    const hasAnswer = userAnswers[currentQuestionIndex] !== null;
    
    if (nextBtn) {
        nextBtn.disabled = !hasAnswer;
        nextBtn.style.opacity = hasAnswer ? '1' : '0.5';
    }
    
    if (submitBtn) {
        submitBtn.disabled = !hasAnswer;
        submitBtn.style.opacity = hasAnswer ? '1' : '0.5';
    }
    
    // Previous button should always be enabled (except on first question)
    if (prevBtn) {
        prevBtn.disabled = currentQuestionIndex === 0;
        prevBtn.style.opacity = currentQuestionIndex === 0 ? '0.5' : '1';
    }
}

function nextQuestion() {
    if (userAnswers[currentQuestionIndex] === null) {
        // Show warning if no answer selected
        showWarning('Please select an answer before proceeding to the next question.');
        return;
    }
    
    if (currentQuestionIndex < questions.length - 1) {
        currentQuestionIndex++;
        showQuestion(currentQuestionIndex);
    }
}

function previousQuestion() {
    if (currentQuestionIndex > 0) {
        currentQuestionIndex--;
        showQuestion(currentQuestionIndex);
    }
}

function submitQuiz() {
    if (userAnswers[currentQuestionIndex] === null) {
        // Show warning if no answer selected
        showWarning('Please select an answer before submitting the quiz.');
        return;
    }
    
    const quizEndTime = new Date();
    const duration = quizStartTime ? calculateDuration(quizStartTime, quizEndTime) : 'N/A';
    
    let score = 0;
    questions.forEach((q, i) => {
        if (userAnswers[i] === q.answer) {
            score++;
        }
    });

    // Save quiz to history
    saveQuizToHistory(score, userAnswers, quizEndTime, duration);

    const resultDiv = document.getElementById('result');
    let message = '';
    let actionButtons = '';
    if (score >= 8) {
        message = `<div class="alert alert-success"><i class="bi bi-check-circle-fill me-2"></i>Excellent! You scored ${score} out of ${questions.length}.</div>`;
    } else {
        message = `<div class="alert alert-danger"><i class="bi bi-x-circle-fill me-2"></i>You scored ${score} out of ${questions.length}. Try again!</div>`;
    }
    
    actionButtons = `
        <div class="mt-3">
            <button type="button" class="btn btn-primary me-2" onclick="retakeQuiz()">
                <i class="bi bi-arrow-repeat me-2"></i>Retake Quiz
            </button>
            <button type="button" class="btn btn-info me-2" onclick="location.href='history.html'">
                <i class="bi bi-clock-history me-2"></i>View History
            </button>
            <button type="button" class="btn btn-outline-secondary" onclick="reviewCurrentQuiz()">
                <i class="bi bi-eye me-2"></i>Review Answers
            </button>
        </div>
    `;
    
    resultDiv.innerHTML = message + actionButtons;

    // Disable all option cards after submission
    disableAllOptions();

    // Hide navigation buttons after submission
    document.getElementById('prevBtn').style.display = 'none';
    document.getElementById('nextBtn').style.display = 'none';
    document.getElementById('submitBtn').style.display = 'none';
}

function saveQuizToHistory(score, answers, endTime, duration) {
    const history = JSON.parse(localStorage.getItem('quizHistory') || '[]');
    
    const quizRecord = {
        date: endTime.toLocaleDateString(),
        time: endTime.toLocaleTimeString(),
        score: score,
        answers: [...answers],
        duration: duration,
        timestamp: endTime.getTime()
    };
    
    history.unshift(quizRecord); // Add to beginning of array
    
    // Keep only last 50 records
    if (history.length > 50) {
        history.splice(50);
    }
    
    localStorage.setItem('quizHistory', JSON.stringify(history));
}

function calculateDuration(startTime, endTime) {
    const diffInSeconds = Math.floor((endTime - startTime) / 1000);
    const minutes = Math.floor(diffInSeconds / 60);
    const seconds = diffInSeconds % 60;
    return `${minutes}m ${seconds}s`;
}

function reviewCurrentQuiz() {
    const score = userAnswers.filter((answer, i) => answer === questions[i].answer).length;
    const percentage = Math.round((score / questions.length) * 100);
    
    let reviewHtml = `
        <div class="modal fade" id="currentReviewModal" tabindex="-1">
            <div class="modal-dialog modal-xl">
                <div class="modal-content" style="border-radius: 20px; border: none; overflow: hidden;">
                    <div class="modal-header" style="background: linear-gradient(135deg, #6366f1, #8b5cf6); color: white; border: none;">
                        <h5 class="modal-title d-flex align-items-center gap-2">
                            <div style="background: rgba(255,255,255,0.2); padding: 0.5rem; border-radius: 8px;">
                                <i class="bi bi-search"></i>
                            </div>
                            Quiz Review & Analysis
                        </h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body p-0" style="max-height: 70vh; overflow-y: auto; background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);">
                        <div class="p-4">
                            <div class="row mb-4">
                                <div class="col-md-8">
                                    <div class="d-flex align-items-center mb-3">
                                        <div style="background: linear-gradient(135deg, #6366f1, #8b5cf6); color: white; width: 60px; height: 60px; border-radius: 16px; display: flex; align-items: center; justify-content: center; margin-right: 1rem;">
                                            <i class="bi bi-graph-up" style="font-size: 1.5rem;"></i>
                                        </div>
                                        <div>
                                            <h4 class="mb-1">Quiz Performance Analysis</h4>
                                            <p class="text-muted mb-0">Current Quiz Session</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="text-center">
                                        <div style="position: relative; display: inline-block;">
                                            <svg width="100" height="100" style="transform: rotate(-90deg);">
                                                <circle cx="50" cy="50" r="40" fill="none" stroke="#e2e8f0" stroke-width="8"/>
                                                <circle cx="50" cy="50" r="40" fill="none" stroke="${percentage >= 80 ? '#10b981' : percentage >= 60 ? '#f59e0b' : '#ef4444'}" 
                                                        stroke-width="8" stroke-dasharray="${2 * Math.PI * 40}" 
                                                        stroke-dashoffset="${2 * Math.PI * 40 * (1 - percentage / 100)}"
                                                        stroke-linecap="round"/>
                                            </svg>
                                            <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);">
                                                <div style="font-size: 1.25rem; font-weight: 700; color: ${percentage >= 80 ? '#10b981' : percentage >= 60 ? '#f59e0b' : '#ef4444'};">${percentage}%</div>
                                            </div>
                                        </div>
                                        <div class="mt-2">
                                            ${getStatusBadge(percentage)}
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row mb-4">
                                <div class="col-md-4">
                                    <div style="background: white; padding: 1.5rem; border-radius: 12px; border: 1px solid #e2e8f0;">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div>
                                                <div style="color: #64748b; font-size: 0.875rem; margin-bottom: 0.25rem;">Score</div>
                                                <div style="font-size: 1.5rem; font-weight: 700;">${score}/${questions.length}</div>
                                            </div>
                                            <i class="bi bi-clipboard-check" style="font-size: 1.5rem; color: #6366f1;"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div style="background: white; padding: 1.5rem; border-radius: 12px; border: 1px solid #e2e8f0;">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div>
                                                <div style="color: #64748b; font-size: 0.875rem; margin-bottom: 0.25rem;">Questions</div>
                                                <div style="font-size: 1.5rem; font-weight: 700;">${questions.length}</div>
                                            </div>
                                            <i class="bi bi-question-circle" style="font-size: 1.5rem; color: #06b6d4;"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div style="background: white; padding: 1.5rem; border-radius: 12px; border: 1px solid #e2e8f0;">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <div>
                                                <div style="color: #64748b; font-size: 0.875rem; margin-bottom: 0.25rem;">Performance</div>
                                                <div style="font-size: 1.5rem; font-weight: 700;">${getPerformanceText(percentage)}</div>
                                            </div>
                                            <i class="bi bi-star" style="font-size: 1.5rem; color: #f59e0b;"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div style="background: white; border-radius: 16px; padding: 1.5rem; border: 1px solid #e2e8f0;">
                                <h5 class="mb-3 d-flex align-items-center">
                                    <i class="bi bi-list-check me-2" style="color: #6366f1;"></i>
                                    Detailed Question Review
                                </h5>
    `;
    
    questions.forEach((question, i) => {
        const userAnswer = userAnswers[i];
        const isCorrect = userAnswer === question.answer;
        
        reviewHtml += `
            <div style="background: ${isCorrect ? '#f0fdf4' : '#fef2f2'}; border: 1px solid ${isCorrect ? '#bbf7d0' : '#fecaca'}; border-radius: 12px; padding: 1.25rem; margin-bottom: 1rem;">
                <div class="d-flex justify-content-between align-items-start mb-2">
                    <span style="background: ${isCorrect ? '#10b981' : '#ef4444'}; color: white; padding: 0.25rem 0.75rem; border-radius: 20px; font-size: 0.75rem; font-weight: 600;">
                        Question ${i + 1}
                    </span>
                    <div class="d-flex align-items-center">
                        <i class="bi bi-${isCorrect ? 'check-circle-fill text-success' : 'x-circle-fill text-danger'}" style="font-size: 1.25rem;"></i>
                        <span class="ms-2" style="font-weight: 600; color: ${isCorrect ? '#059669' : '#dc2626'};">
                            ${isCorrect ? 'Correct' : 'Incorrect'}
                        </span>
                    </div>
                </div>
                <div style="font-weight: 600; margin-bottom: 1rem; color: #1e293b;">${question.question}</div>
                <div class="row">
                    <div class="col-md-6">
                        <div style="font-size: 0.875rem; color: #64748b; margin-bottom: 0.5rem;">Your Answer:</div>
                        <div style="padding: 0.75rem; background: rgba(255,255,255,0.7); border-radius: 8px; color: ${isCorrect ? '#059669' : '#dc2626'}; font-weight: 600;">
                            ${userAnswer || 'No answer provided'}
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div style="font-size: 0.875rem; color: #64748b; margin-bottom: 0.5rem;">Correct Answer:</div>
                        <div style="padding: 0.75rem; background: rgba(255,255,255,0.7); border-radius: 8px; color: #059669; font-weight: 600;">
                            ${question.answer}
                        </div>
                    </div>
                </div>
            </div>
        `;
    });
    
    reviewHtml += `
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer" style="background: white; border: none; border-top: 1px solid #e2e8f0;">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal" style="border-radius: 12px;">
                            <i class="bi bi-x-lg me-1"></i>Close
                        </button>
                        <button type="button" class="btn" onclick="retakeQuiz(); bootstrap.Modal.getInstance(document.getElementById('currentReviewModal')).hide();" style="background: linear-gradient(135deg, #6366f1, #8b5cf6); color: white; border-radius: 12px; border: none;">
                            <i class="bi bi-arrow-repeat me-1"></i>Retake Quiz
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Remove existing modal if any
    const existingModal = document.getElementById('currentReviewModal');
    if (existingModal) {
        existingModal.remove();
    }
    
    // Add modal to body
    document.body.insertAdjacentHTML('beforeend', reviewHtml);
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('currentReviewModal'));
    modal.show();
}

function disableAllOptions() {
    // Add disabled class to all option cards
    const optionCards = document.querySelectorAll('.option-card');
    optionCards.forEach(card => {
        card.classList.add('disabled');
        card.onclick = null; // Remove click handler
        card.style.cursor = 'not-allowed';
    });
}

function showWarning(message) {
    // Remove any existing warning
    const existingWarning = document.querySelector('.alert-warning');
    if (existingWarning) {
        existingWarning.remove();
    }
    
    // Create and show warning
    const warningDiv = document.createElement('div');
    warningDiv.className = 'alert alert-warning alert-dismissible fade show mt-3';
    warningDiv.innerHTML = `
        <i class="bi bi-exclamation-triangle-fill me-2"></i>${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    const questionContainer = document.getElementById('questionContainer');
    questionContainer.appendChild(warningDiv);
    
    // Auto-dismiss after 3 seconds
    setTimeout(() => {
        if (warningDiv.parentNode) {
            warningDiv.remove();
        }
    }, 3000);
}

function retakeQuiz() {
    currentQuestionIndex = 0;
    userAnswers = new Array(questions.length).fill(null);
    quizStartTime = new Date(); // Reset start time
    document.getElementById('result').innerHTML = '';
    
    // Re-enable all option cards
    enableAllOptions();
    
    showQuestion(currentQuestionIndex);
}

function getStatusBadge(percentage) {
    if (percentage >= 80) {
        return '<span class="status-badge status-passed"><i class="bi bi-check-circle-fill"></i>Excellent</span>';
    } else if (percentage >= 60) {
        return '<span class="status-badge status-average"><i class="bi bi-exclamation-triangle-fill"></i>Average</span>';
    } else {
        return '<span class="status-badge status-failed"><i class="bi bi-x-circle-fill"></i>Needs Work</span>';
    }
}

function getPerformanceText(percentage) {
    if (percentage >= 90) return 'Outstanding';
    if (percentage >= 80) return 'Excellent';
    if (percentage >= 70) return 'Good';
    if (percentage >= 60) return 'Average';
    return 'Needs Improvement';
}

function enableAllOptions() {
    // Remove disabled class from all option cards
    const optionCards = document.querySelectorAll('.option-card');
    optionCards.forEach(card => {
        card.classList.remove('disabled');
        card.style.cursor = 'pointer';
    });
}

// Initialize the quiz
document.addEventListener('DOMContentLoaded', () => {
    quizStartTime = new Date(); // Set start time when quiz begins
    showQuestion(currentQuestionIndex);
});
