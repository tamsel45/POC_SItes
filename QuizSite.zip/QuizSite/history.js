// Quiz questions for review purposes
const questions = [
    {
        question: "What is Docker primarily used for?",
        options: ["Database management", "Containerization", "Web development", "Network security"],
        answer: "Containerization"
    },
    {
        question: "Which command is used to build a Docker image?",
        options: ["docker run", "docker build", "docker pull", "docker push"],
        answer: "docker build"
    },
    {
        question: "What is a Docker container?",
        options: ["A virtual machine", "A running instance of a Docker image", "A configuration file", "A network protocol"],
        answer: "A running instance of a Docker image"
    },
    {
        question: "Which file defines how to build a Docker image?",
        options: ["docker-compose.yml", "Dockerfile", "docker.json", "container.xml"],
        answer: "Dockerfile"
    },
    {
        question: "What does Kubernetes primarily manage?",
        options: ["Databases", "Containerized applications", "Web servers", "File systems"],
        answer: "Containerized applications"
    },
    {
        question: "Which Kubernetes object is used to run multiple identical pods?",
        options: ["Service", "Deployment", "ConfigMap", "Secret"],
        answer: "Deployment"
    },
    {
        question: "What is the purpose of Docker Compose?",
        options: ["To build single containers", "To orchestrate multi-container applications", "To monitor container performance", "To secure container networks"],
        answer: "To orchestrate multi-container applications"
    },
    {
        question: "Which command lists all running Docker containers?",
        options: ["docker ps", "docker list", "docker show", "docker status"],
        answer: "docker ps"
    },
    {
        question: "What is a Kubernetes pod?",
        options: ["A storage unit", "The smallest deployable unit", "A networking component", "A security policy"],
        answer: "The smallest deployable unit"
    },
    {
        question: "Which Docker command is used to remove a container?",
        options: ["docker delete", "docker rm", "docker remove", "docker erase"],
        answer: "docker rm"
    }
];

function loadQuizHistory() {
    const history = JSON.parse(localStorage.getItem('quizHistory') || '[]');
    const tableBody = document.getElementById('historyTableBody');
    const emptyState = document.getElementById('emptyState');
    
    if (history.length === 0) {
        emptyState.style.display = 'block';
        return;
    }
    
    emptyState.style.display = 'none';
    updateStats(history);
    
    tableBody.innerHTML = '';
    
    history.forEach((quiz, index) => {
        const row = document.createElement('tr');
        const percentage = Math.round((quiz.score / questions.length) * 100);
        const status = getStatusBadge(percentage);
        const duration = quiz.duration || 'N/A';
        
        row.innerHTML = `
            <td><strong>${history.length - index}</strong></td>
            <td>
                <div>
                    <div class="d-flex align-items-center mb-1">
                        <i class="bi bi-calendar-event me-2 text-primary"></i>
                        <span>${quiz.date}</span>
                    </div>
                    <div class="d-flex align-items-center">
                        <i class="bi bi-clock me-2 text-muted"></i>
                        <small class="text-muted">${quiz.time}</small>
                    </div>
                </div>
            </td>
            <td>
                <div class="d-flex align-items-center">
                    <div class="me-2">
                        <span style="font-size: 1.1rem; font-weight: 600;">${quiz.score}</span>
                        <span class="text-muted">/${questions.length}</span>
                    </div>
                </div>
            </td>
            <td>
                <div class="percentage-bar">
                    <div class="percentage-fill" style="width: ${percentage}%; background: linear-gradient(90deg, ${getPercentageGradient(percentage)});"></div>
                </div>
                <div class="d-flex justify-content-between align-items-center mt-1">
                    <strong style="font-size: 0.875rem;">${percentage}%</strong>
                    <div style="font-size: 0.75rem; color: #64748b;">${getPerformanceText(percentage)}</div>
                </div>
            </td>
            <td>${status}</td>
            <td>
                <div class="d-flex align-items-center">
                    <i class="bi bi-stopwatch me-2 text-info"></i>
                    <span>${duration}</span>
                </div>
            </td>
            <td>
                <button class="review-btn" onclick="reviewQuiz(${index})">
                    <i class="bi bi-search"></i>Review
                </button>
            </td>
        `;
        
        tableBody.appendChild(row);
    });
}

function updateStats(history) {
    const statsContainer = document.getElementById('historyStats');
    
    if (history.length === 0) return;
    
    const totalQuizzes = history.length;
    const totalScore = history.reduce((sum, quiz) => sum + quiz.score, 0);
    const averageScore = Math.round((totalScore / (totalQuizzes * questions.length)) * 100);
    const bestScore = Math.max(...history.map(quiz => quiz.score));
    const bestPercentage = Math.round((bestScore / questions.length) * 100);
    const passedQuizzes = history.filter(quiz => (quiz.score / questions.length) * 100 >= 80).length;
    const successRate = Math.round((passedQuizzes / totalQuizzes) * 100);
    
    statsContainer.innerHTML = `
        <div class="col-lg-3 col-md-6 mb-4">
            <div class="stat-card primary" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 20px; padding: 2rem; position: relative; overflow: hidden; box-shadow: 0 20px 40px rgba(102, 126, 234, 0.15);">
                <div style="position: absolute; top: -20px; right: -20px; width: 80px; height: 80px; background: rgba(255,255,255,0.1); border-radius: 50%; opacity: 0.6;"></div>
                <div style="position: absolute; bottom: -30px; left: -30px; width: 100px; height: 100px; background: rgba(255,255,255,0.05); border-radius: 50%;"></div>
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <div style="background: rgba(255,255,255,0.2); width: 60px; height: 60px; border-radius: 16px; display: flex; align-items: center; justify-content: center;">
                        <i class="bi bi-clipboard-data" style="font-size: 1.8rem; color: white;"></i>
                    </div>
                    <div class="text-end">
                        <div style="font-size: 0.8rem; color: rgba(255,255,255,0.8); text-transform: uppercase; letter-spacing: 1px; font-weight: 600;">Total</div>
                    </div>
                </div>
                <div style="color: white; position: relative; z-index: 2;">
                    <div style="font-size: 2.8rem; font-weight: 800; margin-bottom: 0.5rem; text-shadow: 0 2px 8px rgba(0,0,0,0.2);">${totalQuizzes}</div>
                    <div style="font-size: 1rem; opacity: 0.9; font-weight: 500;">Quiz Attempts</div>
                </div>
            </div>
        </div>
        
        <div class="col-lg-3 col-md-6 mb-4">
            <div class="stat-card success" style="background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%); border-radius: 20px; padding: 2rem; position: relative; overflow: hidden; box-shadow: 0 20px 40px rgba(17, 153, 142, 0.15);">
                <div style="position: absolute; top: -20px; right: -20px; width: 80px; height: 80px; background: rgba(255,255,255,0.1); border-radius: 50%; opacity: 0.6;"></div>
                <div style="position: absolute; bottom: -30px; left: -30px; width: 100px; height: 100px; background: rgba(255,255,255,0.05); border-radius: 50%;"></div>
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <div style="background: rgba(255,255,255,0.2); width: 60px; height: 60px; border-radius: 16px; display: flex; align-items: center; justify-content: center;">
                        <i class="bi bi-trophy-fill" style="font-size: 1.8rem; color: white;"></i>
                    </div>
                    <div class="text-end">
                        <div style="font-size: 0.8rem; color: rgba(255,255,255,0.8); text-transform: uppercase; letter-spacing: 1px; font-weight: 600;">Success</div>
                    </div>
                </div>
                <div style="color: white; position: relative; z-index: 2;">
                    <div class="d-flex align-items-baseline gap-2 mb-2">
                        <span style="font-size: 2.8rem; font-weight: 800; text-shadow: 0 2px 8px rgba(0,0,0,0.2);">${passedQuizzes}</span>
                        <span style="font-size: 1.2rem; opacity: 0.8;">/${totalQuizzes}</span>
                    </div>
                    <div style="font-size: 1rem; opacity: 0.9; font-weight: 500;">Passed (${successRate}%)</div>
                </div>
            </div>
        </div>
        
        <div class="col-lg-3 col-md-6 mb-4">
            <div class="stat-card info" style="background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%); border-radius: 20px; padding: 2rem; position: relative; overflow: hidden; box-shadow: 0 20px 40px rgba(59, 130, 246, 0.15);">
                <div style="position: absolute; top: -20px; right: -20px; width: 80px; height: 80px; background: rgba(255,255,255,0.1); border-radius: 50%; opacity: 0.6;"></div>
                <div style="position: absolute; bottom: -30px; left: -30px; width: 100px; height: 100px; background: rgba(255,255,255,0.05); border-radius: 50%;"></div>
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <div style="background: rgba(255,255,255,0.2); width: 60px; height: 60px; border-radius: 16px; display: flex; align-items: center; justify-content: center;">
                        <i class="bi bi-graph-up-arrow" style="font-size: 1.8rem; color: white;"></i>
                    </div>
                    <div class="text-end">
                        <div style="font-size: 0.8rem; color: rgba(255,255,255,0.8); text-transform: uppercase; letter-spacing: 1px; font-weight: 600;">Average</div>
                    </div>
                </div>
                <div style="color: white; position: relative; z-index: 2;">
                    <div class="d-flex align-items-center gap-2 mb-2">
                        <span style="font-size: 2.8rem; font-weight: 800; text-shadow: 0 2px 8px rgba(0,0,0,0.2);">${averageScore}%</span>
                        <div style="width: 40px; height: 6px; background: rgba(255,255,255,0.3); border-radius: 3px; overflow: hidden;">
                            <div style="width: ${averageScore}%; height: 100%; background: rgba(255,255,255,0.8); border-radius: 3px; transition: width 0.8s ease;"></div>
                        </div>
                    </div>
                    <div style="font-size: 1rem; opacity: 0.9; font-weight: 500;">Performance Score</div>
                </div>
            </div>
        </div>
        
        <div class="col-lg-3 col-md-6 mb-4">
            <div class="stat-card warning" style="background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); border-radius: 20px; padding: 2rem; position: relative; overflow: hidden; box-shadow: 0 20px 40px rgba(245, 158, 11, 0.15);">
                <div style="position: absolute; top: -20px; right: -20px; width: 80px; height: 80px; background: rgba(255,255,255,0.1); border-radius: 50%; opacity: 0.6;"></div>
                <div style="position: absolute; bottom: -30px; left: -30px; width: 100px; height: 100px; background: rgba(255,255,255,0.05); border-radius: 50%;"></div>
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <div style="background: rgba(255,255,255,0.2); width: 60px; height: 60px; border-radius: 16px; display: flex; align-items: center; justify-content: center;">
                        <i class="bi bi-star-fill" style="font-size: 1.8rem; color: white;"></i>
                    </div>
                    <div class="text-end">
                        <div style="font-size: 0.8rem; color: rgba(255,255,255,0.8); text-transform: uppercase; letter-spacing: 1px; font-weight: 600;">Best</div>
                    </div>
                </div>
                <div style="color: white; position: relative; z-index: 2;">
                    <div class="d-flex align-items-center gap-2 mb-2">
                        <span style="font-size: 2.8rem; font-weight: 800; text-shadow: 0 2px 8px rgba(0,0,0,0.2);">${bestPercentage}%</span>
                        ${bestPercentage === 100 ? '<i class="bi bi-award-fill" style="font-size: 1.5rem; color: rgba(255,255,255,0.9);"></i>' : ''}
                    </div>
                    <div style="font-size: 1rem; opacity: 0.9; font-weight: 500;">Highest Score</div>
                </div>
            </div>
        </div>
    `;
}

function getStatusBadge(percentage) {
    if (percentage >= 80) {
        return '<span class="status-badge status-passed"><i class="bi bi-check-circle-fill"></i>Excellent</span>';
    } else if (percentage >= 60) {
        return '<span class="status-badge status-average"><i class="bi bi-exclamation-triangle-fill"></i>Average</span>';
    } else {
        return '<span class="status-badge status-failed"><i class="bi bi-x-circle-fill"></i>Needs Work</span>';
    }
}

function getPercentageGradient(percentage) {
    if (percentage >= 80) return '#10b981, #059669';
    if (percentage >= 60) return '#f59e0b, #d97706';
    return '#ef4444, #dc2626';
}

function getPerformanceText(percentage) {
    if (percentage >= 90) return 'Outstanding';
    if (percentage >= 80) return 'Excellent';
    if (percentage >= 70) return 'Good';
    if (percentage >= 60) return 'Average';
    return 'Needs Improvement';
}

function getPercentageColor(percentage) {
    if (percentage >= 80) return 'success';
    if (percentage >= 60) return 'warning';
    return 'danger';
}

function reviewQuiz(index) {
    const history = JSON.parse(localStorage.getItem('quizHistory') || '[]');
    const quiz = history[index];
    const modal = new bootstrap.Modal(document.getElementById('reviewModal'));
    const modalBody = document.getElementById('reviewModalBody');
    const percentage = Math.round((quiz.score / questions.length) * 100);
    
    let reviewHtml = `
        <div class="p-4">
            <div class="row mb-4">
                <div class="col-md-8">
                    <div class="d-flex align-items-center mb-3">
                        <div style="background: linear-gradient(135deg, #6366f1, #8b5cf6); color: white; width: 60px; height: 60px; border-radius: 16px; display: flex; align-items: center; justify-content: center; margin-right: 1rem;">
                            <i class="bi bi-graph-up" style="font-size: 1.5rem;"></i>
                        </div>
                        <div>
                            <h4 class="mb-1">Quiz Performance Analysis</h4>
                            <p class="text-muted mb-0">${quiz.date} at ${quiz.time}</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="text-center">
                        <div style="position: relative; display: inline-block;">
                            <svg width="100" height="100" style="transform: rotate(-90deg);">
                                <circle cx="50" cy="50" r="40" fill="none" stroke="#e2e8f0" stroke-width="8"/>
                                <circle cx="50" cy="50" r="40" fill="none" stroke="${percentage >= 80 ? '#10b981' : percentage >= 60 ? '#f59e0b' : '#ef4444'}" 
                                        stroke-width="8" stroke-dasharray="${2 * Math.PI * 40}" 
                                        stroke-dashoffset="${2 * Math.PI * 40 * (1 - percentage / 100)}"
                                        stroke-linecap="round"/>
                            </svg>
                            <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);">
                                <div style="font-size: 1.25rem; font-weight: 700; color: ${percentage >= 80 ? '#10b981' : percentage >= 60 ? '#f59e0b' : '#ef4444'};">${percentage}%</div>
                            </div>
                        </div>
                        <div class="mt-2">
                            ${getStatusBadge(percentage)}
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="row mb-4">
                <div class="col-md-4">
                    <div style="background: white; padding: 1.5rem; border-radius: 12px; border: 1px solid #e2e8f0;">
                        <div class="d-flex align-items-center justify-content-between">
                            <div>
                                <div style="color: #64748b; font-size: 0.875rem; margin-bottom: 0.25rem;">Score</div>
                                <div style="font-size: 1.5rem; font-weight: 700;">${quiz.score}/${questions.length}</div>
                            </div>
                            <i class="bi bi-clipboard-check" style="font-size: 1.5rem; color: #6366f1;"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div style="background: white; padding: 1.5rem; border-radius: 12px; border: 1px solid #e2e8f0;">
                        <div class="d-flex align-items-center justify-content-between">
                            <div>
                                <div style="color: #64748b; font-size: 0.875rem; margin-bottom: 0.25rem;">Duration</div>
                                <div style="font-size: 1.5rem; font-weight: 700;">${quiz.duration || 'N/A'}</div>
                            </div>
                            <i class="bi bi-stopwatch" style="font-size: 1.5rem; color: #06b6d4;"></i>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div style="background: white; padding: 1.5rem; border-radius: 12px; border: 1px solid #e2e8f0;">
                        <div class="d-flex align-items-center justify-content-between">
                            <div>
                                <div style="color: #64748b; font-size: 0.875rem; margin-bottom: 0.25rem;">Performance</div>
                                <div style="font-size: 1.5rem; font-weight: 700;">${getPerformanceText(percentage)}</div>
                            </div>
                            <i class="bi bi-star" style="font-size: 1.5rem; color: #f59e0b;"></i>
                        </div>
                    </div>
                </div>
            </div>
            
            <div style="background: white; border-radius: 16px; padding: 1.5rem; border: 1px solid #e2e8f0;">
                <h5 class="mb-3 d-flex align-items-center">
                    <i class="bi bi-list-check me-2" style="color: #6366f1;"></i>
                    Detailed Question Review
                </h5>
    `;
    
    questions.forEach((question, i) => {
        const userAnswer = quiz.answers[i];
        const isCorrect = userAnswer === question.answer;
        
        reviewHtml += `
            <div style="background: ${isCorrect ? '#f0fdf4' : '#fef2f2'}; border: 1px solid ${isCorrect ? '#bbf7d0' : '#fecaca'}; border-radius: 12px; padding: 1.25rem; margin-bottom: 1rem;">
                <div class="d-flex justify-content-between align-items-start mb-2">
                    <span style="background: ${isCorrect ? '#10b981' : '#ef4444'}; color: white; padding: 0.25rem 0.75rem; border-radius: 20px; font-size: 0.75rem; font-weight: 600;">
                        Question ${i + 1}
                    </span>
                    <div class="d-flex align-items-center">
                        <i class="bi bi-${isCorrect ? 'check-circle-fill text-success' : 'x-circle-fill text-danger'}" style="font-size: 1.25rem;"></i>
                        <span class="ms-2" style="font-weight: 600; color: ${isCorrect ? '#059669' : '#dc2626'};">
                            ${isCorrect ? 'Correct' : 'Incorrect'}
                        </span>
                    </div>
                </div>
                <div style="font-weight: 600; margin-bottom: 1rem; color: #1e293b;">${question.question}</div>
                <div class="row">
                    <div class="col-md-6">
                        <div style="font-size: 0.875rem; color: #64748b; margin-bottom: 0.5rem;">Your Answer:</div>
                        <div style="padding: 0.75rem; background: rgba(255,255,255,0.7); border-radius: 8px; color: ${isCorrect ? '#059669' : '#dc2626'}; font-weight: 600;">
                            ${userAnswer || 'No answer provided'}
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div style="font-size: 0.875rem; color: #64748b; margin-bottom: 0.5rem;">Correct Answer:</div>
                        <div style="padding: 0.75rem; background: rgba(255,255,255,0.7); border-radius: 8px; color: #059669; font-weight: 600;">
                            ${question.answer}
                        </div>
                    </div>
                </div>
            </div>
        `;
    });
    
    reviewHtml += `
            </div>
        </div>
    `;
    
    modalBody.innerHTML = reviewHtml;
    modal.show();
}

function deleteQuiz(index) {
    if (confirm('Are you sure you want to delete this quiz record?')) {
        const history = JSON.parse(localStorage.getItem('quizHistory') || '[]');
        history.splice(index, 1);
        localStorage.setItem('quizHistory', JSON.stringify(history));
        loadQuizHistory();
    }
}

function clearHistory() {
    if (confirm('Are you sure you want to clear all quiz history? This action cannot be undone.')) {
        localStorage.removeItem('quizHistory');
        loadQuizHistory();
    }
}

// Load history when page loads
document.addEventListener('DOMContentLoaded', () => {
    loadQuizHistory();
});
