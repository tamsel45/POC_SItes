const express = require('express');
const cors = require('cors');
const fs = require('node:fs');
const path = require('node:path');

const app = express();
const port = 3001; // React app runs on 3000 by default

app.use(cors());
app.use(express.json());

const BOOKMARKS_FILE = path.join(__dirname, '../src/data/bookmarks.json');
const TASKS_FILE = path.join(__dirname, '../src/data/tasks.json');

// Ensure data directory exists
const DATA_DIR = path.join(__dirname, '../src/data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Ensure bookmarks.json exists
if (!fs.existsSync(BOOKMARKS_FILE)) {
  fs.writeFileSync(BOOKMARKS_FILE, JSON.stringify({ bookmarks: [] }, null, 2));
}

// Ensure tasks.json exists
if (!fs.existsSync(TASKS_FILE)) {
  fs.writeFileSync(TASKS_FILE, JSON.stringify({ tasks: [] }, null, 2));
}

// Get all bookmarks
app.get('/api/bookmarks', (req, res) => {
  try {
    const data = fs.readFileSync(BOOKMARKS_FILE, 'utf8');
    const bookmarks = JSON.parse(data);
    res.json(bookmarks);
  } catch (error) {
    console.error('Error reading bookmarks:', error);
    res.status(500).json({ error: 'Error reading bookmarks' });
  }
});

// Add a bookmark
app.post('/api/bookmarks', (req, res) => {
  try {
    const data = fs.readFileSync(BOOKMARKS_FILE, 'utf8');
    const { bookmarks } = JSON.parse(data);
    const newBookmark = { ...req.body, id: Date.now() };
    bookmarks.push(newBookmark);
    fs.writeFileSync(BOOKMARKS_FILE, JSON.stringify({ bookmarks }, null, 2));
    res.json(newBookmark);
  } catch (error) {
    console.error('Error adding bookmark:', error);
    res.status(500).json({ error: 'Error adding bookmark' });
  }
});

// Update a bookmark
app.put('/api/bookmarks/:id', (req, res) => {
  try {
    console.log('PUT /api/bookmarks/:id called');
    console.log('ID:', req.params.id);
    console.log('Body:', req.body);
    
    const data = fs.readFileSync(BOOKMARKS_FILE, 'utf8');
    const { bookmarks } = JSON.parse(data);
    const bookmarkId = Number.parseInt(req.params.id, 10);
    const index = bookmarks.findIndex(bookmark => bookmark.id === bookmarkId);
    
    console.log('Found bookmark at index:', index);
    
    if (index === -1) {
      console.error('Bookmark not found:', bookmarkId);
      return res.status(404).json({ error: 'Bookmark not found' });
    }
    
    bookmarks[index] = { ...bookmarks[index], ...req.body, id: bookmarkId };
    console.log('Updated bookmark:', bookmarks[index]);
    
    fs.writeFileSync(BOOKMARKS_FILE, JSON.stringify({ bookmarks }, null, 2));
    console.log('Saved to file successfully');
    
    res.json(bookmarks[index]);
  } catch (error) {
    console.error('Error updating bookmark:', error);
    res.status(500).json({ error: 'Error updating bookmark' });
  }
});

// Import bookmarks (merge with existing)
app.post('/api/bookmarks/import', (req, res) => {
  try {
    console.log('POST /api/bookmarks/import called');
    const data = fs.readFileSync(BOOKMARKS_FILE, 'utf8');
    const { bookmarks } = JSON.parse(data);
    const newBookmarks = req.body.bookmarks || [];
    
    // Merge new bookmarks with existing, avoid duplicates by URL
    const existingUrls = new Set(bookmarks.map(b => b.url));
    const uniqueNewBookmarks = newBookmarks.filter(b => !existingUrls.has(b.url));
    
    // Add IDs to new bookmarks (using integer IDs)
    let counter = 0;
    const bookmarksWithIds = uniqueNewBookmarks.map(b => ({
      ...b,
      id: Date.now() + counter++
    }));
    
    const allBookmarks = [...bookmarks, ...bookmarksWithIds];
    fs.writeFileSync(BOOKMARKS_FILE, JSON.stringify({ bookmarks: allBookmarks }, null, 2));
    
    console.log(`Imported ${bookmarksWithIds.length} new bookmarks`);
    res.json({ success: true, count: bookmarksWithIds.length });
  } catch (error) {
    console.error('Error importing bookmarks:', error);
    res.status(500).json({ error: 'Error importing bookmarks' });
  }
});

// Delete a bookmark
app.delete('/api/bookmarks/:id', (req, res) => {
  try {
    const data = fs.readFileSync(BOOKMARKS_FILE, 'utf8');
    const { bookmarks } = JSON.parse(data);
    const updatedBookmarks = bookmarks.filter(
      bookmark => bookmark.id !== Number.parseInt(req.params.id, 10)
    );
    fs.writeFileSync(BOOKMARKS_FILE, JSON.stringify({ bookmarks: updatedBookmarks }, null, 2));
    res.json({ success: true });
  } catch (error) {
    console.error('Error deleting bookmark:', error);
    res.status(500).json({ error: 'Error deleting bookmark' });
  }
});

// ===== TASK MANAGEMENT ENDPOINTS =====

// Get all tasks
app.get('/api/tasks', (req, res) => {
  try {
    const data = fs.readFileSync(TASKS_FILE, 'utf8');
    const tasks = JSON.parse(data);
    res.json(tasks);
  } catch (error) {
    console.error('Error reading tasks:', error);
    res.status(500).json({ error: 'Error reading tasks' });
  }
});

// Add a task
app.post('/api/tasks', (req, res) => {
  try {
    console.log('Server: Received task:', req.body);
    const data = fs.readFileSync(TASKS_FILE, 'utf8');
    console.log('Server: Current data:', data);
    const { tasks } = JSON.parse(data);
    const newTask = { ...req.body, id: Date.now() };
    console.log('Server: New task with ID:', newTask);
    tasks.push(newTask);
    fs.writeFileSync(TASKS_FILE, JSON.stringify({ tasks }, null, 2));
    console.log('Server: Task saved to file');
    res.json(newTask);
  } catch (error) {
    console.error('Server: Error adding task:', error);
    res.status(500).json({ error: 'Error adding task' });
  }
});

// Update a task
app.put('/api/tasks/:id', (req, res) => {
  try {
    const data = fs.readFileSync(TASKS_FILE, 'utf8');
    const { tasks } = JSON.parse(data);
    const taskId = Number.parseInt(req.params.id, 10);
    const index = tasks.findIndex(task => task.id === taskId);
    
    if (index === -1) {
      return res.status(404).json({ error: 'Task not found' });
    }
    
    tasks[index] = { ...tasks[index], ...req.body, id: taskId };
    fs.writeFileSync(TASKS_FILE, JSON.stringify({ tasks }, null, 2));
    res.json(tasks[index]);
  } catch (error) {
    console.error('Error updating task:', error);
    res.status(500).json({ error: 'Error updating task' });
  }
});

// Delete a task
app.delete('/api/tasks/:id', (req, res) => {
  try {
    const data = fs.readFileSync(TASKS_FILE, 'utf8');
    const { tasks } = JSON.parse(data);
    const updatedTasks = tasks.filter(
      task => task.id !== Number.parseInt(req.params.id, 10)
    );
    fs.writeFileSync(TASKS_FILE, JSON.stringify({ tasks: updatedTasks }, null, 2));
    res.json({ success: true });
  } catch (error) {
    console.error('Error deleting task:', error);
    res.status(500).json({ error: 'Error deleting task' });
  }
});

// Carry forward incomplete tasks
app.post('/api/tasks/carry-forward', (req, res) => {
  try {
    const data = fs.readFileSync(TASKS_FILE, 'utf8');
    const { tasks } = JSON.parse(data);
    const today = new Date().toISOString().split('T')[0];
    
    // Update all pending/in-progress tasks to carry-forward
    const updatedTasks = tasks.map(task => {
      if ((task.status === 'pending' || task.status === 'in-progress') && 
          task.dueDate && task.dueDate < today) {
        return { ...task, status: 'carry-forward' };
      }
      return task;
    });
    
    fs.writeFileSync(TASKS_FILE, JSON.stringify({ tasks: updatedTasks }, null, 2));
    res.json({ success: true, updated: updatedTasks.length - tasks.length });
  } catch (error) {
    console.error('Error carrying forward tasks:', error);
    res.status(500).json({ error: 'Error carrying forward tasks' });
  }
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});