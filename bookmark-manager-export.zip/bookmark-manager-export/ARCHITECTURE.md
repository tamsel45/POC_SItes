# Bookmark Manager - Architecture & Development Documentation

## Table of Contents
1. [Project Overview](#project-overview)
2. [Technology Stack](#technology-stack)
3. [Architecture Overview](#architecture-overview)
4. [Frontend Architecture](#frontend-architecture)
5. [Backend Architecture](#backend-architecture)
6. [Component Structure](#component-structure)
7. [State Management](#state-management)
8. [Data Flow](#data-flow)
9. [API Design](#api-design)
10. [UI/UX Design Patterns](#uiux-design-patterns)
11. [Development Journey](#development-journey)
12. [Feature Suggestions](#feature-suggestions)

---

## Project Overview

**Bookmark Manager** is a full-stack web application built with React and Express.js that allows users to organize, search, and manage their bookmarks efficiently. It supports browser bookmark imports, local file path associations, and advanced features like bulk category updates.

### Key Features
- ✅ Create, Read, Update, Delete (CRUD) bookmarks
- ✅ Browser bookmark import (HTML/JSON)
- ✅ Category-based organization
- ✅ Search functionality
- ✅ Multi-select bulk operations
- ✅ Local file path integration
- ✅ Dark mode support
- ✅ Custom notification system
- ✅ Responsive design

---

## Technology Stack

### Frontend
- **React 19.2.0** - UI library with hooks
- **TypeScript 4.9.5** - Type safety
- **Tailwind CSS 3.3.5** - Utility-first CSS framework
- **Framer Motion 12.23.24** - Animation library
- **Lucide React 0.553.0** - Icon library
- **React Scripts 5.0.1** - Build tooling

### Backend
- **Express.js 5.1.0** - Web server framework
- **Node.js** - Runtime environment
- **File System (fs)** - JSON-based data persistence

### Development Tools
- **PostCSS** - CSS processing
- **Autoprefixer** - CSS vendor prefixing
- **ESLint** - Code linting (built into React Scripts)

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                     Browser (Client)                        │
│  ┌───────────────────────────────────────────────────────┐ │
│  │  React Application (Port 3000)                        │ │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐           │ │
│  │  │   UI     │  │  State   │  │ Services │           │ │
│  │  │Components│◄─┤Management├─►│  Layer   │           │ │
│  │  └──────────┘  └──────────┘  └─────┬────┘           │ │
│  └────────────────────────────────────┼────────────────┘ │
└────────────────────────────────────────┼──────────────────┘
                                         │
                                    HTTP/REST
                                         │
┌────────────────────────────────────────┼──────────────────┐
│                  Server (Backend)      ▼                  │
│  ┌───────────────────────────────────────────────────────┐│
│  │  Express.js Server (Port 3001)                        ││
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐           ││
│  │  │   API    │  │ Business │  │   Data   │           ││
│  │  │Endpoints │─►│  Logic   │─►│  Layer   │           ││
│  │  └──────────┘  └──────────┘  └─────┬────┘           ││
│  └────────────────────────────────────┼────────────────┘│
└────────────────────────────────────────┼──────────────────┘
                                         │
                                    File I/O
                                         │
                                         ▼
                              ┌──────────────────┐
                              │ bookmarks.json   │
                              │  (Data Store)    │
                              └──────────────────┘
```

---

## Frontend Architecture

### Project Structure
```
src/
├── components/              # React components
│   ├── AddBookmarkForm.tsx  # Drawer for adding bookmarks
│   ├── BookmarkGrid.tsx     # Display bookmarks in grid
│   └── FilePathModal.tsx    # Modal for local file paths
├── contexts/                # React Context providers
│   └── NotificationContext.tsx  # Global notification system
├── services/                # API communication layer
│   └── BookmarkService.ts   # Fetch API wrapper
├── utils/                   # Utility functions
│   ├── bookmarkParser.ts    # Parse HTML/JSON bookmarks
│   └── fileSystem.ts        # File system helpers
├── types.ts                 # TypeScript type definitions
├── App.tsx                  # Main application component
├── index.tsx                # Application entry point
└── index.css                # Global styles + Tailwind
```

### Component Hierarchy
```
App (Root)
├── NotificationProvider (Context)
│   └── App Component
│       ├── Header
│       │   ├── Title + Icon
│       │   ├── Import Button
│       │   ├── Add Bookmark Button
│       │   └── Dark Mode Toggle
│       ├── Search & Filter Bar
│       │   ├── Search Input
│       │   └── Category Dropdown
│       ├── AddBookmarkForm (Drawer)
│       │   ├── Form Fields (Title, URL, Category, LocalPath)
│       │   └── Action Buttons (Cancel, Save)
│       └── BookmarkGrid
│           ├── Bulk Update Panel (Conditional)
│           ├── Category Sections
│           │   └── Bookmark Cards
│           │       ├── Checkbox (Multi-select)
│           │       ├── Title + Icon
│           │       ├── Action Buttons (Copy, Edit, Delete)
│           │       └── Open Local File Button
│           └── FilePathModal (Conditional)
```

---

## Backend Architecture

### Server Structure
```
server/
└── server.js               # Express server with routes
```

### API Endpoints
```javascript
GET    /api/bookmarks           // Get all bookmarks
POST   /api/bookmarks           // Create new bookmark
PUT    /api/bookmarks/:id       // Update bookmark by ID
DELETE /api/bookmarks/:id       // Delete bookmark by ID
POST   /api/bookmarks/import    // Import bookmarks (merge)
```

### Data Model
```typescript
interface Bookmark {
  id?: number;              // Unix timestamp + random (unique)
  title: string;            // Bookmark title
  url: string;              // Bookmark URL
  category: string;         // Category (lowercase)
  localPath?: string;       // Optional local file path
}
```

### Data Storage
- **File:** `src/data/bookmarks.json`
- **Format:** JSON with array of bookmarks
- **Persistence:** Synchronous file writes
- **ID Generation:** `Date.now()` for unique IDs

---

## Component Structure

### 1. App.tsx (Main Component)
**Responsibilities:**
- Application state management
- Route coordination
- Data fetching and CRUD operations
- Dark mode state
- Search and filter logic

**Key State:**
```typescript
const [bookmarks, setBookmarks] = useState<Bookmark[]>([]);
const [searchTerm, setSearchTerm] = useState('');
const [isDarkMode, setIsDarkMode] = useState(false);
const [selectedCategory, setSelectedCategory] = useState<string>('all');
const [isImporting, setIsImporting] = useState(false);
const [isAddDrawerOpen, setIsAddDrawerOpen] = useState(false);
```

**Key Functions:**
- `addBookmark()` - Create new bookmark
- `updateBookmark()` - Update existing bookmark
- `deleteBookmark()` - Delete with confirmation
- `handleFileImport()` - Import browser bookmarks

---

### 2. AddBookmarkForm.tsx (Drawer Component)
**Responsibilities:**
- Form for adding new bookmarks
- Slide-over drawer UI pattern
- Form validation
- Notification on success/error

**Props:**
```typescript
interface AddBookmarkFormProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (bookmark: Bookmark) => Promise<void> | void;
}
```

**UI Pattern:** Slide-over drawer with:
- Branded header (blue-900 background)
- Scrollable form content
- Sticky footer with action buttons
- Overlay backdrop

---

### 3. BookmarkGrid.tsx (Display Component)
**Responsibilities:**
- Display bookmarks in grid layout
- Grouped by category
- Edit mode inline
- Multi-select functionality
- Bulk category updates
- Copy link to clipboard

**Key State:**
```typescript
const [editingId, setEditingId] = useState<number | null>(null);
const [editFormData, setEditFormData] = useState<Bookmark | null>(null);
const [copiedId, setCopiedId] = useState<number | null>(null);
const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
const [showBulkUpdate, setShowBulkUpdate] = useState(false);
const [bulkCategory, setBulkCategory] = useState('');
const [filePathToShow, setFilePathToShow] = useState<string | null>(null);
```

**Features:**
- Hover effects (bg-blue-900 in dark, bg-blue-50 in light)
- Inline editing
- Checkbox selection
- Floating bulk update panel
- File path modal trigger

---

### 4. FilePathModal.tsx (Modal Component)
**Responsibilities:**
- Display local file path
- Copy path to clipboard
- Instructions for opening files
- Professional modal UI

**Features:**
- Copy button with visual feedback
- Step-by-step instructions
- Dark mode support
- Click outside to close

---

### 5. NotificationContext.tsx (Global State)
**Responsibilities:**
- Toast notifications
- Confirmation dialogs
- Global notification state

**API:**
```typescript
const { showNotification, showConfirm } = useNotification();

// Show notification
showNotification('success', 'Title', 'Optional message');

// Show confirmation dialog
const confirmed = await showConfirm({
  title: 'Delete Bookmark',
  message: 'Are you sure?',
  confirmText: 'Delete',
  cancelText: 'Cancel',
  type: 'danger'  // 'danger' | 'warning' | 'info'
});
```

**Notification Types:**
- `success` - Green with CheckCircle icon
- `error` - Red with XCircle icon
- `warning` - Yellow with AlertCircle icon
- `info` - Blue with Info icon

---

## State Management

### Local Component State
- **useState** for component-specific state
- **useEffect** for side effects (data fetching)

### Global State (Context API)
- **NotificationContext** for notifications and confirmations

### State Flow
```
User Action
    ↓
Component Handler
    ↓
Service Layer (BookmarkService)
    ↓
HTTP Request → Backend API
    ↓
Backend Processing
    ↓
File System Write (bookmarks.json)
    ↓
HTTP Response
    ↓
Service Layer
    ↓
Component State Update
    ↓
UI Re-render
    ↓
Notification (if needed)
```

---

## Data Flow

### Read Operations (GET)
```
App.tsx (useEffect on mount)
    ↓
BookmarkService.getAllBookmarks()
    ↓
fetch('/api/bookmarks')
    ↓
Express: GET /api/bookmarks
    ↓
fs.readFileSync('bookmarks.json')
    ↓
Parse JSON → Return data
    ↓
setBookmarks(data)
    ↓
BookmarkGrid renders
```

### Create Operations (POST)
```
AddBookmarkForm submit
    ↓
App.addBookmark(bookmark)
    ↓
BookmarkService.addBookmark(bookmark)
    ↓
fetch('/api/bookmarks', POST)
    ↓
Express: POST /api/bookmarks
    ↓
Generate ID (Date.now())
    ↓
Read existing bookmarks
    ↓
Append new bookmark
    ↓
fs.writeFileSync('bookmarks.json')
    ↓
Return new bookmark
    ↓
setBookmarks([...bookmarks, newBookmark])
    ↓
showNotification('success')
```

### Update Operations (PUT)
```
BookmarkGrid edit save
    ↓
App.updateBookmark(id, bookmark)
    ↓
BookmarkService.updateBookmark(id, bookmark)
    ↓
fetch('/api/bookmarks/:id', PUT)
    ↓
Express: PUT /api/bookmarks/:id
    ↓
Read bookmarks
    ↓
Find bookmark by ID
    ↓
Update fields
    ↓
fs.writeFileSync('bookmarks.json')
    ↓
Return updated bookmark
    ↓
setBookmarks(bookmarks.map(...))
    ↓
showNotification('success')
```

### Delete Operations (DELETE)
```
BookmarkGrid delete button
    ↓
App.deleteBookmark(id)
    ↓
showConfirm() → User confirms
    ↓
BookmarkService.deleteBookmark(id)
    ↓
fetch('/api/bookmarks/:id', DELETE)
    ↓
Express: DELETE /api/bookmarks/:id
    ↓
Read bookmarks
    ↓
Filter out bookmark by ID
    ↓
fs.writeFileSync('bookmarks.json')
    ↓
Return success
    ↓
setBookmarks(bookmarks.filter(...))
    ↓
showNotification('success')
```

---

## API Design

### RESTful Principles
- Uses standard HTTP methods (GET, POST, PUT, DELETE)
- Resource-based URLs (`/api/bookmarks`)
- JSON request/response format
- HTTP status codes for responses

### Error Handling
```javascript
// Backend
if (!bookmark) {
  return res.status(404).json({ error: 'Bookmark not found' });
}

// Frontend
if (!response.ok) {
  throw new Error(`HTTP ${response.status}: ${response.statusText}`);
}
```

### CORS Configuration
```javascript
app.use(cors({
  origin: 'http://localhost:3000',
  credentials: true
}));
```

---

## UI/UX Design Patterns

### Color Scheme
- **Primary:** Blue (blue-600, blue-900)
- **Success:** Green (green-600)
- **Danger:** Red (red-600)
- **Warning:** Yellow (yellow-500)
- **Neutral:** Gray scale

### Dark Mode
- Implemented with Tailwind's `dark:` prefix
- Toggled via class on root element
- Persists across page (could be enhanced with localStorage)

### Design Patterns Used

#### 1. Slide-over Drawer (AddBookmarkForm)
- Fixed positioning
- Overlay backdrop
- Slide-in animation from right
- Sticky header and footer

#### 2. Modal Dialog (FilePathModal, Confirmation)
- Centered positioning
- Overlay backdrop
- Scale and fade animation
- Click outside to close

#### 3. Toast Notifications
- Top-right stacking
- Auto-dismiss (5 seconds)
- Manual close button
- Icon + message format

#### 4. Grid Layout (BookmarkGrid)
- Responsive columns (1-5 based on screen size)
- Card-based design
- Hover effects
- Grouped by category

#### 5. Inline Editing
- Edit mode toggle
- Form appears in place
- Cancel/Save actions
- Visual feedback

#### 6. Multi-select Pattern
- Checkboxes on cards
- Floating action panel
- Bulk operations
- Select All per category

---

## Development Journey

### Phase 1: Initial Setup
1. Created React app with TypeScript
2. Set up Tailwind CSS configuration
3. Fixed CRACO conflicts (removed, used PostCSS directly)
4. Implemented basic component structure

### Phase 2: Backend Integration
1. Created Express.js server (port 3001)
2. Implemented CRUD API endpoints
3. File-based JSON storage
4. Fixed CORS issues

### Phase 3: Core Features
1. Add/Edit/Delete bookmarks
2. Category organization
3. Search functionality
4. Browser bookmark import (HTML/JSON parsing)

### Phase 4: UI/UX Enhancements
1. **Design Evolution:**
   - Started with glossy gradient theme
   - Changed to plain colors with hover effects
   - Hover color: bg-blue-900 (dark), bg-blue-50 (light)

2. **Layout Changes:**
   - Full browser width (removed max-width)
   - Reduced card sizes (padding 6→4)
   - Title truncation to single line
   - Removed category span from cards

3. **Color Updates:**
   - Changed Add button from orange-700 to blue-900
   - Unified color scheme throughout

### Phase 5: Advanced Features
1. Multi-select with checkboxes
2. Bulk category updates
3. Fixed duplicate ID issues (decimal → integer)
4. Local file path integration

### Phase 6: Notification System
1. Replaced all `alert()` with custom notifications
2. Created NotificationContext
3. Toast notifications with icons
4. Confirmation dialogs with custom styling

### Phase 7: Icon System
1. Added icons to all buttons
2. Icons for form labels
3. Category section icons
4. Notification type icons

### Phase 8: File Path Modal
1. Created custom modal for local file paths
2. Copy-to-clipboard functionality
3. Step-by-step instructions
4. Professional UI design

---

## Feature Suggestions

### 🚀 High Priority Features

#### 1. **Tag System** (Instead of single category)
```typescript
interface Bookmark {
  tags: string[];  // Multiple tags per bookmark
  // Add tag colors for visual organization
}
```
**Benefits:**
- More flexible organization
- Bookmarks can belong to multiple groups
- Filter by multiple tags

**Implementation:**
- Tag input with autocomplete
- Tag cloud view
- Multi-tag filtering

---

#### 2. **Browser Extension**
Create a Chrome/Firefox extension for quick bookmark saving.

**Features:**
- Right-click → "Save to Bookmark Manager"
- Current page auto-fill
- Automatic category suggestion
- Quick access popup

---

#### 3. **Cloud Sync / Database Integration**
Replace JSON file with proper database.

**Options:**
- **MongoDB** - Document-based, flexible schema
- **PostgreSQL** - Relational, strong typing
- **Firebase** - Real-time sync, user authentication

**Benefits:**
- User accounts
- Cross-device sync
- Better performance
- Concurrent access support

---

#### 4. **Full-Text Search with Highlighting**
```typescript
// Search in title, URL, tags, notes
// Highlight matching text in results
```

**Implementation:**
- Elasticsearch or Algolia integration
- Fuzzy matching
- Search history
- Saved searches

---

#### 5. **Bookmark Collections / Folders**
Nested folder structure for better organization.

```typescript
interface Collection {
  id: number;
  name: string;
  parentId?: number;
  bookmarks: Bookmark[];
}
```

**UI:**
- Tree view sidebar
- Drag-and-drop between folders
- Breadcrumb navigation

---

### 💡 Medium Priority Features

#### 6. **Screenshot/Thumbnail Generation**
Auto-generate preview images for bookmarks.

**Implementation:**
- Use API service (e.g., ScreenshotAPI, Puppeteer)
- Cache thumbnails
- Lazy loading

---

#### 7. **Import from Popular Services**
- Pocket
- Instapaper
- Raindrop.io
- Browser sync (Chrome, Firefox, Edge)

---

#### 8. **Export Options**
- HTML (browser-compatible format)
- CSV
- PDF report
- Markdown

---

#### 9. **Keyboard Shortcuts**
```
Ctrl/Cmd + K  → Quick search
Ctrl/Cmd + N  → Add bookmark
Ctrl/Cmd + E  → Edit selected
Ctrl/Cmd + D  → Delete selected
/             → Focus search
Esc           → Close modals
```

---

#### 10. **Bookmark Notes & Descriptions**
```typescript
interface Bookmark {
  notes?: string;       // Personal notes
  description?: string; // Auto-fetched meta description
}
```

---

#### 11. **Link Health Checking**
Periodically check if URLs are still valid.

**Features:**
- Background job to check links
- Mark broken links
- Suggest updates
- Archive old bookmarks

---

#### 12. **Smart Suggestions**
- Suggest categories based on URL/title
- Duplicate detection
- Related bookmarks
- Popular bookmarks in category

---

### 🎨 UI/UX Enhancements

#### 13. **List vs Grid View Toggle**
Switch between compact list and card grid.

---

#### 14. **Custom Themes**
- Multiple color schemes
- User-defined colors
- Theme marketplace

---

#### 15. **Drag-and-Drop**
- Reorder bookmarks
- Move between categories
- Bulk operations

---

#### 16. **Advanced Filters**
- Date added
- Last modified
- Most visited (if tracking)
- Has local file path
- Tag combinations

---

#### 17. **Quick Actions Menu**
Right-click context menu on bookmarks:
- Open in new tab
- Copy URL
- Edit
- Delete
- Move to category
- Add tags

---

### 🔧 Technical Improvements

#### 18. **Performance Optimizations**
- Virtual scrolling for large lists (react-window)
- Pagination or infinite scroll
- Lazy loading images
- Code splitting

---

#### 19. **Testing**
```typescript
// Unit tests (Jest)
// Integration tests
// E2E tests (Cypress/Playwright)
```

---

#### 20. **PWA (Progressive Web App)**
- Offline support
- Install as desktop app
- Service worker caching
- Push notifications

---

#### 21. **Analytics Dashboard**
Track usage patterns:
- Most visited bookmarks
- Category distribution
- Growth over time
- Search patterns

---

#### 22. **API Authentication**
Add JWT-based authentication:
```typescript
// Login/Register
// JWT tokens
// Protected routes
// User-specific data
```

---

#### 23. **Rate Limiting**
Prevent API abuse:
```javascript
const rateLimit = require('express-rate-limit');

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100 // limit each IP to 100 requests per windowMs
});

app.use('/api/', limiter);
```

---

#### 24. **Logging & Monitoring**
- Winston for logging
- Error tracking (Sentry)
- Performance monitoring
- User activity logs

---

### 🔐 Security Enhancements

#### 25. **Input Validation & Sanitization**
```typescript
// Validate URLs
// Sanitize HTML
// XSS prevention
// SQL injection protection (if using DB)
```

---

#### 26. **Encrypted Storage**
Encrypt sensitive data (if storing passwords, API keys).

---

#### 27. **HTTPS Support**
Production deployment with SSL certificates.

---

### 🌍 Collaboration Features

#### 28. **Shared Collections**
- Share bookmark collections with others
- Public/private collections
- Collaborative editing
- Comments on bookmarks

---

#### 29. **Social Features**
- Follow other users
- Discover popular bookmarks
- Bookmark recommendations
- Activity feed

---

### 📱 Mobile Experience

#### 30. **Mobile App**
React Native version:
- Native iOS/Android apps
- Share sheet integration
- Widget support
- Offline mode

---

### 🤖 AI/ML Features

#### 31. **AI-Powered Organization**
- Auto-categorization using NLP
- Smart tagging
- Content summarization
- Duplicate detection

---

#### 32. **Reading Time Estimation**
Estimate time to read linked content.

---

#### 33. **Content Archiving**
Save full page content (like Wayback Machine):
- Archive page HTML
- PDF generation
- Search archived content

---

## Recommended Implementation Order

### Short-term (1-2 weeks)
1. ✅ Tag system (replaces/supplements categories)
2. ✅ Keyboard shortcuts
3. ✅ List/Grid view toggle
4. ✅ Advanced filters

### Medium-term (1-2 months)
1. ✅ Database integration (MongoDB/PostgreSQL)
2. ✅ User authentication
3. ✅ Cloud sync
4. ✅ Browser extension
5. ✅ PWA support

### Long-term (3-6 months)
1. ✅ Screenshot/thumbnail generation
2. ✅ Link health checking
3. ✅ AI-powered features
4. ✅ Mobile app
5. ✅ Collaboration features

---

## Conclusion

This Bookmark Manager is a well-architected, modern web application with a solid foundation. The separation of concerns, component-based architecture, and use of modern React patterns make it easy to extend and maintain.

The notification system, custom modals, and attention to UX details show a mature approach to frontend development. The file-based backend is simple but functional, perfect for a single-user application.

**Next Steps:**
1. Choose 2-3 features from the suggestions above
2. Plan the implementation (database first if going multi-user)
3. Add tests before adding complexity
4. Consider deployment strategy (Vercel, Netlify, AWS, etc.)

**Strengths:**
- Clean code structure
- Modern tech stack
- Good UX patterns
- Comprehensive icon system
- Professional notifications

**Areas for Growth:**
- Database integration
- User authentication
- Testing coverage
- Performance optimization for large datasets
- Mobile responsiveness
- Deployment pipeline

---

## Questions or Contributions?

Feel free to extend this document as the project evolves. Keep it up to date with architectural changes and new features.

**Author:** AI Assistant (Claude)  
**Last Updated:** November 10, 2025  
**Version:** 1.0.0
