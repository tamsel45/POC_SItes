const fs = require('fs');
const path = require('path');

const bookmarksPath = path.join(__dirname, 'src', 'data', 'bookmarks.json');
const data = JSON.parse(fs.readFileSync(bookmarksPath, 'utf8'));

console.log('Fixing decimal IDs...');
let fixedCount = 0;
let counter = 0;

// Convert all decimal IDs to integers
data.bookmarks = data.bookmarks.map(bookmark => {
  if (!Number.isInteger(bookmark.id)) {
    const newId = Math.floor(bookmark.id);
    console.log(`Fixed ID: ${bookmark.id} -> ${newId} (${bookmark.title})`);
    fixedCount++;
    return { ...bookmark, id: newId };
  }
  return bookmark;
});

// Check for and fix any duplicate IDs that may have resulted from flooring
const idCounts = {};
data.bookmarks.forEach(b => {
  idCounts[b.id] = (idCounts[b.id] || 0) + 1;
});

const duplicateIds = Object.keys(idCounts).filter(id => idCounts[id] > 1).map(Number);

if (duplicateIds.length > 0) {
  console.log(`\nFound ${duplicateIds.length} duplicate IDs after conversion, fixing...`);
  
  data.bookmarks = data.bookmarks.map(bookmark => {
    if (duplicateIds.includes(bookmark.id)) {
      const baseId = Date.now() + counter++;
      console.log(`Reassigning duplicate ID: ${bookmark.id} -> ${baseId} (${bookmark.title})`);
      return { ...bookmark, id: baseId };
    }
    return bookmark;
  });
}

fs.writeFileSync(bookmarksPath, JSON.stringify(data, null, 2));
console.log(`\nFixed ${fixedCount} decimal IDs`);
console.log('All IDs are now integers!');
