import { useState, useEffect } from 'react';
import { Plus, Filter, Mail, ArrowRight, AlertCircle, FileText } from 'lucide-react';
import { AnimatePresence } from 'framer-motion';
import { DndContext, DragEndEvent, closestCorners, PointerSensor, useSensor, useSensors } from '@dnd-kit/core';
import { SortableContext, verticalListSortingStrategy } from '@dnd-kit/sortable';
import * as XLSX from 'xlsx';
import { Task, TaskPriority, TaskStatus } from '../types';
import { TaskService } from '../services/TaskService';
import { useNotification } from '../contexts/NotificationContext';
import AddTaskForm from './AddTaskForm';
import TaskCard from './TaskCard';
import DroppableColumn from './DroppableColumn';

interface TaskManagerProps {
  isDarkMode: boolean;
  theme: 'blue' | 'purple' | 'green' | 'orange';
}

const TaskManager = ({ isDarkMode, theme }: TaskManagerProps) => {
  const { showNotification, showConfirm } = useNotification();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [isAddDrawerOpen, setIsAddDrawerOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [filterPriority, setFilterPriority] = useState<TaskPriority | 'all'>('all');
  const [filterAssignee, setFilterAssignee] = useState<string>('all');
  const [filterPeriod, setFilterPeriod] = useState<string>('all');
  const [showSummaryModal, setShowSummaryModal] = useState(false);
  const today = new Date().toISOString().split('T')[0];

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    })
  );

  const themeColors = {
    blue: 'bg-blue-600 hover:bg-blue-700',
    purple: 'bg-purple-600 hover:bg-purple-700',
    green: 'bg-green-600 hover:bg-green-700',
    orange: 'bg-orange-600 hover:bg-orange-700',
  };

  useEffect(() => {
    loadTasks();
  }, []);

  const loadTasks = async () => {
    const loadedTasks = await TaskService.getAllTasks();
    setTasks(loadedTasks);
  };

  const addTask = async (task: Omit<Task, 'id'>) => {
    console.log('TaskManager: Adding task:', task);
    const newTask = await TaskService.addTask(task);
    console.log('TaskManager: Received new task:', newTask);
    if (newTask) {
      setTasks([...tasks, newTask]);
      showNotification('success', 'Task Added', 'New task has been added successfully!');
    } else {
      console.error('TaskManager: Failed to add task - newTask is null');
      showNotification('error', 'Task Not Added', 'Failed to add task. Please check the console.');
    }
  };

  const updateTask = async (id: number, updatedTask: Task) => {
    const result = await TaskService.updateTask(id, updatedTask);
    if (result) {
      setTasks(tasks.map(t => t.id === id ? result : t));
      showNotification('success', 'Task Updated', 'Task has been updated successfully!');
    }
  };

  const deleteTask = async (id: number) => {
    const confirmed = await showConfirm({
      title: 'Delete Task',
      message: 'Are you sure you want to delete this task? This action cannot be undone.',
      confirmText: 'Delete',
      cancelText: 'Cancel',
      type: 'danger'
    });
    
    if (confirmed) {
      const success = await TaskService.deleteTask(id);
      if (success) {
        setTasks(tasks.filter(t => t.id !== id));
        showNotification('success', 'Task Deleted', 'Task has been deleted successfully!');
      }
    }
  };

  const handleStatusChange = async (task: Task, newStatus: TaskStatus) => {
    const updatedTask = { 
      ...task, 
      status: newStatus,
      completedDate: newStatus === 'completed' ? today : undefined
    };
    await updateTask(task.id!, updatedTask);
  };

  const handleEdit = (task: Task) => {
    setEditingTask(task);
    setIsAddDrawerOpen(true);
  };

  const generatePeriodSummary = (period: string) => {
    const periodTasks = getTasksForPeriod(period);
    const completed = periodTasks.filter(t => t.status === 'completed');
    const incomplete = periodTasks.filter(t => t.status !== 'completed');
    
    const periodNames: { [key: string]: string } = {
      q1: 'Q1 (Jan-Mar)',
      q2: 'Q2 (Apr-Jun)',
      q3: 'Q3 (Jul-Sep)',
      q4: 'Q4 (Oct-Dec)',
      h1: 'H1 (Jan-Jun)',
      h2: 'H2 (Jul-Dec)',
      year: new Date().getFullYear().toString()
    };
    
    // Create Excel workbook
    const wb = XLSX.utils.book_new();
    
    // Summary sheet
    const summaryData = [
      ['Task Summary Report', ''],
      ['Period', periodNames[period] || period],
      ['Generated', new Date().toLocaleDateString()],
      ['', ''],
      ['Overview', ''],
      ['Total Tasks', periodTasks.length],
      ['Completed', completed.length],
      ['Completion Rate', periodTasks.length > 0 ? `${Math.round((completed.length / periodTasks.length) * 100)}%` : '0%'],
      ['Incomplete', incomplete.length],
      ['', ''],
      ['By Priority', ''],
      ['Urgent', periodTasks.filter(t => t.priority === 'urgent').length],
      ['High', periodTasks.filter(t => t.priority === 'high').length],
      ['Medium', periodTasks.filter(t => t.priority === 'medium').length],
      ['Low', periodTasks.filter(t => t.priority === 'low').length],
      ['', ''],
      ['By Status', ''],
      ['Completed', completed.length],
      ['In Progress', periodTasks.filter(t => t.status === 'in-progress').length],
      ['Pending', periodTasks.filter(t => t.status === 'pending').length],
      ['Carry Forward', periodTasks.filter(t => t.status === 'carry-forward').length],
    ];
    const summaryWs = XLSX.utils.aoa_to_sheet(summaryData);
    XLSX.utils.book_append_sheet(wb, summaryWs, 'Summary');
    
    // Completed tasks sheet
    const completedData: (string | number)[][] = [
      ['#', 'Title', 'Description', 'Priority', 'Assigned To', 'Created Date', 'Completed Date', 'Notes']
    ];
    for (const [i, task] of completed.entries()) {
      completedData.push([
        i + 1,
        task.title,
        task.description || '',
        task.priority.toUpperCase(),
        task.assignedTo || '',
        task.createdDate ? new Date(task.createdDate).toLocaleDateString() : '',
        task.completedDate ? new Date(task.completedDate).toLocaleDateString() : '',
        task.notes || ''
      ]);
    }
    const completedWs = XLSX.utils.aoa_to_sheet(completedData);
    XLSX.utils.book_append_sheet(wb, completedWs, 'Completed Tasks');
    
    // Incomplete tasks sheet
    const incompleteData: (string | number)[][] = [
      ['#', 'Title', 'Description', 'Priority', 'Status', 'Assigned To', 'Due Date', 'Created Date', 'Remind Manager', 'Notes']
    ];
    for (const [i, task] of incomplete.entries()) {
      incompleteData.push([
        i + 1,
        task.title,
        task.description || '',
        task.priority.toUpperCase(),
        task.status.toUpperCase(),
        task.assignedTo || '',
        task.dueDate ? new Date(task.dueDate).toLocaleDateString() : '',
        task.createdDate ? new Date(task.createdDate).toLocaleDateString() : '',
        task.remindManager ? 'Yes' : 'No',
        task.notes || ''
      ]);
    }
    const incompleteWs = XLSX.utils.aoa_to_sheet(incompleteData);
    XLSX.utils.book_append_sheet(wb, incompleteWs, 'Incomplete Tasks');
    
    // Download the file
    const fileName = `task-summary-${period}-${new Date().toISOString().split('T')[0]}.xlsx`;
    XLSX.writeFile(wb, fileName);
    showNotification('success', 'Excel Exported!', `${periodNames[period]} summary exported as ${fileName}`);
  };

  const generateEmailSummary = async () => {
    const completedTasks = tasks.filter(t => t.status === 'completed' && t.assignedTo === 'me');
    const incompleteTasks = tasks.filter(t => 
      (t.status === 'pending' || t.status === 'in-progress' || t.status === 'carry-forward') && 
      t.assignedTo === 'me'
    );
    const remindManagerTasks = tasks.filter(t => t.remindManager && t.status !== 'completed');
    const delegatedTasks = tasks.filter(t => t.assignedTo !== 'me' && t.assignedTo);

    let emailBody = `Daily Task Summary - ${new Date().toLocaleDateString()}\n\n`;
    
    emailBody += `=== COMPLETED TASKS (${completedTasks.length}) ===\n`;
    for (const [i, task] of completedTasks.entries()) {
      emailBody += `${i + 1}. [${task.priority.toUpperCase()}] ${task.title}\n`;
      if (task.notes) emailBody += `   Notes: ${task.notes}\n`;
    }
    
    emailBody += `\n=== INCOMPLETE TASKS (${incompleteTasks.length}) ===\n`;
    for (const [i, task] of incompleteTasks.entries()) {
      emailBody += `${i + 1}. [${task.priority.toUpperCase()}] ${task.title} - Status: ${task.status}\n`;
      if (task.dueDate) emailBody += `   Due: ${task.dueDate}\n`;
    }
    
    if (remindManagerTasks.length > 0) {
      emailBody += `\n=== ITEMS TO DISCUSS WITH MANAGER (${remindManagerTasks.length}) ===\n`;
      for (const [i, task] of remindManagerTasks.entries()) {
        emailBody += `${i + 1}. ${task.title} - ${task.status}\n`;
      }
    }
    
    if (delegatedTasks.length > 0) {
      emailBody += `\n=== DELEGATED TASKS (${delegatedTasks.length}) ===\n`;
      for (const [i, task] of delegatedTasks.entries()) {
        emailBody += `${i + 1}. ${task.title} - Assigned to: ${task.assignedTo} - Status: ${task.status}\n`;
      }
    }

    // Try to copy to clipboard first
    try {
      await navigator.clipboard.writeText(emailBody);
      showNotification('success', 'Summary Copied!', 'Daily summary copied to clipboard. You can paste it in your email.');
    } catch {
      // Fallback: Download as text file if clipboard fails
      const blob = new Blob([emailBody], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `daily-task-summary-${new Date().toISOString().split('T')[0]}.txt`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      showNotification('success', 'Summary Downloaded', 'Daily summary saved as text file. You can copy its content to your email.');
    }
  };

  const handleCarryForward = async () => {
    const confirmed = await showConfirm({
      title: 'Carry Forward Tasks',
      message: 'This will mark all incomplete tasks with past due dates as "Carry Forward". Continue?',
      confirmText: 'Carry Forward',
      cancelText: 'Cancel',
      type: 'warning'
    });
    
    if (confirmed) {
      await TaskService.carryForwardTasks();
      await loadTasks();
      showNotification('success', 'Tasks Updated', 'Incomplete tasks have been carried forward!');
    }
  };

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;
    
    if (!over) return;

    const activeId = active.id;
    const overId = over.id;

    // Find the active task
    const activeTask = tasks.find(t => t.id === activeId);
    if (!activeTask) return;

    // Check if we're dropping on a column (status container) or another task
    const overTask = tasks.find(t => t.id === overId);
    
    // If dropped on a column container, change status
    if (overId === 'pending' || overId === 'in-progress' || overId === 'completed' || overId === 'carry-forward') {
      const newStatus = overId as TaskStatus;
      if (activeTask.status !== newStatus) {
        const updatedTask = {
          ...activeTask,
          status: newStatus,
          completedDate: newStatus === 'completed' ? today : undefined
        };
        await updateTask(activeTask.id!, updatedTask);
      }
    }
    // If dropped on another task, change status to match that task
    else if (overTask && activeTask.status !== overTask.status) {
      const updatedTask = {
        ...activeTask,
        status: overTask.status,
        completedDate: overTask.status === 'completed' ? today : undefined
      };
      await updateTask(activeTask.id!, updatedTask);
    }
    // If dropped on a task in the same column, reorder (just visual, not persisted)
    else if (overTask && activeTask.status === overTask.status && activeId !== overId) {
      const oldIndex = tasks.indexOf(activeTask);
      const newIndex = tasks.indexOf(overTask);
      
      const newTasks = [...tasks];
      newTasks.splice(oldIndex, 1);
      newTasks.splice(newIndex, 0, activeTask);
      
      setTasks(newTasks);
    }
  };

  const getTasksForPeriod = (period: string) => {
    const now = new Date();
    const year = now.getFullYear();
    
    let startDate: Date, endDate: Date;
    
    switch (period) {
      case 'q1':
        startDate = new Date(year, 0, 1);
        endDate = new Date(year, 2, 31);
        break;
      case 'q2':
        startDate = new Date(year, 3, 1);
        endDate = new Date(year, 5, 30);
        break;
      case 'q3':
        startDate = new Date(year, 6, 1);
        endDate = new Date(year, 8, 30);
        break;
      case 'q4':
        startDate = new Date(year, 9, 1);
        endDate = new Date(year, 11, 31);
        break;
      case 'h1':
        startDate = new Date(year, 0, 1);
        endDate = new Date(year, 5, 30);
        break;
      case 'h2':
        startDate = new Date(year, 6, 1);
        endDate = new Date(year, 11, 31);
        break;
      case 'year':
        startDate = new Date(year, 0, 1);
        endDate = new Date(year, 11, 31);
        break;
      default:
        return tasks;
    }
    
    return tasks.filter(task => {
      const taskDate = task.completedDate || task.createdDate;
      if (!taskDate) return false;
      const date = new Date(taskDate);
      return date >= startDate && date <= endDate;
    });
  };

  const filteredTasks = tasks.filter(task => {
    const matchesPriority = filterPriority === 'all' || task.priority === filterPriority;
    const matchesAssignee = filterAssignee === 'all' || task.assignedTo === filterAssignee;
    
    // Apply period filter
    let matchesPeriod = true;
    if (filterPeriod !== 'all') {
      const periodTasks = getTasksForPeriod(filterPeriod);
      matchesPeriod = periodTasks.includes(task);
    }
    
    return matchesPriority && matchesAssignee && matchesPeriod;
  });

  const tasksByStatus = {
    pending: filteredTasks.filter(t => t.status === 'pending'),
    'in-progress': filteredTasks.filter(t => t.status === 'in-progress'),
    completed: filteredTasks.filter(t => t.status === 'completed'),
    'carry-forward': filteredTasks.filter(t => t.status === 'carry-forward'),
  };

  const getUniqueAssignees = () => {
    const assignees = new Set(tasks.map(t => t.assignedTo).filter(Boolean));
    return Array.from(assignees);
  };

  const getPriorityColor = (priority: TaskPriority) => {
    switch (priority) {
      case 'urgent': return 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 border-red-300 dark:border-red-700';
      case 'high': return 'bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-300 border-orange-300 dark:border-orange-700';
      case 'medium': return 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-300 border-yellow-300 dark:border-yellow-700';
      case 'low': return 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300 border-green-300 dark:border-green-700';
    }
  };

  const getStatusColor = (status: TaskStatus) => {
    switch (status) {
      case 'completed': return 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300';
      case 'in-progress': return 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300';
      case 'carry-forward': return 'bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300';
      default: return 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300';
    }
  };

  const stats = {
    total: tasks.length,
    completed: tasks.filter(t => t.status === 'completed').length,
    pending: tasks.filter(t => t.status === 'pending').length,
    inProgress: tasks.filter(t => t.status === 'in-progress').length,
    urgent: tasks.filter(t => t.priority === 'urgent' && t.status !== 'completed').length,
    remindManager: tasks.filter(t => t.remindManager && t.status !== 'completed').length,
  };

  return (
    <div className="space-y-6">
      {/* Header with Stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <div className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-700">
          <div className="text-sm text-gray-600 dark:text-gray-400">Total Tasks</div>
          <div className="text-2xl font-bold text-gray-900 dark:text-white">{stats.total}</div>
        </div>
        <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4 border border-green-200 dark:border-green-800">
          <div className="text-sm text-green-600 dark:text-green-400">Completed</div>
          <div className="text-2xl font-bold text-green-700 dark:text-green-300">{stats.completed}</div>
        </div>
        <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4 border border-blue-200 dark:border-blue-800">
          <div className="text-sm text-blue-600 dark:text-blue-400">In Progress</div>
          <div className="text-2xl font-bold text-blue-700 dark:text-blue-300">{stats.inProgress}</div>
        </div>
        <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 border border-gray-200 dark:border-gray-600">
          <div className="text-sm text-gray-600 dark:text-gray-400">Pending</div>
          <div className="text-2xl font-bold text-gray-700 dark:text-gray-300">{stats.pending}</div>
        </div>
        <div className="bg-red-50 dark:bg-red-900/20 rounded-lg p-4 border border-red-200 dark:border-red-800">
          <div className="text-sm text-red-600 dark:text-red-400">Urgent</div>
          <div className="text-2xl font-bold text-red-700 dark:text-red-300">{stats.urgent}</div>
        </div>
        <div className="bg-amber-50 dark:bg-amber-900/20 rounded-lg p-4 border border-amber-200 dark:border-amber-800">
          <div className="text-sm text-amber-600 dark:text-amber-400">Remind Manager</div>
          <div className="text-2xl font-bold text-amber-700 dark:text-amber-300">{stats.remindManager}</div>
        </div>
      </div>

      {/* Action Buttons and Filters */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-700">
        <div className="flex flex-col lg:flex-row items-start lg:items-center gap-4">
          {/* Filters */}
          <div className="flex items-center gap-3 flex-1">
            <Filter className="w-5 h-5 text-gray-600 dark:text-gray-400 flex-shrink-0" />
            <div className="flex flex-col sm:flex-row gap-3 flex-1">
              <select
                value={filterPriority}
                onChange={(e) => setFilterPriority(e.target.value as TaskPriority | 'all')}
                className="px-4 py-2 bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none text-gray-900 dark:text-white text-sm"
              >
                <option value="all">All Priorities</option>
                <option value="urgent">Urgent</option>
                <option value="high">High</option>
                <option value="medium">Medium</option>
                <option value="low">Low</option>
              </select>
              <select
                value={filterAssignee}
                onChange={(e) => setFilterAssignee(e.target.value)}
                className="px-4 py-2 bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none text-gray-900 dark:text-white text-sm"
              >
                <option value="all">All Assignees</option>
                {getUniqueAssignees().map(assignee => (
                  <option key={assignee} value={assignee}>{assignee}</option>
                ))}
              </select>
              <select
                value={filterPeriod}
                onChange={(e) => setFilterPeriod(e.target.value)}
                className="px-4 py-2 bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none text-gray-900 dark:text-white text-sm"
              >
                <option value="all">All Time</option>
                <option value="q1">Q1 (Jan-Mar)</option>
                <option value="q2">Q2 (Apr-Jun)</option>
                <option value="q3">Q3 (Jul-Sep)</option>
                <option value="q4">Q4 (Oct-Dec)</option>
                <option value="h1">H1 (Jan-Jun)</option>
                <option value="h2">H2 (Jul-Dec)</option>
                <option value="year">Full Year</option>
              </select>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap gap-2 lg:flex-shrink-0">
            <button
              onClick={() => {
                setEditingTask(null);
                setIsAddDrawerOpen(true);
              }}
              className={`flex items-center gap-2 px-4 py-2 ${themeColors[theme]} text-white rounded-lg shadow-md hover:shadow-lg transition-all duration-200 font-medium text-sm whitespace-nowrap`}
            >
              <Plus className="w-4 h-4" />
              Add Task
            </button>
            <button
              onClick={generateEmailSummary}
              className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 shadow-md hover:shadow-lg transition-all duration-200 font-medium text-sm whitespace-nowrap"
            >
              <Mail className="w-4 h-4" />
              Email
            </button>
            <button
              onClick={handleCarryForward}
              className="flex items-center gap-2 px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 shadow-md hover:shadow-lg transition-all duration-200 font-medium text-sm whitespace-nowrap"
            >
              <ArrowRight className="w-4 h-4" />
              Carry Forward
            </button>
            <button
              onClick={() => filterPeriod !== 'all' && generatePeriodSummary(filterPeriod)}
              disabled={filterPeriod === 'all'}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg shadow-md hover:shadow-lg transition-all duration-200 font-medium text-sm whitespace-nowrap ${
                filterPeriod === 'all'
                  ? 'bg-gray-300 dark:bg-gray-600 text-gray-500 dark:text-gray-400 cursor-not-allowed'
                  : 'bg-orange-600 text-white hover:bg-orange-700'
              }`}
            >
              <FileText className="w-4 h-4" />
              Period Summary
            </button>
          </div>
        </div>
      </div>

      {/* Kanban Board */}
      <div>
        <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
          Tasks Board ({filteredTasks.length} total)
        </h3>
        
        {tasks.length === 0 ? (
          <div className="bg-white dark:bg-gray-800 rounded-lg p-12 text-center border border-gray-200 dark:border-gray-700">
            <AlertCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-500 dark:text-gray-400">No tasks found. Click "Add New Task" to get started!</p>
          </div>
        ) : (
          <DndContext sensors={sensors} collisionDetection={closestCorners} onDragEnd={handleDragEnd}>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Pending Column */}
              <DroppableColumn id="pending" title="Pending" count={tasksByStatus.pending.length} color="gray">
                <SortableContext items={tasksByStatus.pending.map(t => t.id!)} strategy={verticalListSortingStrategy}>
                  <div className="space-y-2 min-h-[100px]">
                    {tasksByStatus.pending.map((task) => (
                      <TaskCard
                        key={task.id}
                        task={task}
                        onEdit={handleEdit}
                        onDelete={deleteTask}
                        onStatusChange={handleStatusChange}
                        getPriorityColor={getPriorityColor}
                        getStatusColor={getStatusColor}
                      />
                    ))}
                  </div>
                </SortableContext>
              </DroppableColumn>

              {/* In Progress Column */}
              <DroppableColumn id="in-progress" title="In Progress" count={tasksByStatus['in-progress'].length} color="blue">
                <SortableContext items={tasksByStatus['in-progress'].map(t => t.id!)} strategy={verticalListSortingStrategy}>
                  <div className="space-y-2 min-h-[100px]">
                    {tasksByStatus['in-progress'].map((task) => (
                      <TaskCard
                        key={task.id}
                        task={task}
                        onEdit={handleEdit}
                        onDelete={deleteTask}
                        onStatusChange={handleStatusChange}
                        getPriorityColor={getPriorityColor}
                        getStatusColor={getStatusColor}
                      />
                    ))}
                  </div>
                </SortableContext>
              </DroppableColumn>

              {/* Completed Column */}
              <DroppableColumn id="completed" title="Completed" count={tasksByStatus.completed.length} color="green">
                <SortableContext items={tasksByStatus.completed.map(t => t.id!)} strategy={verticalListSortingStrategy}>
                  <div className="space-y-2 min-h-[100px]">
                    {tasksByStatus.completed.map((task) => (
                      <TaskCard
                        key={task.id}
                        task={task}
                        onEdit={handleEdit}
                        onDelete={deleteTask}
                        onStatusChange={handleStatusChange}
                        getPriorityColor={getPriorityColor}
                        getStatusColor={getStatusColor}
                      />
                    ))}
                  </div>
                </SortableContext>
              </DroppableColumn>

              {/* Carry Forward Column */}
              <DroppableColumn id="carry-forward" title="Carry Forward" count={tasksByStatus['carry-forward'].length} color="purple">
                <SortableContext items={tasksByStatus['carry-forward'].map(t => t.id!)} strategy={verticalListSortingStrategy}>
                  <div className="space-y-2 min-h-[100px]">
                    {tasksByStatus['carry-forward'].map((task) => (
                      <TaskCard
                        key={task.id}
                        task={task}
                        onEdit={handleEdit}
                        onDelete={deleteTask}
                        onStatusChange={handleStatusChange}
                        getPriorityColor={getPriorityColor}
                        getStatusColor={getStatusColor}
                      />
                    ))}
                  </div>
                </SortableContext>
              </DroppableColumn>
            </div>
          </DndContext>
        )}
      </div>

      {/* Add/Edit Task Form */}
      <AnimatePresence>
        {isAddDrawerOpen && (
          <AddTaskForm
            isOpen={isAddDrawerOpen}
            onClose={() => {
              setIsAddDrawerOpen(false);
              setEditingTask(null);
            }}
            onAdd={editingTask ? (task) => updateTask(editingTask.id!, task as Task) : addTask}
            editTask={editingTask}
          />
        )}
      </AnimatePresence>
    </div>
  );
};

export default TaskManager;
