import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { Trash2, Edit2, Bell, User, Calendar, GripVertical } from 'lucide-react';
import { Task, TaskPriority, TaskStatus } from '../types';

interface TaskCardProps {
  task: Task;
  onEdit: (task: Task) => void;
  onDelete: (id: number) => void;
  onStatusChange: (task: Task, status: TaskStatus) => void;
  getPriorityColor: (priority: TaskPriority) => string;
  getStatusColor: (status: TaskStatus) => string;
}

const TaskCard = ({ task, onEdit, onDelete, onStatusChange, getPriorityColor, getStatusColor }: TaskCardProps) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: task.id! });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 p-3 hover:shadow-md transition-shadow"
    >
      <div className="flex items-start gap-2">
        {/* Drag Handle */}
        <div
          {...attributes}
          {...listeners}
          className="cursor-grab active:cursor-grabbing mt-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
        >
          <GripVertical className="w-4 h-4" />
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          {/* Title and Priority */}
          <div className="flex items-start justify-between gap-2 mb-2">
            <h4 className="font-semibold text-sm text-gray-900 dark:text-white line-clamp-2">
              {task.title}
            </h4>
            <span className={`text-xs px-2 py-0.5 rounded-full border whitespace-nowrap ${getPriorityColor(task.priority)}`}>
              {task.priority}
            </span>
          </div>

          {/* Description */}
          {task.description && (
            <p className="text-xs text-gray-600 dark:text-gray-400 mb-2 line-clamp-2">
              {task.description}
            </p>
          )}

          {/* Metadata */}
          <div className="flex flex-wrap items-center gap-2 text-xs text-gray-500 dark:text-gray-400 mb-2">
            {task.dueDate && (
              <span className="flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                Due: {new Date(task.dueDate).toLocaleDateString()}
              </span>
            )}
            {task.completedDate && task.status === 'completed' && (
              <span className="flex items-center gap-1 text-green-600 dark:text-green-400">
                <Calendar className="w-3 h-3" />
                ✓ {new Date(task.completedDate).toLocaleDateString()}
              </span>
            )}
            {task.assignedTo && (
              <span className="flex items-center gap-1">
                <User className="w-3 h-3" />
                {task.assignedTo}
              </span>
            )}
            {task.remindManager && (
              <span className="flex items-center gap-1 text-amber-600 dark:text-amber-400">
                <Bell className="w-3 h-3" />
                Remind
              </span>
            )}
          </div>

          {/* Status and Actions */}
          <div className="flex items-center justify-between gap-2">
            <select
              value={task.status}
              onChange={(e) => onStatusChange(task, e.target.value as TaskStatus)}
              className={`text-xs px-2 py-1 rounded-md border-0 focus:ring-1 focus:ring-blue-500 ${getStatusColor(task.status)}`}
            >
              <option value="pending">Pending</option>
              <option value="in-progress">In Progress</option>
              <option value="completed">Completed</option>
              <option value="carry-forward">Carry Forward</option>
            </select>

            <div className="flex items-center gap-1">
              <button
                onClick={() => onEdit(task)}
                className="p-1 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded hover:bg-blue-200 dark:hover:bg-blue-900/50 transition-all"
                title="Edit Task"
              >
                <Edit2 className="w-3 h-3" />
              </button>
              <button
                onClick={() => onDelete(task.id!)}
                className="p-1 bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded hover:bg-red-200 dark:hover:bg-red-900/50 transition-all"
                title="Delete Task"
              >
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TaskCard;
