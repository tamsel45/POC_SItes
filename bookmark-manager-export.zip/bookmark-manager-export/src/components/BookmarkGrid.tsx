import { useState } from 'react';
import { Trash2, FolderOpen, Edit2, Copy, Check, ExternalLink, CheckSquare, Tag, X, RefreshCw, Folder } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bookmark } from '../types';
import { useNotification } from '../contexts/NotificationContext';
import FilePathModal from './FilePathModal';

interface BookmarkGridProps {
  bookmarks: Bookmark[];
  onDelete: (id: number) => void;
  onUpdate: (id: number, bookmark: Bookmark) => Promise<void>;
  isDarkMode: boolean;
}

const BookmarkGrid = ({ bookmarks, onDelete, onUpdate, isDarkMode }: BookmarkGridProps) => {
  const { showNotification } = useNotification();
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editFormData, setEditFormData] = useState<Bookmark | null>(null);
  const [copiedId, setCopiedId] = useState<number | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
  const [showBulkUpdate, setShowBulkUpdate] = useState(false);
  const [bulkCategory, setBulkCategory] = useState('');
  const [filePathToShow, setFilePathToShow] = useState<string | null>(null);

  const handleEdit = (bookmark: Bookmark, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(bookmark.id || null);
    setEditFormData({ ...bookmark });
  };

  const handleCancelEdit = (e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(null);
    setEditFormData(null);
  };

  const handleSaveEdit = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (editingId && editFormData) {
      console.log('Saving edit for ID:', editingId, 'Data:', editFormData);
      await onUpdate(editingId, editFormData);
      setEditingId(null);
      setEditFormData(null);
      showNotification('success', 'Bookmark updated', 'Your changes have been saved successfully.');
    }
  };

  const handleCopyLink = async (url: string, id: number) => {
    try {
      await navigator.clipboard.writeText(url);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    } catch (error) {
      console.error('Failed to copy:', error);
    }
  };

  const toggleSelection = (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    const newSelected = new Set(selectedIds);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedIds(newSelected);
  };

  const handleBulkCategoryUpdate = async () => {
    if (!bulkCategory.trim()) {
      showNotification('warning', 'Category required', 'Please enter a category name before updating.');
      return;
    }

    let successCount = 0;
    let errorCount = 0;

    for (const id of Array.from(selectedIds)) {
      const bookmark = bookmarks.find(b => b.id === id);
      if (bookmark && bookmark.id) {
        try {
          await onUpdate(bookmark.id, { ...bookmark, category: bulkCategory.toLowerCase() });
          successCount++;
        } catch (error) {
          console.error(`Failed to update bookmark ${bookmark.id}:`, error);
          errorCount++;
        }
      }
    }

    setSelectedIds(new Set());
    setShowBulkUpdate(false);
    setBulkCategory('');
    
    if (errorCount > 0) {
      showNotification('warning', 'Partial update', `Updated ${successCount} bookmarks. Failed to update ${errorCount} bookmarks. Check console for details.`);
    } else {
      showNotification('success', 'Bulk update successful', `Successfully updated ${successCount} bookmarks to category: ${bulkCategory}`);
    }
  };

  const handleSelectAll = (category: string) => {
    const categoryBookmarks = bookmarks.filter(b => b.category === category);
    const newSelected = new Set(selectedIds);
    const allSelected = categoryBookmarks.every(b => newSelected.has(b.id || 0));
    
    if (allSelected) {
      for (const b of categoryBookmarks) {
        newSelected.delete(b.id || 0);
      }
    } else {
      for (const b of categoryBookmarks) {
        newSelected.add(b.id || 0);
      }
    }
    setSelectedIds(newSelected);
  };

  const handleCardClick = (url: string, e: React.MouseEvent) => {
    // Don't navigate if clicking on buttons or inputs
    const target = e.target as HTMLElement;
    if (target.tagName === 'BUTTON' || target.tagName === 'INPUT' || target.closest('button') || target.closest('input')) {
      return;
    }
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const groupedBookmarks = bookmarks.reduce((acc, bookmark) => {
    if (!acc[bookmark.category]) {
      acc[bookmark.category] = [];
    }
    acc[bookmark.category].push(bookmark);
    return acc;
  }, {} as Record<string, Bookmark[]>);

  return (
    <div className="space-y-10">
      {/* Bulk Update Panel */}
      {selectedIds.size > 0 && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="fixed top-20 right-8 z-50 bg-white dark:bg-gray-800 p-6 rounded-xl shadow-xl border border-gray-200 dark:border-gray-700"
        >
          <div className="flex items-center gap-2 mb-3">
            <CheckSquare className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            <h3 className="text-lg font-bold text-gray-900 dark:text-white">
              {selectedIds.size} Selected
            </h3>
          </div>
          {!showBulkUpdate ? (
            <button
              onClick={() => setShowBulkUpdate(true)}
              className="flex items-center justify-center gap-2 w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all duration-200 shadow-md font-medium"
            >
              <Tag className="w-4 h-4" />
              Update Category
            </button>
          ) : (
            <div className="space-y-3">
              <div className="relative">
                <Tag className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="text"
                  value={bulkCategory}
                  onChange={(e) => setBulkCategory(e.target.value)}
                  placeholder="Enter new category"
                  className="w-full pl-10 pr-4 py-2 bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none text-gray-900 dark:text-white"
                />
              </div>
              <div className="flex gap-2">
                <button
                  onClick={handleBulkCategoryUpdate}
                  className="flex items-center justify-center gap-1.5 flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-all duration-200 shadow-md font-medium"
                >
                  <Check className="w-4 h-4" />
                  Apply
                </button>
                <button
                  onClick={() => {
                    setShowBulkUpdate(false);
                    setBulkCategory('');
                  }}
                  className="flex items-center justify-center gap-1.5 flex-1 px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-all duration-200 shadow-md font-medium"
                >
                  <X className="w-4 h-4" />
                  Cancel
                </button>
              </div>
              <button
                onClick={() => setSelectedIds(new Set())}
                className="flex items-center justify-center gap-1.5 w-full px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-all duration-200 shadow-md font-medium text-sm"
              >
                <X className="w-4 h-4" />
                Clear Selection
              </button>
            </div>
          )}
        </motion.div>
      )}

      {Object.entries(groupedBookmarks).map(([category, bookmarks]) => {
        const categorySelected = bookmarks.filter(b => selectedIds.has(b.id || 0)).length;
        const allCategorySelected = categorySelected === bookmarks.length && bookmarks.length > 0;
        
        return (
          <motion.div
            key={category}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-2">
                <Folder className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                  {category.charAt(0).toUpperCase() + category.slice(1)}
                </h2>
              </div>
              <button
                onClick={() => handleSelectAll(category)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-200 shadow-md font-medium ${
                  allCategorySelected
                    ? 'bg-blue-600 text-white hover:bg-blue-700'
                    : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-600 border border-gray-300 dark:border-gray-600'
                }`}
              >
                {allCategorySelected ? (
                  <>
                    <CheckSquare className="w-4 h-4" />
                    All Selected
                  </>
                ) : (
                  <>
                    <CheckSquare className="w-4 h-4" />
                    Select All ({bookmarks.length})
                  </>
                )}
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-6">
            {bookmarks.map((bookmark) => {
              const isSelected = selectedIds.has(bookmark.id || 0);
              return (
              <motion.div
                key={bookmark.id}
                layout
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                onClick={(e) => handleCardClick(bookmark.url, e)}
                className={`p-4 rounded-lg cursor-pointer transition-all duration-200 border ${
                  isSelected
                    ? 'border-blue-500 ring-2 ring-blue-500/50 bg-blue-50 dark:bg-blue-900/20'
                    : isDarkMode 
                      ? 'border-gray-700 bg-gray-800 hover:bg-blue-900 hover:border-blue-800' 
                      : 'border-gray-200 bg-white hover:bg-blue-50 hover:border-blue-300'
                } shadow-md hover:shadow-lg`}
              >
                {editingId === bookmark.id && editFormData ? (
                  <AnimatePresence>
                    <motion.div
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      className="space-y-3"
                    >
                      <input
                        type="text"
                        value={editFormData.title}
                        onChange={(e) => setEditFormData({ ...editFormData, title: e.target.value })}
                        onClick={(e) => e.stopPropagation()}
                        className="w-full px-3 py-2.5 bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none text-gray-900 dark:text-white"
                        placeholder="Title"
                      />
                      <input
                        type="text"
                        value={editFormData.url}
                        onChange={(e) => setEditFormData({ ...editFormData, url: e.target.value })}
                        onClick={(e) => e.stopPropagation()}
                        className="w-full px-3 py-2.5 bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none text-gray-900 dark:text-white"
                        placeholder="URL"
                      />
                      <input
                        type="text"
                        value={editFormData.category}
                        onChange={(e) => setEditFormData({ ...editFormData, category: e.target.value.toLowerCase() })}
                        onClick={(e) => e.stopPropagation()}
                        className="w-full px-3 py-2.5 bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none text-gray-900 dark:text-white"
                        placeholder="Category"
                      />
                      <input
                        type="text"
                        value={editFormData.localPath || ''}
                        onChange={(e) => setEditFormData({ ...editFormData, localPath: e.target.value })}
                        onClick={(e) => e.stopPropagation()}
                        className="w-full px-3 py-2.5 bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none text-gray-900 dark:text-white"
                        placeholder="Local Path (Optional)"
                      />
                      <div className="flex gap-2">
                        <button
                          onClick={(e) => handleSaveEdit(e)}
                          className="flex-1 px-4 py-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-all duration-200 shadow-md font-medium"
                        >
                          Save
                        </button>
                        <button
                          onClick={(e) => handleCancelEdit(e)}
                          className="flex-1 px-4 py-2.5 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-all duration-200 shadow-md font-medium"
                        >
                          Cancel
                        </button>
                      </div>
                    </motion.div>
                  </AnimatePresence>
                ) : (
                  <>
                    {/* Single row with checkbox, icon, title, and action buttons */}
                    <div className="flex items-center gap-2 mb-2">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={(e) => toggleSelection(bookmark.id || 0, e as unknown as React.MouseEvent)}
                        onClick={(e) => e.stopPropagation()}
                        className="w-4 h-4 rounded accent-purple-600 cursor-pointer flex-shrink-0"
                      />
                      <div className="p-1.5 rounded bg-blue-600 flex-shrink-0">
                        <ExternalLink className="w-3.5 h-3.5 text-white" />
                      </div>
                      <h3 className="text-base font-semibold text-gray-900 dark:text-white truncate flex-1 min-w-0">
                        {bookmark.title}
                      </h3>
                      <div className="flex gap-1 flex-shrink-0">
                        <button
                          onClick={() => handleCopyLink(bookmark.url, bookmark.id || 0)}
                          className="p-1.5 rounded bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition-all duration-200"
                          title="Copy link"
                        >
                          {copiedId === bookmark.id ? (
                            <Check className="w-3.5 h-3.5 text-green-600" />
                          ) : (
                            <Copy className="w-3.5 h-3.5 text-gray-600 dark:text-gray-300" />
                          )}
                        </button>
                        <button
                          onClick={(e) => handleEdit(bookmark, e)}
                          className="p-1.5 rounded bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition-all duration-200"
                          title="Edit bookmark"
                        >
                          <Edit2 className="w-3.5 h-3.5 text-gray-600 dark:text-gray-300" />
                        </button>
                        <button
                          onClick={() => bookmark.id && onDelete(bookmark.id)}
                          className="p-1.5 rounded bg-gray-100 dark:bg-gray-700 hover:bg-red-100 dark:hover:bg-red-900/30 transition-all duration-200"
                          title="Delete bookmark"
                        >
                          <Trash2 className="w-3.5 h-3.5 text-red-600 dark:text-red-400" />
                        </button>
                      </div>
                    </div>
                    <p className="text-xs text-gray-600 dark:text-gray-400 mt-1.5 truncate">
                      {bookmark.url}
                    </p>
                    {bookmark.localPath && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setFilePathToShow(bookmark.localPath || '');
                        }}
                        className="mt-2 text-xs px-2.5 py-1 rounded bg-purple-600 text-white hover:bg-purple-700 flex items-center gap-1.5 transition-all duration-200 font-medium"
                      >
                        <FolderOpen className="w-3.5 h-3.5" />
                        <span>Open Local File</span>
                      </button>
                    )}
                  </>
                )}
              </motion.div>
              );
            })}
          </div>
        </motion.div>
        );
      })}

      {/* File Path Modal */}
      <AnimatePresence>
        {filePathToShow && (
          <FilePathModal
            filePath={filePathToShow}
            onClose={() => setFilePathToShow(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
};

export default BookmarkGrid;