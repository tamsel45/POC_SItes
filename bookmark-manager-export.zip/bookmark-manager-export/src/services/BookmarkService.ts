import { Bookmark } from '../types';

const API_URL = 'http://localhost:3001/api';

export const BookmarkService = {
  async getAllBookmarks(): Promise<Bookmark[]> {
    try {
      const response = await fetch(`${API_URL}/bookmarks`);
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      const data = await response.json();
      return data.bookmarks || [];
    } catch (error) {
      console.error('Error reading bookmarks:', error);
      return [];
    }
  },

  async addBookmark(bookmark: Bookmark): Promise<Bookmark | null> {
    try {
      const response = await fetch(`${API_URL}/bookmarks`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(bookmark),
      });
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      const data = await response.json();
      return data as Bookmark;
    } catch (error) {
      console.error('Error adding bookmark:', error);
      return null;
    }
  },

  async updateBookmark(id: number, bookmark: Bookmark): Promise<Bookmark | null> {
    try {
      console.log('Updating bookmark:', id, bookmark);
      const response = await fetch(`${API_URL}/bookmarks/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(bookmark),
      });
      console.log('Update response status:', response.status);
      if (!response.ok) {
        const errorText = await response.text();
        console.error('Update failed:', errorText);
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      const data = await response.json();
      console.log('Updated bookmark data:', data);
      return data as Bookmark;
    } catch (error) {
      console.error('Error updating bookmark:', error);
      return null;
    }
  },

  async importBookmarks(bookmarks: Bookmark[]): Promise<{ success: boolean; count: number } | null> {
    try {
      console.log('Importing bookmarks:', bookmarks.length);
      const response = await fetch(`${API_URL}/bookmarks/import`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ bookmarks }),
      });
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error importing bookmarks:', error);
      return null;
    }
  },

  async deleteBookmark(id: number): Promise<boolean> {
    try {
      const response = await fetch(`${API_URL}/bookmarks/${id}`, {
        method: 'DELETE',
      });
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      return true;
    } catch (error) {
      console.error('Error deleting bookmark:', error);
      return false;
    }
  }
};