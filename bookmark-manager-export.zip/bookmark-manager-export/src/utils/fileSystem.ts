type NotificationCallback = (type: 'success' | 'error' | 'warning' | 'info', title: string, message?: string) => void;

export const openLocalFile = async (
  filePath: string, 
  showNotification?: NotificationCallback
): Promise<void> => {
  try {
    // Validate that the file path is provided
    if (!filePath || filePath.trim().length === 0) {
      if (showNotification) {
        showNotification('error', 'Empty file path', 'No file path was provided.');
      }
      return;
    }

    // Browsers cannot directly open local files for security reasons
    // Show the user the file path in a notification with instructions
    if (showNotification) {
      showNotification(
        'info', 
        'Open Local File', 
        `Path: ${filePath}\n\nPlease use File Explorer or your operating system's file manager to open this file.`
      );
    }

    // Log for debugging
    console.log('Open file request:', filePath);
  } catch (error) {
    console.error('Error processing file path:', error);
    if (showNotification) {
      showNotification(
        'error', 
        'Unable to process file path', 
        `Path: ${filePath}\n\nPlease check the path and try again.`
      );
    }
  }
};