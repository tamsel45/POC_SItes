import { useState, useEffect, useRef } from 'react';
import { Search, Moon, Sun, Upload, Plus, Bookmark as BookmarkIcon, Filter, Grid3x3, List, Palette, HelpCircle, CheckSquare } from 'lucide-react';
import AddBookmarkForm from './components/AddBookmarkForm';
import BookmarkGrid from './components/BookmarkGrid';
import BookmarkList from './components/BookmarkList';
import KeyboardShortcutsModal from './components/KeyboardShortcutsModal';
import TaskManager from './components/TaskManager';
import { Bookmark } from './types';
import { BookmarkService } from './services/BookmarkService';
import { parseBookmarkHTML, parseBookmarkJSON } from './utils/bookmarkParser';
import { useNotification } from './contexts/NotificationContext';
import { useKeyboardShortcuts } from './hooks/useKeyboardShortcuts';

function App() {
  const { showNotification, showConfirm } = useNotification();
  const [bookmarks, setBookmarks] = useState<Bookmark[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isImporting, setIsImporting] = useState(false);
  const [isAddDrawerOpen, setIsAddDrawerOpen] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [theme, setTheme] = useState<'blue' | 'purple' | 'green' | 'orange'>('blue');
  const [showThemeSelector, setShowThemeSelector] = useState(false);
  const [advancedFiltersOpen, setAdvancedFiltersOpen] = useState(false);
  const [dateRange, setDateRange] = useState<{ start: string; end: string }>({ start: '', end: '' });
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [showOnlyWithFiles, setShowOnlyWithFiles] = useState(false);
  const [showHelpModal, setShowHelpModal] = useState(false);
  const [currentPage, setCurrentPage] = useState<'bookmarks' | 'tasks'>('bookmarks');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Keyboard shortcuts
  useKeyboardShortcuts({
    onNewBookmark: () => setIsAddDrawerOpen(true),
    onSearch: () => searchInputRef.current?.focus(),
    onToggleView: () => setViewMode(prev => prev === 'grid' ? 'list' : 'grid'),
    onToggleDarkMode: () => setIsDarkMode(prev => !prev),
    onShowHelp: () => setShowHelpModal(true),
    onEscape: () => {
      setIsAddDrawerOpen(false);
      setShowThemeSelector(false);
      setAdvancedFiltersOpen(false);
      setShowHelpModal(false);
    },
  });

  useEffect(() => {
    // Load bookmarks from service on mount
    const loadBookmarks = async () => {
      const savedBookmarks = await BookmarkService.getAllBookmarks();
      setBookmarks(savedBookmarks);
    };
    loadBookmarks();
  }, []);

  const addBookmark = async (bookmark: Bookmark) => {
    const newBookmark = await BookmarkService.addBookmark(bookmark);
    if (newBookmark) {
      setBookmarks(currentBookmarks => [...currentBookmarks, newBookmark]);
    }
  };

  const updateBookmark = async (id: number, updatedBookmark: Bookmark): Promise<void> => {
    console.log('App: updateBookmark called for ID:', id);
    const result = await BookmarkService.updateBookmark(id, updatedBookmark);
    console.log('App: received result:', result);
    if (result) {
      setBookmarks(currentBookmarks => 
        currentBookmarks.map(bookmark => bookmark.id === id ? result : bookmark)
      );
      console.log('App: bookmarks state updated');
    } else {
      console.error('App: update failed, result is null');
    }
  };

  const deleteBookmark = async (id: number) => {
    const confirmed = await showConfirm({
      title: 'Delete Bookmark',
      message: 'Are you sure you want to delete this bookmark? This action cannot be undone.',
      confirmText: 'Delete',
      cancelText: 'Cancel',
      type: 'danger'
    });
    
    if (confirmed) {
      const success = await BookmarkService.deleteBookmark(id);
      if (success) {
        setBookmarks(currentBookmarks => currentBookmarks.filter(bookmark => bookmark.id !== id));
        showNotification('success', 'Bookmark deleted', 'The bookmark has been successfully removed.');
      } else {
        showNotification('error', 'Delete failed', 'Failed to delete the bookmark. Please try again.');
      }
    }
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsImporting(true);
    try {
      const content = await file.text();
      let importedBookmarks: Bookmark[] = [];

      // Determine file type and parse accordingly
      if (file.name.endsWith('.html') || file.name.endsWith('.htm')) {
        importedBookmarks = parseBookmarkHTML(content);
      } else if (file.name.endsWith('.json')) {
        importedBookmarks = parseBookmarkJSON(content);
      } else {
        showNotification('error', 'Unsupported file format', 'Please use HTML or JSON files.');
        return;
      }

      if (importedBookmarks.length === 0) {
        showNotification('warning', 'No bookmarks found', 'The file does not contain any valid bookmarks.');
        return;
      }

      // Call the import API
      const result = await BookmarkService.importBookmarks(importedBookmarks);
      if (result?.success) {
        showNotification('success', 'Import successful', `Successfully imported ${result.count} bookmarks!`);
        // Reload all bookmarks
        const updatedBookmarks = await BookmarkService.getAllBookmarks();
        setBookmarks(updatedBookmarks);
      } else {
        showNotification('error', 'Import failed', 'Failed to import bookmarks. Please try again.');
      }
    } catch (error) {
      console.error('Import error:', error);
      showNotification('error', 'Import error', error instanceof Error ? error.message : 'Unknown error occurred');
    } finally {
      setIsImporting(false);
      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const filteredBookmarks = bookmarks.filter(bookmark => {
    const matchesSearch = bookmark.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      bookmark.url.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || bookmark.category === selectedCategory;
    const matchesAdvancedCategories = selectedCategories.length === 0 || selectedCategories.includes(bookmark.category);
    const matchesFileFilter = !showOnlyWithFiles || !!bookmark.localPath;
    
    // Date range filter (if implemented with createdAt field in future)
    let matchesDateRange = true;
    if (dateRange.start || dateRange.end) {
      // Placeholder for future date filtering when createdAt is added to Bookmark type
      matchesDateRange = true;
    }
    
    return matchesSearch && matchesCategory && matchesAdvancedCategories && matchesFileFilter && matchesDateRange;
  });

  const categories = ['all', ...new Set(bookmarks.map(b => b.category))];

  // Theme color configurations
  const themeColors = {
    blue: {
      primary: 'bg-blue-600 hover:bg-blue-700',
      secondary: 'bg-blue-900 hover:bg-blue-950',
      text: 'text-blue-600 dark:text-blue-400',
      border: 'border-blue-500 ring-blue-500/50',
      hover: 'hover:bg-blue-50 dark:hover:bg-blue-900',
    },
    purple: {
      primary: 'bg-purple-600 hover:bg-purple-700',
      secondary: 'bg-purple-900 hover:bg-purple-950',
      text: 'text-purple-600 dark:text-purple-400',
      border: 'border-purple-500 ring-purple-500/50',
      hover: 'hover:bg-purple-50 dark:hover:bg-purple-900',
    },
    green: {
      primary: 'bg-green-600 hover:bg-green-700',
      secondary: 'bg-green-900 hover:bg-green-950',
      text: 'text-green-600 dark:text-green-400',
      border: 'border-green-500 ring-green-500/50',
      hover: 'hover:bg-green-50 dark:hover:bg-green-900',
    },
    orange: {
      primary: 'bg-orange-600 hover:bg-orange-700',
      secondary: 'bg-orange-900 hover:bg-orange-950',
      text: 'text-orange-600 dark:text-orange-400',
      border: 'border-orange-500 ring-orange-500/50',
      hover: 'hover:bg-orange-50 dark:hover:bg-orange-900',
    },
  };

  const currentTheme = themeColors[theme];

  return (
    <div className={`min-h-screen ${isDarkMode ? 'dark bg-gray-900' : 'bg-gray-50'}`}>
      <div className="w-full px-4 md:px-8 lg:px-12 py-6">
        <header className="mb-8">
          <div className="flex flex-col gap-4 bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {currentPage === 'bookmarks' ? (
                  <BookmarkIcon className="w-8 h-8 text-blue-600 dark:text-blue-400" />
                ) : (
                  <CheckSquare className="w-8 h-8 text-blue-600 dark:text-blue-400" />
                )}
                <h1 className="text-4xl font-bold text-gray-900 dark:text-white">
                  {currentPage === 'bookmarks' ? 'Bookmark Manager' : 'Task Manager'}
                </h1>
              </div>
              
              {/* Page Navigation Tabs */}
              <div className="flex items-center gap-2 bg-gray-100 dark:bg-gray-700 rounded-lg p-1">
                <button
                  onClick={() => setCurrentPage('bookmarks')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-md transition-all duration-200 ${
                    currentPage === 'bookmarks'
                      ? 'bg-white dark:bg-gray-600 shadow-md text-blue-600 dark:text-blue-400'
                      : 'text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                  }`}
                >
                  <BookmarkIcon className="w-4 h-4" />
                  Bookmarks
                </button>
                <button
                  onClick={() => setCurrentPage('tasks')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-md transition-all duration-200 ${
                    currentPage === 'tasks'
                      ? 'bg-white dark:bg-gray-600 shadow-md text-blue-600 dark:text-blue-400'
                      : 'text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                  }`}
                >
                  <CheckSquare className="w-4 h-4" />
                  Tasks
                </button>
              </div>
            </div>
            
            {currentPage === 'bookmarks' && (
              <div className="flex items-center gap-3">
                <button
                  onClick={handleImportClick}
                  disabled={isImporting}
                  className={`flex items-center gap-2 px-5 py-2.5 text-white rounded-lg disabled:opacity-50 disabled:cursor-not-allowed shadow-md hover:shadow-lg transition-all duration-200 ${currentTheme.primary}`}
                >
                  <Upload className="w-4 h-4" />
                  {isImporting ? 'Importing...' : 'Import'}
                </button>
                <button
                  onClick={() => setIsAddDrawerOpen(true)}
                  className={`flex items-center gap-2 px-5 py-2.5 text-white rounded-lg shadow-md hover:shadow-lg transition-all duration-200 ${currentTheme.secondary}`}
                >
                  <Plus className="w-4 h-4" />
                  Add Bookmark
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".html,.htm,.json"
                  onChange={handleFileImport}
                  className="hidden"
                />
                
                {/* View Mode Toggle */}
                <div className="flex items-center gap-1 bg-gray-200 dark:bg-gray-700 rounded-lg p-1">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-2 rounded-md transition-all duration-200 ${
                    viewMode === 'grid'
                      ? 'bg-white dark:bg-gray-600 shadow-md'
                      : 'hover:bg-gray-300 dark:hover:bg-gray-600'
                  }`}
                  title="Grid View"
                >
                  <Grid3x3 className={`w-5 h-5 ${viewMode === 'grid' ? currentTheme.text : 'text-gray-600 dark:text-gray-300'}`} />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-2 rounded-md transition-all duration-200 ${
                    viewMode === 'list'
                      ? 'bg-white dark:bg-gray-600 shadow-md'
                      : 'hover:bg-gray-300 dark:hover:bg-gray-600'
                  }`}
                  title="List View"
                >
                  <List className={`w-5 h-5 ${viewMode === 'list' ? currentTheme.text : 'text-gray-600 dark:text-gray-300'}`} />
                </button>
              </div>
              
              {/* Theme Selector */}
              <div className="relative">
                <button
                  onClick={() => setShowThemeSelector(!showThemeSelector)}
                  className="p-3 rounded-lg bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 shadow-md hover:shadow-lg transition-all duration-200"
                  title="Change Theme"
                >
                  <Palette className={`w-5 h-5 ${currentTheme.text}`} />
                </button>
                {showThemeSelector && (
                  <div className="absolute right-0 mt-2 bg-white dark:bg-gray-800 rounded-lg shadow-xl border border-gray-200 dark:border-gray-700 p-2 z-50 min-w-[160px]">
                    <div className="text-xs font-semibold text-gray-500 dark:text-gray-400 px-3 py-2">
                      SELECT THEME
                    </div>
                    {(['blue', 'purple', 'green', 'orange'] as const).map((t) => (
                      <button
                        key={t}
                        onClick={() => {
                          setTheme(t);
                          setShowThemeSelector(false);
                          showNotification('success', 'Theme changed', `Switched to ${t} theme`);
                        }}
                        className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-all duration-200 ${
                          theme === t
                            ? 'bg-gray-100 dark:bg-gray-700'
                            : 'hover:bg-gray-50 dark:hover:bg-gray-700'
                        }`}
                      >
                        <div className={`w-4 h-4 rounded-full ${themeColors[t].primary.split(' ')[0]}`} />
                        <span className="text-sm font-medium text-gray-900 dark:text-white capitalize">
                          {t}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
              
              <button
                onClick={() => setIsDarkMode(!isDarkMode)}
                className="p-3 rounded-lg bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 shadow-md hover:shadow-lg transition-all duration-200"
              >
                {isDarkMode ? <Sun className="w-5 h-5 text-yellow-400" /> : <Moon className="w-5 h-5 text-gray-700" />}
              </button>
              
              {/* Help Button */}
              <button
                onClick={() => setShowHelpModal(true)}
                className="p-3 rounded-lg bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 shadow-md hover:shadow-lg transition-all duration-200"
                title="Keyboard Shortcuts (Press ?)"
              >
                <HelpCircle className="w-5 h-5 text-gray-700 dark:text-gray-300" />
              </button>
            </div>
            )}
          </div>
          
          {currentPage === 'bookmarks' && (
            <>
            <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                ref={searchInputRef}
                type="text"
                placeholder="Search bookmarks... (Ctrl+K)"
                className="w-full pl-12 pr-4 py-3 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none shadow-md text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <div className="relative">
              <Filter className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5 pointer-events-none" />
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="pl-12 pr-8 py-3 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none shadow-md text-gray-900 dark:text-white appearance-none cursor-pointer"
              >
                {categories.map(category => (
                  <option key={category} value={category}>
                    {category.charAt(0).toUpperCase() + category.slice(1)}
                  </option>
                ))}
              </select>
            </div>
            
            <button
              onClick={() => setAdvancedFiltersOpen(!advancedFiltersOpen)}
              className={`px-5 py-3 rounded-lg shadow-md transition-all duration-200 font-medium whitespace-nowrap ${
                advancedFiltersOpen
                  ? `${currentTheme.primary} text-white`
                  : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-600'
              }`}
            >
              Advanced Filters
            </button>
          </div>
          
          {/* Advanced Filters Panel */}
          {advancedFiltersOpen && (
            <div className="mt-4 p-6 bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 shadow-lg">
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">Advanced Filters</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {/* Multiple Category Selection */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Categories (Multi-select)
                  </label>
                  <div className="space-y-2 max-h-40 overflow-y-auto p-2 border border-gray-200 dark:border-gray-700 rounded-lg">
                    {categories.filter(c => c !== 'all').map(cat => (
                      <label key={cat} className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={selectedCategories.includes(cat)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedCategories([...selectedCategories, cat]);
                            } else {
                              setSelectedCategories(selectedCategories.filter(c => c !== cat));
                            }
                          }}
                          className="w-4 h-4 rounded accent-purple-600"
                        />
                        <span className="text-sm text-gray-900 dark:text-white capitalize">{cat}</span>
                      </label>
                    ))}
                  </div>
                </div>
                
                {/* Has Local File Filter */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    File Options
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer p-3 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700">
                    <input
                      type="checkbox"
                      checked={showOnlyWithFiles}
                      onChange={(e) => setShowOnlyWithFiles(e.target.checked)}
                      className="w-4 h-4 rounded accent-purple-600"
                    />
                    <span className="text-sm text-gray-900 dark:text-white">Only show bookmarks with local files</span>
                  </label>
                </div>
                
                {/* Date Range (Placeholder for future) */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Date Range (Coming Soon)
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="date"
                      value={dateRange.start}
                      onChange={(e) => setDateRange({ ...dateRange, start: e.target.value })}
                      className="px-3 py-2 bg-gray-100 dark:bg-gray-900 border border-gray-300 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none text-sm text-gray-900 dark:text-white opacity-50 cursor-not-allowed"
                      disabled
                    />
                    <input
                      type="date"
                      value={dateRange.end}
                      onChange={(e) => setDateRange({ ...dateRange, end: e.target.value })}
                      className="px-3 py-2 bg-gray-100 dark:bg-gray-900 border border-gray-300 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none text-sm text-gray-900 dark:text-white opacity-50 cursor-not-allowed"
                      disabled
                    />
                  </div>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Requires createdAt field in bookmarks</p>
                </div>
              </div>
              
              <div className="flex gap-2 mt-4">
                <button
                  onClick={() => {
                    setSelectedCategories([]);
                    setShowOnlyWithFiles(false);
                    setDateRange({ start: '', end: '' });
                    showNotification('info', 'Filters cleared', 'All advanced filters have been reset');
                  }}
                  className="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-all duration-200 font-medium"
                >
                  Clear Filters
                </button>
              </div>
            </div>
          )}
          </>
          )}
        </header>

        {currentPage === 'bookmarks' ? (
          <>
            <AddBookmarkForm
              isOpen={isAddDrawerOpen}
              onClose={() => setIsAddDrawerOpen(false)}
              onAdd={async (bookmark) => {
                await addBookmark(bookmark);
              }}
            />
            
            {viewMode === 'grid' ? (
              <BookmarkGrid 
                bookmarks={filteredBookmarks} 
                onDelete={deleteBookmark}
                onUpdate={updateBookmark}
                isDarkMode={isDarkMode}
                theme={theme}
              />
            ) : (
              <BookmarkList 
                bookmarks={filteredBookmarks} 
                onDelete={deleteBookmark}
                onUpdate={updateBookmark}
                isDarkMode={isDarkMode}
                theme={theme}
              />
            )}
          </>
        ) : (
          <TaskManager isDarkMode={isDarkMode} theme={theme} />
        )}
        
        {/* Keyboard Shortcuts Help Modal */}
        <KeyboardShortcutsModal
          isOpen={showHelpModal}
          onClose={() => setShowHelpModal(false)}
        />
      </div>
    </div>
  );
}

export default App;