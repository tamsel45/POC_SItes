import React from 'react';
import { render, screen } from '@testing-library/react';
import App from './App';

test('renders bookmark manager heading', () => {
  render(<App />);
  const heading = screen.getByRole('heading', { name: /bookmark manager/i });
  expect(heading).toBeInTheDocument();
});
