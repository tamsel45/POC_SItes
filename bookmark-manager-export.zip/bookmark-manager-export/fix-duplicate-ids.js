const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, 'src', 'data', 'bookmarks.json');

// Read the bookmarks file
const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));

// Track seen IDs and fix duplicates
const seenIds = new Set();
let fixedCount = 0;

data.bookmarks = data.bookmarks.map(bookmark => {
  if (seenIds.has(bookmark.id)) {
    // Generate new unique ID
    const newId = Date.now() + Math.random();
    console.log(`Fixed duplicate ID ${bookmark.id} -> ${newId} for: ${bookmark.title}`);
    fixedCount++;
    return { ...bookmark, id: newId };
  }
  seenIds.add(bookmark.id);
  return bookmark;
});

// Write back to file
fs.writeFileSync(filePath, JSON.stringify(data, null, 2));

console.log(`\n✅ Fixed ${fixedCount} duplicate IDs`);
console.log(`Total bookmarks: ${data.bookmarks.length}`);
console.log(`Unique IDs: ${seenIds.size}`);
