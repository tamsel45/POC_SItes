const express = require('express');
const cors = require('cors');
const fs = require('node:fs');
const path = require('node:path');

const app = express();
const port = 3001; // React app runs on 3000 by default

app.use(cors());
app.use(express.json());

const BOOKMARKS_FILE = path.join(__dirname, '../src/data/bookmarks.json');

// Ensure bookmarks.json exists
if (!fs.existsSync(BOOKMARKS_FILE)) {
  fs.writeFileSync(BOOKMARKS_FILE, JSON.stringify({ bookmarks: [] }, null, 2));
}

// Get all bookmarks
app.get('/api/bookmarks', (req, res) => {
  try {
    const data = fs.readFileSync(BOOKMARKS_FILE, 'utf8');
    const bookmarks = JSON.parse(data);
    res.json(bookmarks);
  } catch (error) {
    console.error('Error reading bookmarks:', error);
    res.status(500).json({ error: 'Error reading bookmarks' });
  }
});

// Add a bookmark
app.post('/api/bookmarks', (req, res) => {
  try {
    const data = fs.readFileSync(BOOKMARKS_FILE, 'utf8');
    const { bookmarks } = JSON.parse(data);
    const newBookmark = { ...req.body, id: Date.now() };
    bookmarks.push(newBookmark);
    fs.writeFileSync(BOOKMARKS_FILE, JSON.stringify({ bookmarks }, null, 2));
    res.json(newBookmark);
  } catch (error) {
    console.error('Error adding bookmark:', error);
    res.status(500).json({ error: 'Error adding bookmark' });
  }
});

// Update a bookmark
app.put('/api/bookmarks/:id', (req, res) => {
  try {
    console.log('PUT /api/bookmarks/:id called');
    console.log('ID:', req.params.id);
    console.log('Body:', req.body);
    
    const data = fs.readFileSync(BOOKMARKS_FILE, 'utf8');
    const { bookmarks } = JSON.parse(data);
    const bookmarkId = Number.parseInt(req.params.id, 10);
    const index = bookmarks.findIndex(bookmark => bookmark.id === bookmarkId);
    
    console.log('Found bookmark at index:', index);
    
    if (index === -1) {
      console.error('Bookmark not found:', bookmarkId);
      return res.status(404).json({ error: 'Bookmark not found' });
    }
    
    bookmarks[index] = { ...bookmarks[index], ...req.body, id: bookmarkId };
    console.log('Updated bookmark:', bookmarks[index]);
    
    fs.writeFileSync(BOOKMARKS_FILE, JSON.stringify({ bookmarks }, null, 2));
    console.log('Saved to file successfully');
    
    res.json(bookmarks[index]);
  } catch (error) {
    console.error('Error updating bookmark:', error);
    res.status(500).json({ error: 'Error updating bookmark' });
  }
});

// Import bookmarks (merge with existing)
app.post('/api/bookmarks/import', (req, res) => {
  try {
    console.log('POST /api/bookmarks/import called');
    const data = fs.readFileSync(BOOKMARKS_FILE, 'utf8');
    const { bookmarks } = JSON.parse(data);
    const newBookmarks = req.body.bookmarks || [];
    
    // Merge new bookmarks with existing, avoid duplicates by URL
    const existingUrls = new Set(bookmarks.map(b => b.url));
    const uniqueNewBookmarks = newBookmarks.filter(b => !existingUrls.has(b.url));
    
    // Add IDs to new bookmarks (using integer IDs)
    let counter = 0;
    const bookmarksWithIds = uniqueNewBookmarks.map(b => ({
      ...b,
      id: Date.now() + counter++
    }));
    
    const allBookmarks = [...bookmarks, ...bookmarksWithIds];
    fs.writeFileSync(BOOKMARKS_FILE, JSON.stringify({ bookmarks: allBookmarks }, null, 2));
    
    console.log(`Imported ${bookmarksWithIds.length} new bookmarks`);
    res.json({ success: true, count: bookmarksWithIds.length });
  } catch (error) {
    console.error('Error importing bookmarks:', error);
    res.status(500).json({ error: 'Error importing bookmarks' });
  }
});

// Delete a bookmark
app.delete('/api/bookmarks/:id', (req, res) => {
  try {
    const data = fs.readFileSync(BOOKMARKS_FILE, 'utf8');
    const { bookmarks } = JSON.parse(data);
    const updatedBookmarks = bookmarks.filter(
      bookmark => bookmark.id !== Number.parseInt(req.params.id, 10)
    );
    fs.writeFileSync(BOOKMARKS_FILE, JSON.stringify({ bookmarks: updatedBookmarks }, null, 2));
    res.json({ success: true });
  } catch (error) {
    console.error('Error deleting bookmark:', error);
    res.status(500).json({ error: 'Error deleting bookmark' });
  }
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});