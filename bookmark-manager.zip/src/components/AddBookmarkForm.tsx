import { useState, useEffect } from 'react';
import { Plus, X, FileText, Link, Tag, FolderOpen, XCircle, Save } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bookmark } from '../types';
import { useNotification } from '../contexts/NotificationContext';

interface AddBookmarkFormProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (bookmark: Bookmark) => Promise<void> | void;
}

const AddBookmarkForm = ({ isOpen, onClose, onAdd }: AddBookmarkFormProps) => {
  const { showNotification } = useNotification();
  const [formData, setFormData] = useState({
    title: '',
    url: '',
    category: '',
    localPath: ''
  });

  useEffect(() => {
    if (!isOpen) {
      setFormData({ title: '', url: '', category: '', localPath: '' });
    }
  }, [isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await onAdd(formData as Bookmark);
      setFormData({ title: '', url: '', category: '', localPath: '' });
      showNotification('success', 'Bookmark added', 'Your new bookmark has been saved successfully.');
      onClose();
    } catch (err) {
      console.error('Add bookmark failed:', err);
      showNotification('error', 'Failed to add bookmark', 'An error occurred. Please check the console for details.');
    }
  };

  return (
    <>
      <AnimatePresence>
        {isOpen && (
          <>
            {/* Overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={onClose}
              className="fixed inset-0 z-40 bg-black/50"
            />

            {/* Drawer panel */}
            <motion.aside
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'tween' }}
              className="fixed right-0 top-0 z-50 h-full w-full sm:w-[420px] bg-white dark:bg-gray-900 shadow-xl flex flex-col"
              onClick={(e) => e.stopPropagation()}
            >
              <header className="flex items-center justify-between p-4 bg-blue-900 text-white">
                <div className="flex items-center gap-3">
                  <div className="p-1.5 rounded bg-blue-950/50">
                    <Plus className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold">Add Bookmark</h3>
                    <p className="text-xs opacity-90">Create a new bookmark</p>
                  </div>
                </div>
                <button onClick={onClose} aria-label="Close" className="p-2 rounded hover:bg-blue-950/30">
                  <X className="w-5 h-5 text-white" />
                </button>
              </header>

              <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-5">
                <div>
                  <label htmlFor="title" className="flex items-center gap-2 text-sm font-semibold mb-2 text-gray-700 dark:text-gray-200">
                    <FileText className="w-4 h-4" />
                    Title
                  </label>
                  <input
                    id="title"
                    type="text"
                    required
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none text-gray-900 dark:text-white"
                  />
                </div>

                <div>
                  <label htmlFor="url" className="flex items-center gap-2 text-sm font-semibold mb-2 text-gray-700 dark:text-gray-200">
                    <Link className="w-4 h-4" />
                    URL
                  </label>
                  <input
                    id="url"
                    type="url"
                    required
                    value={formData.url}
                    onChange={(e) => setFormData({ ...formData, url: e.target.value })}
                    className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none text-gray-900 dark:text-white"
                  />
                </div>

                <div>
                  <label htmlFor="category" className="flex items-center gap-2 text-sm font-semibold mb-2 text-gray-700 dark:text-gray-200">
                    <Tag className="w-4 h-4" />
                    Category
                  </label>
                  <input
                    id="category"
                    type="text"
                    required
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value.toLowerCase() })}
                    className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none text-gray-900 dark:text-white"
                  />
                </div>

                <div>
                  <label htmlFor="localPath" className="flex items-center gap-2 text-sm font-semibold mb-2 text-gray-700 dark:text-gray-200">
                    <FolderOpen className="w-4 h-4" />
                    Local File Path (Optional)
                  </label>
                  <input
                    id="localPath"
                    type="text"
                    value={formData.localPath}
                    onChange={(e) => setFormData({ ...formData, localPath: e.target.value })}
                    className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400"
                    placeholder="C:\\path\\to\\your\\file.txt"
                  />
                </div>
              </form>

              {/* Sticky footer */}
              <div className="border-t border-gray-200 dark:border-gray-700 p-4 bg-white dark:bg-gray-900 sticky bottom-0">
                <div className="flex gap-3">
                  <button
                    onClick={() => onClose()}
                    type="button"
                    className="flex items-center justify-center gap-2 flex-1 px-4 py-3 bg-gray-200 dark:bg-gray-800 text-gray-800 dark:text-gray-200 rounded-lg hover:bg-gray-300 transition-all duration-150"
                  >
                    <XCircle className="w-4 h-4" />
                    Cancel
                  </button>
                  <button
                    onClick={(e) => {
                      // Submit by invoking the form's submit
                      const form = (e.currentTarget as HTMLElement).closest('aside')?.querySelector('form') as HTMLFormElement | null;
                      form?.requestSubmit();
                    }}
                    type="button"
                    className="flex items-center justify-center gap-2 flex-1 px-4 py-3 bg-blue-900 text-white rounded-lg hover:bg-blue-950 transition-all duration-150"
                  >
                    <Save className="w-4 h-4" />
                    Save Bookmark
                  </button>
                </div>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  );
};

export default AddBookmarkForm;