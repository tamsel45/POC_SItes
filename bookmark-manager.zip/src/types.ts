export interface Bookmark {
  id?: number;
  title: string;
  url: string;
  category: string;
  localPath?: string;
}