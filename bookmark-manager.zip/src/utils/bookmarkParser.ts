import { Bookmark } from '../types';

export const parseBookmarkHTML = (htmlContent: string): Bookmark[] => {
  const parser = new DOMParser();
  const doc = parser.parseFromString(htmlContent, 'text/html');
  const bookmarks: Bookmark[] = [];
  
  // Find all <A> tags (bookmark links)
  const links = doc.querySelectorAll('a');
  
  for (const link of links) {
    const url = link.getAttribute('href');
    const title = link.textContent?.trim();
    
    if (url && title) {
      // Try to determine category from folder structure
      let category = 'imported';
      const dt = link.closest('dt');
      if (dt) {
        const parent = dt.parentElement;
        if (parent) {
          const h3 = parent.querySelector('h3');
          if (h3) {
            category = h3.textContent?.trim().toLowerCase() || 'imported';
          }
        }
      }
      
      bookmarks.push({
        title,
        url,
        category,
        localPath: '',
      });
    }
  }
  
  return bookmarks;
};

export const parseBookmarkJSON = (jsonContent: string): Bookmark[] => {
  try {
    const data = JSON.parse(jsonContent);
    
    // Handle Chrome/Edge JSON format
    if (data.roots) {
      const bookmarks: Bookmark[] = [];
      
      const processNode = (node: any, category: string = 'imported') => {
        if (node.type === 'url') {
          bookmarks.push({
            title: node.name || 'Untitled',
            url: node.url,
            category: category.toLowerCase(),
            localPath: '',
          });
        } else if (node.type === 'folder' && node.children) {
          const folderName = node.name || category;
          for (const child of node.children) {
            processNode(child, folderName);
          }
        }
      };
      
      // Process bookmark bar, other bookmarks, and mobile bookmarks
      if (data.roots.bookmark_bar) {
        processNode(data.roots.bookmark_bar, 'bookmark bar');
      }
      if (data.roots.other) {
        processNode(data.roots.other, 'other');
      }
      if (data.roots.synced) {
        processNode(data.roots.synced, 'mobile');
      }
      
      return bookmarks;
    }
    
    // Handle simple JSON array format
    if (Array.isArray(data)) {
      return data.map(item => ({
        title: item.title || item.name || 'Untitled',
        url: item.url,
        category: item.category || 'imported',
        localPath: item.localPath || '',
      }));
    }
    
    return [];
  } catch (error) {
    console.error('Error parsing JSON:', error);
    throw new Error('Invalid JSON format');
  }
};
