import { useEffect } from 'react';

export interface KeyboardShortcuts {
  onNewBookmark?: () => void;
  onSearch?: () => void;
  onToggleView?: () => void;
  onToggleDarkMode?: () => void;
  onEscape?: () => void;
  onShowHelp?: () => void;
  onSwitchPage?: () => void;
  onToggleTheme?: () => void;
  onToggleFilters?: () => void;
  onFocusSearch?: () => void;
  onCloseModal?: () => void;
}

export const useKeyboardShortcuts = (shortcuts: KeyboardShortcuts) => {
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      // Ignore if user is typing in an input/textarea
      const target = event.target as HTMLElement;
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable) {
        // Allow Escape even in inputs
        if (event.key === 'Escape' && shortcuts.onEscape) {
          shortcuts.onEscape();
          return;
        }
        return;
      }

      // Ctrl/Cmd + N - New bookmark
      if ((event.ctrlKey || event.metaKey) && event.key === 'n' && shortcuts.onNewBookmark) {
        event.preventDefault();
        shortcuts.onNewBookmark();
      }

      // Ctrl/Cmd + K - Focus search
      if ((event.ctrlKey || event.metaKey) && event.key === 'k' && shortcuts.onSearch) {
        event.preventDefault();
        shortcuts.onSearch();
      }

      // G - Grid view, L - List view
      if (event.key === 'g' && shortcuts.onToggleView) {
        shortcuts.onToggleView();
      }

      // D - Toggle dark mode
      if (event.key === 'd' && shortcuts.onToggleDarkMode) {
        shortcuts.onToggleDarkMode();
      }

      // Escape - Close modals/drawers
      if (event.key === 'Escape' && shortcuts.onEscape) {
        shortcuts.onEscape();
      }

      // ? - Show keyboard shortcuts help
      if (event.key === '?' && shortcuts.onShowHelp) {
        event.preventDefault();
        shortcuts.onShowHelp();
      }

      // T - Switch between Bookmarks and Tasks
      if (event.key === 't' && shortcuts.onSwitchPage) {
        shortcuts.onSwitchPage();
      }

      // F - Toggle filters
      if (event.key === 'f' && shortcuts.onToggleFilters) {
        shortcuts.onToggleFilters();
      }
    };

    globalThis.addEventListener('keydown', handleKeyDown);
    return () => globalThis.removeEventListener('keydown', handleKeyDown);
  }, [shortcuts]);
};
