export interface Bookmark {
  id?: number;
  title: string;
  url: string;
  category: string;
  localPath?: string;
}

export type TaskPriority = 'low' | 'medium' | 'high' | 'urgent';
export type TaskStatus = 'pending' | 'in-progress' | 'completed' | 'carry-forward';

export interface Task {
  id?: number;
  title: string;
  description?: string;
  priority: TaskPriority;
  status: TaskStatus;
  dueDate?: string;
  assignedTo?: string; // 'me' or colleague name
  remindManager: boolean; // If true, need to remind manager daily
  createdDate: string;
  completedDate?: string;
  notes?: string;
  tags?: string[]; // Tags like GenAI, Containerization, DevOps, etc.
}