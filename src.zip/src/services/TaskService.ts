import { Task } from '../types';

const API_BASE_URL = 'http://localhost:3001/api';

export const TaskService = {
  async getAllTasks(): Promise<Task[]> {
    try {
      const response = await fetch(`${API_BASE_URL}/tasks`);
      const data = await response.json();
      return data.tasks || [];
    } catch (error) {
      console.error('Error fetching tasks:', error);
      return [];
    }
  },

  async addTask(task: Omit<Task, 'id'>): Promise<Task | null> {
    try {
      console.log('TaskService: Sending task to server:', task);
      const response = await fetch(`${API_BASE_URL}/tasks`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(task),
      });
      console.log('TaskService: Response status:', response.status);
      const result = await response.json();
      console.log('TaskService: Response data:', result);
      return result;
    } catch (error) {
      console.error('TaskService: Error adding task:', error);
      return null;
    }
  },

  async updateTask(id: number, task: Task): Promise<Task | null> {
    try {
      const response = await fetch(`${API_BASE_URL}/tasks/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(task),
      });
      return await response.json();
    } catch (error) {
      console.error('Error updating task:', error);
      return null;
    }
  },

  async deleteTask(id: number): Promise<boolean> {
    try {
      const response = await fetch(`${API_BASE_URL}/tasks/${id}`, {
        method: 'DELETE',
      });
      const result = await response.json();
      return result.success;
    } catch (error) {
      console.error('Error deleting task:', error);
      return false;
    }
  },

  async carryForwardTasks(): Promise<boolean> {
    try {
      const response = await fetch(`${API_BASE_URL}/tasks/carry-forward`, {
        method: 'POST',
      });
      const result = await response.json();
      return result.success;
    } catch (error) {
      console.error('Error carrying forward tasks:', error);
      return false;
    }
  },
};
