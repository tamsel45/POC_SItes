import { useState } from 'react';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon } from 'lucide-react';
import { Task, TaskPriority, TaskStatus } from '../types';

interface TaskCalendarViewProps {
  tasks: Task[];
  onEdit: (task: Task) => void;
  onDelete: (id: number) => void;
  onStatusChange: (task: Task, status: TaskStatus) => void;
  getPriorityColor: (priority: TaskPriority) => string;
  getStatusColor: (status: TaskStatus) => string;
}

const TaskCalendarView = ({ tasks, onEdit, onDelete, onStatusChange, getPriorityColor, getStatusColor }: TaskCalendarViewProps) => {
  const [currentDate, setCurrentDate] = useState(new Date());

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const firstDayOfMonth = new Date(year, month, 1);
  const lastDayOfMonth = new Date(year, month + 1, 0);
  const startDate = new Date(firstDayOfMonth);
  startDate.setDate(startDate.getDate() - startDate.getDay()); // Start from Sunday
  
  const endDate = new Date(lastDayOfMonth);
  endDate.setDate(endDate.getDate() + (6 - endDate.getDay())); // End on Saturday

  const weeks: Date[][] = [];
  let currentWeek: Date[] = [];
  const iterDate = new Date(startDate);

  while (iterDate <= endDate) {
    currentWeek.push(new Date(iterDate));
    if (currentWeek.length === 7) {
      weeks.push(currentWeek);
      currentWeek = [];
    }
    iterDate.setDate(iterDate.getDate() + 1);
  }

  const getTasksForDate = (date: Date) => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const dateStr = `${year}-${month}-${day}`;
    
    return tasks.filter(task => {
      if (task.dueDate) {
        // Normalize the task date to YYYY-MM-DD format without timezone conversion
        const taskDateStr = task.dueDate.split('T')[0];
        return taskDateStr === dateStr;
      }
      return false;
    });
  };

  const goToPreviousMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const goToNextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  const goToToday = () => {
    setCurrentDate(new Date());
  };

  const isToday = (date: Date) => {
    const today = new Date();
    return date.toDateString() === today.toDateString();
  };

  const isCurrentMonth = (date: Date) => {
    return date.getMonth() === month;
  };

  const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'];
  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-700">
        <div className="flex items-center gap-3">
          <CalendarIcon className="w-6 h-6 text-blue-600 dark:text-blue-400" />
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
            {monthNames[month]} {year}
          </h2>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={goToPreviousMonth}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
            title="Previous Month"
          >
            <ChevronLeft className="w-5 h-5 text-gray-600 dark:text-gray-400" />
          </button>
          <button
            onClick={goToToday}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-medium transition-colors"
          >
            Today
          </button>
          <button
            onClick={goToNextMonth}
            className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
            title="Next Month"
          >
            <ChevronRight className="w-5 h-5 text-gray-600 dark:text-gray-400" />
          </button>
        </div>
      </div>

      {/* Calendar Grid */}
      <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
        {/* Day Names */}
        <div className="grid grid-cols-7 bg-gray-50 dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700">
          {dayNames.map(day => (
            <div
              key={day}
              className="p-3 text-center text-sm font-semibold text-gray-700 dark:text-gray-300 border-r border-gray-200 dark:border-gray-700 last:border-r-0"
            >
              {day}
            </div>
          ))}
        </div>

        {/* Weeks */}
        {weeks.map((week, weekIndex) => (
          <div key={weekIndex} className="grid grid-cols-7 border-b border-gray-200 dark:border-gray-700 last:border-b-0">
            {week.map((date, dayIndex) => {
              const dayTasks = getTasksForDate(date);
              const today = isToday(date);
              const currentMonthDay = isCurrentMonth(date);

              return (
                <div
                  key={dayIndex}
                  className={`min-h-[120px] p-2 border-r border-gray-200 dark:border-gray-700 last:border-r-0 ${
                    !currentMonthDay ? 'bg-gray-50 dark:bg-gray-900/50' : ''
                  } ${today ? 'bg-blue-50 dark:bg-blue-900/20' : ''}`}
                >
                  {/* Date Number */}
                  <div className={`text-sm font-semibold mb-2 ${
                    today 
                      ? 'text-blue-600 dark:text-blue-400' 
                      : currentMonthDay
                        ? 'text-gray-900 dark:text-white'
                        : 'text-gray-400 dark:text-gray-600'
                  }`}>
                    {date.getDate()}
                    {today && (
                      <span className="ml-1 text-xs bg-blue-600 text-white px-1.5 py-0.5 rounded-full">
                        Today
                      </span>
                    )}
                  </div>

                  {/* Tasks */}
                  <div className="space-y-1">
                    {dayTasks.slice(0, 2).map(task => (
                      <div
                        key={task.id}
                        className="text-xs p-1.5 rounded border cursor-pointer hover:shadow-sm transition-shadow"
                        style={{
                          backgroundColor: task.priority === 'urgent' ? '#fee2e2' :
                                         task.priority === 'high' ? '#fed7aa' :
                                         task.priority === 'medium' ? '#fef3c7' :
                                         '#dcfce7',
                          borderColor: task.priority === 'urgent' ? '#fca5a5' :
                                      task.priority === 'high' ? '#fdba74' :
                                      task.priority === 'medium' ? '#fde047' :
                                      '#86efac',
                        }}
                        onClick={() => onEdit(task)}
                        title={task.title}
                      >
                        <div className="font-medium truncate text-gray-900">
                          {task.title}
                        </div>
                        {task.tags && task.tags.length > 0 && (
                          <div className="flex flex-wrap gap-0.5 mt-0.5">
                            {task.tags.slice(0, 2).map(tag => (
                              <span
                                key={tag}
                                className="text-[10px] px-1 py-0.5 bg-white/60 rounded"
                              >
                                {tag}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                    {dayTasks.length > 2 && (
                      <div className="text-xs text-gray-500 dark:text-gray-400 font-medium pl-1">
                        +{dayTasks.length - 2} more
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        ))}
      </div>

      {/* Legend */}
      <div className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-700">
        <h3 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">Priority Legend:</h3>
        <div className="flex flex-wrap gap-3">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded border" style={{ backgroundColor: '#fee2e2', borderColor: '#fca5a5' }} />
            <span className="text-xs text-gray-600 dark:text-gray-400">Urgent</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded border" style={{ backgroundColor: '#fed7aa', borderColor: '#fdba74' }} />
            <span className="text-xs text-gray-600 dark:text-gray-400">High</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded border" style={{ backgroundColor: '#fef3c7', borderColor: '#fde047' }} />
            <span className="text-xs text-gray-600 dark:text-gray-400">Medium</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded border" style={{ backgroundColor: '#dcfce7', borderColor: '#86efac' }} />
            <span className="text-xs text-gray-600 dark:text-gray-400">Low</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TaskCalendarView;
