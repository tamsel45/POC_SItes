import { useDroppable } from '@dnd-kit/core';
import { ReactNode } from 'react';

interface DroppableColumnProps {
  id: string;
  children: ReactNode;
  title: string;
  count: number;
  color: string;
}

const DroppableColumn = ({ id, children, title, count, color }: DroppableColumnProps) => {
  const { setNodeRef, isOver } = useDroppable({
    id: id,
  });

  const colorClasses = {
    gray: {
      bg: 'bg-gray-50 dark:bg-gray-900',
      text: 'text-gray-700 dark:text-gray-300',
      dot: 'bg-gray-500',
      border: 'border-gray-300 dark:border-gray-600'
    },
    blue: {
      bg: 'bg-blue-50 dark:bg-blue-900/20',
      text: 'text-blue-700 dark:text-blue-300',
      dot: 'bg-blue-500',
      border: 'border-blue-300 dark:border-blue-600'
    },
    green: {
      bg: 'bg-green-50 dark:bg-green-900/20',
      text: 'text-green-700 dark:text-green-300',
      dot: 'bg-green-500',
      border: 'border-green-300 dark:border-green-600'
    },
    purple: {
      bg: 'bg-purple-50 dark:bg-purple-900/20',
      text: 'text-purple-700 dark:text-purple-300',
      dot: 'bg-purple-500',
      border: 'border-purple-300 dark:border-purple-600'
    },
  };

  const currentColor = colorClasses[color as keyof typeof colorClasses] || colorClasses.gray;

  return (
    <div
      ref={setNodeRef}
      className={`${currentColor.bg} rounded-lg p-3 transition-all ${
        isOver ? `ring-2 ${currentColor.border} ring-offset-2` : ''
      }`}
    >
      <h4 className={`font-semibold text-sm ${currentColor.text} mb-3 flex items-center gap-2`}>
        <div className={`w-2 h-2 rounded-full ${currentColor.dot}`}></div>
        {title} ({count})
      </h4>
      {children}
    </div>
  );
};

export default DroppableColumn;
