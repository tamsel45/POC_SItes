import { useState, useMemo } from 'react';
import { Trash2, FolderOpen, Edit2, Copy, Check, ExternalLink, CheckSquare, Tag, X, ArrowUpDown, ArrowUp, ArrowDown } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bookmark } from '../types';
import { useNotification } from '../contexts/NotificationContext';
import FilePathModal from './FilePathModal';

interface BookmarkListProps {
  bookmarks: Bookmark[];
  onDelete: (id: number) => void;
  onUpdate: (id: number, bookmark: Bookmark) => Promise<void>;
  isDarkMode: boolean;
  theme: 'blue' | 'purple' | 'green' | 'orange';
}

type SortField = 'title' | 'category' | null;
type SortDirection = 'asc' | 'desc';

const BookmarkList = ({ bookmarks, onDelete, onUpdate, isDarkMode, theme }: BookmarkListProps) => {
  const { showNotification } = useNotification();
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editFormData, setEditFormData] = useState<Bookmark | null>(null);
  const [copiedId, setCopiedId] = useState<number | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
  const [showBulkUpdate, setShowBulkUpdate] = useState(false);
  const [bulkCategory, setBulkCategory] = useState('');
  const [filePathToShow, setFilePathToShow] = useState<string | null>(null);
  const [sortField, setSortField] = useState<SortField>(null);
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc');

  const themeColors = {
    blue: 'text-blue-600 dark:text-blue-400',
    purple: 'text-purple-600 dark:text-purple-400',
    green: 'text-green-600 dark:text-green-400',
    orange: 'text-orange-600 dark:text-orange-400',
  };

  const handleEdit = (bookmark: Bookmark, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(bookmark.id || null);
    setEditFormData({ ...bookmark });
  };

  const handleCancelEdit = (e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(null);
    setEditFormData(null);
  };

  const handleSaveEdit = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (editingId && editFormData) {
      await onUpdate(editingId, editFormData);
      setEditingId(null);
      setEditFormData(null);
      showNotification('success', 'Bookmark updated', 'Your changes have been saved successfully.');
    }
  };

  const handleCopyLink = async (url: string, id: number) => {
    try {
      await navigator.clipboard.writeText(url);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    } catch (error) {
      console.error('Failed to copy:', error);
    }
  };

  const toggleSelection = (id: number, e: React.MouseEvent) => {
    e.stopPropagation();
    const newSelected = new Set(selectedIds);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedIds(newSelected);
  };

  const handleBulkCategoryUpdate = async () => {
    if (!bulkCategory.trim()) {
      showNotification('warning', 'Category required', 'Please enter a category name before updating.');
      return;
    }

    let successCount = 0;
    let errorCount = 0;

    for (const id of Array.from(selectedIds)) {
      const bookmark = sortedBookmarks.find(b => b.id === id);
      if (bookmark && bookmark.id) {
        try {
          await onUpdate(bookmark.id, { ...bookmark, category: bulkCategory.toLowerCase() });
          successCount++;
        } catch (error) {
          console.error(`Failed to update bookmark ${bookmark.id}:`, error);
          errorCount++;
        }
      }
    }

    setSelectedIds(new Set());
    setShowBulkUpdate(false);
    setBulkCategory('');
    
    if (errorCount > 0) {
      showNotification('warning', 'Partial update', `Updated ${successCount} bookmarks. Failed to update ${errorCount} bookmarks.`);
    } else {
      showNotification('success', 'Bulk update successful', `Successfully updated ${successCount} bookmarks to category: ${bulkCategory}`);
    }
  };

  const handleSelectAll = () => {
    const newSelected = new Set(selectedIds);
    const allSelected = bookmarks.every(b => newSelected.has(b.id || 0));
    
    if (allSelected) {
      setSelectedIds(new Set());
    } else {
      bookmarks.forEach(b => newSelected.add(b.id || 0));
      setSelectedIds(newSelected);
    }
  };

  const handleRowClick = (url: string, e: React.MouseEvent) => {
    const target = e.target as HTMLElement;
    if (target.tagName === 'BUTTON' || target.tagName === 'INPUT' || target.closest('button') || target.closest('input')) {
      return;
    }
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      // Toggle direction if same field
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      // New field, default to ascending
      setSortField(field);
      setSortDirection('asc');
    }
  };

  // Sort bookmarks based on current sort settings
  const sortedBookmarks = useMemo(() => {
    if (!sortField) return bookmarks;

    return [...bookmarks].sort((a, b) => {
      let comparison = 0;

      if (sortField === 'title') {
        comparison = a.title.localeCompare(b.title);
      } else if (sortField === 'category') {
        comparison = a.category.localeCompare(b.category);
      }

      return sortDirection === 'asc' ? comparison : -comparison;
    });
  }, [bookmarks, sortField, sortDirection]);

  const allSelected = sortedBookmarks.length > 0 && sortedBookmarks.every(b => selectedIds.has(b.id || 0));

  const getSortIcon = (field: SortField) => {
    if (sortField !== field) {
      return <ArrowUpDown className="w-4 h-4 opacity-40" />;
    }
    return sortDirection === 'asc' 
      ? <ArrowUp className="w-4 h-4" />
      : <ArrowDown className="w-4 h-4" />;
  };

  return (
    <div className="space-y-4">
      {/* Bulk Update Panel */}
      {selectedIds.size > 0 && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="fixed top-20 right-8 z-50 bg-white dark:bg-gray-800 p-6 rounded-xl shadow-xl border border-gray-200 dark:border-gray-700"
        >
          <div className="flex items-center gap-2 mb-3">
            <CheckSquare className={`w-5 h-5 ${themeColors[theme]}`} />
            <h3 className="text-lg font-bold text-gray-900 dark:text-white">
              {selectedIds.size} Selected
            </h3>
          </div>
          {!showBulkUpdate ? (
            <button
              onClick={() => setShowBulkUpdate(true)}
              className={`flex items-center justify-center gap-2 w-full px-4 py-2 ${theme === 'blue' ? 'bg-blue-600 hover:bg-blue-700' : theme === 'purple' ? 'bg-purple-600 hover:bg-purple-700' : theme === 'green' ? 'bg-green-600 hover:bg-green-700' : 'bg-orange-600 hover:bg-orange-700'} text-white rounded-lg transition-all duration-200 shadow-md font-medium`}
            >
              <Tag className="w-4 h-4" />
              Update Category
            </button>
          ) : (
            <div className="space-y-3">
              <div className="relative">
                <Tag className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="text"
                  value={bulkCategory}
                  onChange={(e) => setBulkCategory(e.target.value)}
                  placeholder="Enter new category"
                  className="w-full pl-10 pr-4 py-2 bg-gray-50 dark:bg-gray-900 border border-gray-300 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none text-gray-900 dark:text-white"
                />
              </div>
              <div className="flex gap-2">
                <button
                  onClick={handleBulkCategoryUpdate}
                  className="flex items-center justify-center gap-1.5 flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-all duration-200 shadow-md font-medium"
                >
                  <Check className="w-4 h-4" />
                  Apply
                </button>
                <button
                  onClick={() => {
                    setShowBulkUpdate(false);
                    setBulkCategory('');
                  }}
                  className="flex items-center justify-center gap-1.5 flex-1 px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-all duration-200 shadow-md font-medium"
                >
                  <X className="w-4 h-4" />
                  Cancel
                </button>
              </div>
              <button
                onClick={() => setSelectedIds(new Set())}
                className="flex items-center justify-center gap-1.5 w-full px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-all duration-200 shadow-md font-medium text-sm"
              >
                <X className="w-4 h-4" />
                Clear Selection
              </button>
            </div>
          )}
        </motion.div>
      )}

      {/* List View Header */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div className="grid grid-cols-12 gap-4 px-4 py-3 bg-gray-50 dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700 font-semibold text-sm text-gray-700 dark:text-gray-300">
          <div className="col-span-1 flex items-center gap-2">
            <input
              type="checkbox"
              checked={allSelected}
              onChange={handleSelectAll}
              className="w-4 h-4 rounded accent-purple-600 cursor-pointer"
            />
            <CheckSquare className="w-4 h-4" />
          </div>
          <button
            onClick={() => handleSort('title')}
            className="col-span-4 flex items-center gap-2 hover:text-gray-900 dark:hover:text-white transition-colors cursor-pointer text-left"
          >
            <span>Title</span>
            {getSortIcon('title')}
          </button>
          <div className="col-span-3">URL</div>
          <button
            onClick={() => handleSort('category')}
            className="col-span-2 flex items-center gap-2 hover:text-gray-900 dark:hover:text-white transition-colors cursor-pointer text-left"
          >
            <span>Category</span>
            {getSortIcon('category')}
          </button>
          <div className="col-span-1">File</div>
          <div className="col-span-1">Actions</div>
        </div>

        {/* List Rows */}
        <div className="divide-y divide-gray-200 dark:divide-gray-700">
          {sortedBookmarks.length === 0 ? (
            <div className="px-4 py-12 text-center text-gray-500 dark:text-gray-400">
              No bookmarks found. Add your first bookmark to get started!
            </div>
          ) : (
            sortedBookmarks.map((bookmark) => {
              const isSelected = selectedIds.has(bookmark.id || 0);
              return editingId === bookmark.id && editFormData ? (
                <div
                  key={bookmark.id}
                  className="grid grid-cols-12 gap-4 px-4 py-4 bg-gray-50 dark:bg-gray-900"
                >
                  <div className="col-span-12 grid grid-cols-12 gap-3">
                    <div className="col-span-1"></div>
                    <div className="col-span-4">
                      <input
                        type="text"
                        value={editFormData.title}
                        onChange={(e) => setEditFormData({ ...editFormData, title: e.target.value })}
                        onClick={(e) => e.stopPropagation()}
                        className="w-full px-3 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none text-sm text-gray-900 dark:text-white"
                        placeholder="Title"
                      />
                    </div>
                    <div className="col-span-3">
                      <input
                        type="text"
                        value={editFormData.url}
                        onChange={(e) => setEditFormData({ ...editFormData, url: e.target.value })}
                        onClick={(e) => e.stopPropagation()}
                        className="w-full px-3 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none text-sm text-gray-900 dark:text-white"
                        placeholder="URL"
                      />
                    </div>
                    <div className="col-span-2">
                      <input
                        type="text"
                        value={editFormData.category}
                        onChange={(e) => setEditFormData({ ...editFormData, category: e.target.value.toLowerCase() })}
                        onClick={(e) => e.stopPropagation()}
                        className="w-full px-3 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none text-sm text-gray-900 dark:text-white"
                        placeholder="Category"
                      />
                    </div>
                    <div className="col-span-2">
                      <input
                        type="text"
                        value={editFormData.localPath || ''}
                        onChange={(e) => setEditFormData({ ...editFormData, localPath: e.target.value })}
                        onClick={(e) => e.stopPropagation()}
                        className="w-full px-3 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none text-sm text-gray-900 dark:text-white"
                        placeholder="Local Path"
                      />
                    </div>
                  </div>
                  <div className="col-span-12 flex gap-2 justify-end">
                    <button
                      onClick={(e) => handleSaveEdit(e)}
                      className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-all duration-200 shadow-md font-medium text-sm"
                    >
                      Save
                    </button>
                    <button
                      onClick={(e) => handleCancelEdit(e)}
                      className="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-all duration-200 shadow-md font-medium text-sm"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <motion.div
                  key={bookmark.id}
                  layout
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  onClick={(e) => handleRowClick(bookmark.url, e)}
                  className={`grid grid-cols-12 gap-4 px-4 py-3 cursor-pointer transition-all duration-200 ${
                    isSelected
                      ? `${theme === 'blue' ? 'bg-blue-50 dark:bg-blue-900/20' : theme === 'purple' ? 'bg-purple-50 dark:bg-purple-900/20' : theme === 'green' ? 'bg-green-50 dark:bg-green-900/20' : 'bg-orange-50 dark:bg-orange-900/20'}`
                      : isDarkMode 
                        ? 'hover:bg-gray-700' 
                        : 'hover:bg-gray-50'
                  }`}
                >
                  <div className="col-span-1 flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={(e) => toggleSelection(bookmark.id || 0, e as unknown as React.MouseEvent)}
                      onClick={(e) => e.stopPropagation()}
                      className="w-4 h-4 rounded accent-purple-600 cursor-pointer"
                    />
                    <ExternalLink className={`w-4 h-4 ${themeColors[theme]}`} />
                  </div>
                  <div className="col-span-4 flex items-center">
                    <span className="text-sm font-semibold text-gray-900 dark:text-white truncate">
                      {bookmark.title}
                    </span>
                  </div>
                  <div className="col-span-3 flex items-center">
                    <span className="text-sm text-gray-600 dark:text-gray-400 truncate">
                      {bookmark.url}
                    </span>
                  </div>
                  <div className="col-span-2 flex items-center">
                    <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${
                      theme === 'blue' ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300' :
                      theme === 'purple' ? 'bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300' :
                      theme === 'green' ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300' :
                      'bg-orange-100 dark:bg-orange-900/30 text-orange-700 dark:text-orange-300'
                    }`}>
                      {bookmark.category}
                    </span>
                  </div>
                  <div className="col-span-1 flex items-center">
                    {bookmark.localPath && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setFilePathToShow(bookmark.localPath || '');
                        }}
                        className="p-1.5 rounded bg-purple-600 hover:bg-purple-700 transition-all duration-200"
                        title="Open Local File"
                      >
                        <FolderOpen className="w-4 h-4 text-white" />
                      </button>
                    )}
                  </div>
                  <div className="col-span-1 flex items-center gap-1">
                    <button
                      onClick={() => handleCopyLink(bookmark.url, bookmark.id || 0)}
                      className="p-1.5 rounded bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition-all duration-200"
                      title="Copy link"
                    >
                      {copiedId === bookmark.id ? (
                        <Check className="w-3.5 h-3.5 text-green-600" />
                      ) : (
                        <Copy className="w-3.5 h-3.5 text-gray-600 dark:text-gray-300" />
                      )}
                    </button>
                    <button
                      onClick={(e) => handleEdit(bookmark, e)}
                      className="p-1.5 rounded bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition-all duration-200"
                      title="Edit bookmark"
                    >
                      <Edit2 className="w-3.5 h-3.5 text-gray-600 dark:text-gray-300" />
                    </button>
                    <button
                      onClick={() => bookmark.id && onDelete(bookmark.id)}
                      className="p-1.5 rounded bg-gray-100 dark:bg-gray-700 hover:bg-red-100 dark:hover:bg-red-900/30 transition-all duration-200"
                      title="Delete bookmark"
                    >
                      <Trash2 className="w-3.5 h-3.5 text-red-600 dark:text-red-400" />
                    </button>
                  </div>
                </motion.div>
              );
            })
          )}
        </div>
      </div>

      {/* File Path Modal */}
      <AnimatePresence>
        {filePathToShow && (
          <FilePathModal
            filePath={filePathToShow}
            onClose={() => setFilePathToShow(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
};

export default BookmarkList;
