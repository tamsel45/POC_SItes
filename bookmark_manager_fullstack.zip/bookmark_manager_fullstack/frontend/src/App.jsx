// frontend/src/App.jsx
import React, { useEffect, useState } from 'react';
import api from './api';

export default function App(){
  const [bookmarks, setBookmarks] = useState([]);
  const [q, setQ] = useState('');
  const [form, setForm] = useState({title:'', url:'', category:'General'});
  const [editing, setEditing] = useState(null);

  const fetchAll = async () => {
    const data = await api.getAll();
    setBookmarks(data);
  };

  useEffect(()=>{ fetchAll(); }, []);

  const search = async (e) => {
    e.preventDefault();
    if(!q) return fetchAll();
    const res = await api.search(q);
    setBookmarks(res);
  };

  const addBookmark = async (e) => {
    e.preventDefault();
    if(!form.title || !form.url) return alert('Title and URL required');
    if(editing){
      const updated = await api.update(editing.id, form);
      setEditing(null);
      setForm({title:'', url:'', category:'General'});
      fetchAll();
      return;
    }
    await api.add(form);
    setForm({title:'', url:'', category:'General'});
    fetchAll();
  };

  const remove = async (id) => {
    if(!confirm('Delete this bookmark?')) return;
    await api.delete(id);
    fetchAll();
  };

  const startEdit = (bm) => {
    setEditing(bm);
    setForm({title: bm.title, url: bm.url, category: bm.category});
  };

  return (
    <div className="container">
      <header>
        <h1>Bookmark Manager</h1>
        <div style={{display:'flex', gap:8, alignItems:'center'}}>
          <form onSubmit={search} style={{display:'flex', gap:8}}>
            <input className="search" placeholder="Search by title, url or category" value={q} onChange={e=>setQ(e.target.value)} />
            <button className="small" type="submit">Search</button>
            <button className="small" type="button" onClick={()=>{ setQ(''); fetchAll(); }}>Clear</button>
          </form>
        </div>
      </header>

      <section style={{marginBottom:16}}>
        <form onSubmit={addBookmark}>
          <input placeholder="Title" value={form.title} onChange={e=>setForm({...form, title:e.target.value})} />
          <input placeholder="URL (include https://)" value={form.url} onChange={e=>setForm({...form, url:e.target.value})} />
          <select value={form.category} onChange={e=>setForm({...form, category:e.target.value})}>
            <option>General</option>
            <option>Design</option>
            <option>Development</option>
            <option>Stocks</option>
            <option>Learning</option>
          </select>
          <button className="small" type="submit">{editing ? 'Update' : 'Add'}</button>
          {editing && <button type="button" className="small" onClick={()=>{ setEditing(null); setForm({title:'', url:'', category:'General'}) }}>Cancel</button>}
        </form>
      </section>

      <section>
        <div className="grid">
          {bookmarks.map(b => (
            <div className="card" key={b.id}>
              <div className="tags">{b.category}</div>
              <h3><a href={b.url} target="_blank" rel="noreferrer">{b.title}</a></h3>
              <div style={{fontSize:13, color:'#475569'}}>{b.url}</div>
              <div className="actions">
                <button className="small" onClick={()=>startEdit(b)}>Edit</button>
                <button className="small" onClick={()=>remove(b.id)}>Delete</button>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}