// frontend/src/api.js
const BASE = import.meta.env.VITE_API_BASE || 'http://localhost:4000';

async function getAll(){
  const r = await fetch(`${BASE}/api/bookmarks`);
  return r.json();
}
async function search(q){
  const r = await fetch(`${BASE}/api/bookmarks/search?q=`+encodeURIComponent(q));
  return r.json();
}
async function add(obj){
  const r = await fetch(`${BASE}/api/bookmarks`, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(obj)});
  return r.json();
}
async function update(id, obj){
  const r = await fetch(`${BASE}/api/bookmarks/`+id, {method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify(obj)});
  return r.json();
}
async function deleteBookmark(id){
  const r = await fetch(`${BASE}/api/bookmarks/`+id, {method:'DELETE'});
  return r.json();
}

export default { getAll, search, add, update, delete: deleteBookmark };