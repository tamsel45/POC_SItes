# Frontend (Vite + React)

## Setup
1. `cd frontend`
2. `npm install`
3. `npm run dev`

It expects the backend API at `http://localhost:4000` by default. You can change the API base URL by creating a `.env` file with:
VITE_API_BASE=http://your-backend:4000