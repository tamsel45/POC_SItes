# Bookmark Manager (Full-stack)

This package includes:
- `backend` — Node.js + Express + SQLite (better-sqlite3)
- `frontend` — Vite + React (simple UI, no Tailwind to keep setup minimal). You can swap CSS for Tailwind if desired.

## Quick start (local)
1. Open two terminals.
2. Start backend:
   - `cd backend`
   - `npm install`
   - `npm start`
3. Start frontend:
   - `cd frontend`
   - `npm install`
   - `npm run dev`
4. Open `http://localhost:3000`

## Notes
- Database file is `backend/db.sqlite`.
- API endpoints are listed in `backend/README.md`.
- The frontend uses `http://localhost:4000` as default backend. Change `VITE_API_BASE` if needed.