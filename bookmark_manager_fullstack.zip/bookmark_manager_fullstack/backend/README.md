# Backend (Node.js + Express + SQLite)

## Setup
1. `cd backend`
2. `npm install`
3. `npm start`

The server will run on port 4000 by default and exposes:
- GET  /api/bookmarks
- GET  /api/bookmarks/search?q=term
- POST /api/bookmarks
- PUT  /api/bookmarks/:id
- DELETE /api/bookmarks/:id