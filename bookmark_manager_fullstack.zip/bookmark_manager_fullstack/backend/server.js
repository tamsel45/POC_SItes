// backend/server.js
const express = require('express');
const cors = require('cors');
const Database = require('better-sqlite3');
const bodyParser = require('body-parser');
const path = require('path');

const db = new Database(path.join(__dirname, 'db.sqlite'));
db.prepare(`CREATE TABLE IF NOT EXISTS bookmarks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  url TEXT NOT NULL,
  category TEXT NOT NULL
)`).run();

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Get all bookmarks
app.get('/api/bookmarks', (req, res) => {
  const rows = db.prepare('SELECT * FROM bookmarks ORDER BY id DESC').all();
  res.json(rows);
});

// Search bookmarks
app.get('/api/bookmarks/search', (req, res) => {
  const q = (req.query.q || '').trim();
  if (!q) return res.json([]);
  const like = `%${q}%`;
  const rows = db.prepare('SELECT * FROM bookmarks WHERE title LIKE ? OR url LIKE ? OR category LIKE ? ORDER BY id DESC').all(like, like, like);
  res.json(rows);
});

// Add bookmark
app.post('/api/bookmarks', (req, res) => {
  const { title, url, category } = req.body;
  if (!title || !url || !category) {
    return res.status(400).json({ error: 'title, url and category required' });
  }
  const stmt = db.prepare('INSERT INTO bookmarks (title, url, category) VALUES (?, ?, ?)');
  const info = stmt.run(title, url, category);
  const newRow = db.prepare('SELECT * FROM bookmarks WHERE id = ?').get(info.lastInsertRowid);
  res.json(newRow);
});

// Update bookmark
app.put('/api/bookmarks/:id', (req, res) => {
  const id = Number(req.params.id);
  const { title, url, category } = req.body;
  db.prepare('UPDATE bookmarks SET title = ?, url = ?, category = ? WHERE id = ?').run(title, url, category, id);
  const row = db.prepare('SELECT * FROM bookmarks WHERE id = ?').get(id);
  res.json(row);
});

// Delete bookmark
app.delete('/api/bookmarks/:id', (req, res) => {
  const id = Number(req.params.id);
  db.prepare('DELETE FROM bookmarks WHERE id = ?').run(id);
  res.json({ success: true });
});

// Simple health
app.get('/api/health', (req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));